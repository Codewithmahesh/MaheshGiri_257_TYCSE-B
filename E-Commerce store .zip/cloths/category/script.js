// Global variables
let currentCategory = "women";
let allProducts = [];
let filteredProducts = [];

// Get URL parameters
function getUrlParams() {
  const params = new URLSearchParams(window.location.search);
  return params.get("category") || "women";
}

// Load products from database
async function loadProducts() {
  try {
    const response = await fetch('../api/products.php?action=get_products');
    const data = await response.json();
    
    if (data.success) {
      allProducts = data.products;
      filterAndDisplayProducts();
    } else {
      console.error('Failed to load products:', data.message);
      displayNoProducts();
    }
  } catch (error) {
    console.error('Error loading products:', error);
    displayNoProducts();
  }
}

// Convert database category to display category
function getCategoryType(dbCategory) {
  // Database categories: women_tops, women_bottoms, women_accessories, men_tops, men_bottoms, men_accessories
  const parts = dbCategory.split('_');
  return parts.length > 1 ? parts[1] : dbCategory; // Returns: tops, bottoms, accessories
}

// Get gender from database category
function getGender(dbCategory) {
  return dbCategory.startsWith('women_') ? 'women' : 'men';
}

// Calculate discounted price
function calculateDiscountedPrice(price, discountPercentage) {
  if (discountPercentage > 0) {
    return price * (1 - discountPercentage / 100);
  }
  return price;
}

// Initialize page
function init() {
  currentCategory = getUrlParams();
  updateCategoryButtons();
  updateCategoryTitle();
  loadProducts();
  checkUserSession();
}

// Update category buttons
function updateCategoryButtons() {
  const buttons = document.querySelectorAll(".category-btn-shop");
  buttons.forEach((btn) => {
    btn.classList.remove("active");
    if (btn.dataset.category === currentCategory) {
      btn.classList.add("active");
    }
  });
}

// Update category title
function updateCategoryTitle() {
  const title = document.getElementById("category-title");
  title.textContent =
    currentCategory.charAt(0).toUpperCase() +
    currentCategory.slice(1) +
    "'s Collection";
}

// Category button listeners
document.querySelectorAll(".category-btn-shop").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    currentCategory = btn.dataset.category;
    window.history.pushState(null, "", `?category=${currentCategory}`);
    updateCategoryButtons();
    updateCategoryTitle();
    resetFilters();
    filterAndDisplayProducts();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
});

// Navbar category links
document.querySelectorAll(".category-link").forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const category = link.dataset.category;
    currentCategory = category;
    window.history.pushState(null, "", `?category=${currentCategory}`);
    updateCategoryButtons();
    updateCategoryTitle();
    resetFilters();
    filterAndDisplayProducts();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
});

// Filter and display products
function filterAndDisplayProducts() {
  const maxPrice = parseInt(document.getElementById("priceRange").value);
  const selectedCategories = Array.from(
    document.querySelectorAll(".category-filter:checked")
  ).map((el) => el.value);

  // Filter products by current gender category (women/men) and active status
  let products = allProducts.filter(product => {
    const gender = getGender(product.category);
    return gender === currentCategory && product.is_active == 1;
  });

  // Apply additional filters
  filteredProducts = products.filter((product) => {
    const actualPrice = calculateDiscountedPrice(product.price, product.discount_percentage);
    const priceMatch = actualPrice <= maxPrice;
    
    const categoryType = getCategoryType(product.category);
    const categoryMatch =
      selectedCategories.length === 0 ||
      selectedCategories.includes(categoryType);

    return priceMatch && categoryMatch;
  });

  // Apply sorting
  const sortValue = document.getElementById("sort").value;
  sortProducts(sortValue);

  // Display products
  displayProducts();
}

// Sort products
function sortProducts(sortType) {
  switch (sortType) {
    case "price-low":
      filteredProducts.sort((a, b) => {
        const priceA = calculateDiscountedPrice(a.price, a.discount_percentage);
        const priceB = calculateDiscountedPrice(b.price, b.discount_percentage);
        return priceA - priceB;
      });
      break;
    case "price-high":
      filteredProducts.sort((a, b) => {
        const priceA = calculateDiscountedPrice(a.price, a.discount_percentage);
        const priceB = calculateDiscountedPrice(b.price, b.discount_percentage);
        return priceB - priceA;
      });
      break;
    case "popular":
      filteredProducts.sort((a, b) => b.id - a.id);
      break;
    case "newest":
    default:
      filteredProducts.sort((a, b) => b.id - a.id);
  }
}

// Display products
function displayProducts() {
  const grid = document.getElementById("products-grid");
  const noProducts = document.getElementById("no-products");
  const productCount = document.getElementById("product-count");

  grid.innerHTML = "";

  if (filteredProducts.length === 0) {
    noProducts.style.display = "block";
    productCount.textContent = "0";
    return;
  }

  noProducts.style.display = "none";
  productCount.textContent = filteredProducts.length;

  filteredProducts.forEach((product) => {
    const card = document.createElement("div");
    card.className = "product-card";

    const originalPrice = parseFloat(product.price);
    const discountedPrice = calculateDiscountedPrice(originalPrice, product.discount_percentage);
    const hasDiscount = product.discount_percentage > 0;

    const priceHTML = hasDiscount
      ? `<span class="price-old">$${originalPrice.toFixed(2)}</span><span class="price-new">$${discountedPrice.toFixed(2)}</span>`
      : `<span class="price-current">$${originalPrice.toFixed(2)}</span>`;

    const badgeHTML = hasDiscount 
      ? `<span class="badge">${product.discount_percentage}% OFF</span>` 
      : '';

    const imageUrl = (product.image_url && product.image_url !== '0' && product.image_url !== 'null')
      ? `../${product.image_url}` 
      : 'https://via.placeholder.com/400x500?text=No+Image';

    const categoryType = getCategoryType(product.category);

    card.innerHTML = `
      <div class="product-image">
        ${badgeHTML}
        <img src="${imageUrl}" alt="${product.name}" data-fallback="https://via.placeholder.com/400x500?text=No+Image" />
      </div>
      <div class="product-info">
        <h3>${product.name}</h3>
        <div class="product-details">
          <span>${categoryType.charAt(0).toUpperCase() + categoryType.slice(1)}</span>
          ${product.stock_quantity > 0 
            ? `<span class="stock-badge">In Stock (${product.stock_quantity})</span>` 
            : '<span class="stock-badge out-of-stock">Out of Stock</span>'}
        </div>
        ${product.description ? `<p class="product-description">${product.description.substring(0, 100)}${product.description.length > 100 ? '...' : ''}</p>` : ''}
        <div class="product-price">
          ${priceHTML}
        </div>
        <button class="add-to-cart" ${product.stock_quantity === 0 ? 'disabled' : ''}>
          ${product.stock_quantity > 0 ? 'Add to Cart' : 'Out of Stock'}
        </button>
      </div>
    `;

    // Handle image load error with JavaScript instead of inline onerror
    const img = card.querySelector('img');
    img.addEventListener('error', function() {
      const fallback = this.getAttribute('data-fallback');
      if (this.src !== fallback) {
        this.src = fallback;
      }
    });

    if (product.stock_quantity > 0) {
      card.querySelector(".add-to-cart").addEventListener("click", (e) => {
        e.preventDefault();
        addToCartProduct(product);
      });
    }

    grid.appendChild(card);
  });
}

// Display no products message
function displayNoProducts() {
  const grid = document.getElementById("products-grid");
  const noProducts = document.getElementById("no-products");
  const productCount = document.getElementById("product-count");
  
  grid.innerHTML = "";
  noProducts.style.display = "block";
  productCount.textContent = "0";
}

// Add to cart
function addToCartProduct(product) {
  // Use shared addToCart function from cart-utils.js
  // This handles login check and redirects guests to login page
  addToCart(product);
}

// Filter listeners
document.getElementById("priceRange").addEventListener("input", (e) => {
  document.getElementById("priceValue").textContent = e.target.value;
  filterAndDisplayProducts();
});

document
  .querySelectorAll(".category-filter")
  .forEach((filter) => {
    filter.addEventListener("change", filterAndDisplayProducts);
  });

// Sort listener
document.getElementById("sort").addEventListener("change", (e) => {
  sortProducts(e.target.value);
  displayProducts();
});

// Reset filters
function resetFilters() {
  document.getElementById("priceRange").value = 500;
  document.getElementById("priceValue").textContent = "500";
  document
    .querySelectorAll(".category-filter")
    .forEach((filter) => {
      filter.checked = false;
    });
  document.getElementById("sort").value = "newest";
}

// Reset button listener
document.querySelector(".btn-reset").addEventListener("click", (e) => {
  e.preventDefault();
  resetFilters();
  filterAndDisplayProducts();
});



// Mobile menu toggle
const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
const navLinks = document.querySelector(".nav-links");

if (mobileMenuBtn) {
  mobileMenuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("active");
    mobileMenuBtn.classList.toggle("active");

    const spans = mobileMenuBtn.querySelectorAll("span");
    if (mobileMenuBtn.classList.contains("active")) {
      spans[0].style.transform = "rotate(45deg) translate(5px, 5px)";
      spans[1].style.opacity = "0";
      spans[2].style.transform = "rotate(-45deg) translate(7px, -6px)";
    } else {
      spans[0].style.transform = "none";
      spans[1].style.opacity = "1";
      spans[2].style.transform = "none";
    }
  });
}

// Initialize on page load
window.addEventListener("DOMContentLoaded", init);

// Handle browser back/forward buttons
window.addEventListener("popstate", init);

// Check user session and update navbar
function checkUserSession() {
  const formData = new FormData();
  formData.append('action', 'check_session');

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success && data.logged_in) {
      updateNavbarForLoggedInUser(data.user);
      // Fetch cart count for logged in user
      updateCartCount();
    }
  })
  .catch(error => {
    console.error('Session check error:', error);
  });
}

// Update cart count from server
function updateCartCount() {
  fetch('../api/cart.php?action=get_cart')
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const cartCount = document.querySelector(".cart-count");
        cartCount.textContent = data.count;
      }
    })
    .catch(error => console.error('Error fetching cart count:', error));
}

// Update navbar to show user avatar
function updateNavbarForLoggedInUser(user) {
  // Find the login link - it might be an anchor tag with href to auth page
  const userLoginLink = document.querySelector('a[href="../auth/index.html"]');
  
  if (userLoginLink) {
    // Get user initials
    const initials = getUserInitials(user.name);
    
    // Create user avatar and dropdown
    const userAvatarHTML = `
      <div class="user-profile-container">
        <button class="user-avatar" id="userAvatarBtn" aria-label="User Menu">
          ${initials}
        </button>
        <div class="user-dropdown" id="userDropdown">
          <div class="user-dropdown-header">
            <div class="user-dropdown-avatar">${initials}</div>
            <div class="user-dropdown-info">
              <p class="user-dropdown-name">${user.name}</p>
              <p class="user-dropdown-email">${user.email}</p>
            </div>
          </div>
          <div class="user-dropdown-divider"></div>
          <a href="../profile/index.html" class="user-dropdown-item">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            Edit Profile
          </a>
          <button class="user-dropdown-item" id="logoutBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Logout
          </button>
        </div>
      </div>
    `;
    
    // Replace the login link with avatar
    const container = document.createElement('div');
    container.innerHTML = userAvatarHTML;
    userLoginLink.parentNode.replaceChild(container.firstElementChild, userLoginLink);
    
    // Add event listeners
    setupUserDropdown();
  }
}

// Get user initials from name
function getUserInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return parts[0][0].toUpperCase();
}

// Setup user dropdown functionality
function setupUserDropdown() {
  const avatarBtn = document.getElementById('userAvatarBtn');
  const dropdown = document.getElementById('userDropdown');
  const logoutBtn = document.getElementById('logoutBtn');
  
  if (avatarBtn && dropdown) {
    // Toggle dropdown
    avatarBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('active');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!avatarBtn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
      }
    });
  }
  
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      const formData = new FormData();
      formData.append('action', 'logout');
      
      fetch('../api/user_auth.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          showNotification('Logged out successfully!');
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        }
      })
      .catch(error => {
        console.error('Logout error:', error);
      });
    });
  }
}
