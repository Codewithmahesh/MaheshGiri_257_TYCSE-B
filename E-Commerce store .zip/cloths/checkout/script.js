// Initialize
document.addEventListener('DOMContentLoaded', () => {
  checkUserSession();
});

// Track selected items
let selectedItems = new Set();
let cartData = [];

// Check user session
function checkUserSession() {
  const formData = new FormData();
  formData.append('action', 'check_session');

  fetch('/cloths/api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success && data.logged_in) {
      updateNavbarForLoggedInUser(data.user);
      loadCartItems();
    } else {
      // Redirect to login if not logged in
      window.location.href = '../auth/index.html';
    }
  })
  .catch(error => {
    console.error('Session check error:', error);
  });
}

// Load cart items
function loadCartItems() {
  fetch('/cloths/api/cart.php?action=get_cart')
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        cartData = data.cart_items;
        // Select all items by default
        selectedItems = new Set(cartData.map(item => item.id));
        displayCartItems(cartData);
        updateOrderSummary();
        updateCartCount(data.count);
      }
    })
    .catch(error => console.error('Error loading cart:', error));
}

// Display cart items
function displayCartItems(items) {
  const container = document.getElementById('cart-items');
  
  if (items.length === 0) {
    container.innerHTML = '<div class="empty-cart-message">Your cart is empty. <a href="../category/index.html?category=women">Start shopping</a></div>';
    document.getElementById('placeOrderBtn').disabled = true;
    return;
  }

  container.innerHTML = items.map(item => {
    const price = parseFloat(item.price);
    const discount = parseInt(item.discount_percentage);
    const finalPrice = discount > 0 ? price * (1 - discount / 100) : price;
    const imageUrl = (item.image_url && item.image_url !== '0') ? `/cloths/${item.image_url}` : 'https://via.placeholder.com/100x120?text=No+Image';
    const isSelected = selectedItems.has(item.id);

    return `
      <div class="cart-item ${isSelected ? 'selected' : ''}" data-id="${item.id}">
        <div class="cart-item-checkbox">
          <input 
            type="checkbox" 
            class="item-checkbox" 
            data-cart-id="${item.id}" 
            ${isSelected ? 'checked' : ''} 
            onchange="toggleItemSelection(${item.id})"
            aria-label="Select ${item.name}"
            style="display: block; width: 24px; height: 24px;"
          >
        </div>
        <img 
          src="${imageUrl}" 
          alt="${item.name}" 
          class="cart-item-image" 
          style="width: 100px; height: 120px; object-fit: cover;"
          onerror="this.src='https://via.placeholder.com/100x120?text=No+Image'"
        >
        <div class="cart-item-details">
          <h3 class="cart-item-name">${item.name}</h3>
          <div class="cart-item-price-row">
            <span class="cart-item-price">$${finalPrice.toFixed(2)}</span>
            ${discount > 0 ? `
              <span class="cart-item-price-original">$${price.toFixed(2)}</span>
              <span class="cart-item-discount-badge">${discount}% OFF</span>
            ` : ''}
          </div>
          <div class="cart-item-actions">
            <div class="quantity-controls">
              <button class="qty-btn minus" onclick="updateQuantity(${item.id}, ${item.quantity - 1})" ${item.quantity <= 1 ? 'disabled' : ''}>−</button>
              <span class="qty-display">${item.quantity}</span>
              <button class="qty-btn plus" onclick="updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
            </div>
            <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
          </div>
        </div>
      </div>
    `;
  }).join('');
  
  // Update select all checkbox
  updateSelectAllCheckbox();
}

// Toggle item selection
window.toggleItemSelection = function(cartId) {
  if (selectedItems.has(cartId)) {
    selectedItems.delete(cartId);
  } else {
    selectedItems.add(cartId);
  }
  
  // Update UI
  const cartItem = document.querySelector(`.cart-item[data-id="${cartId}"]`);
  if (cartItem) {
    cartItem.classList.toggle('selected', selectedItems.has(cartId));
  }
  
  updateSelectAllCheckbox();
  updateOrderSummary();
};

// Select all checkbox handler
document.addEventListener('DOMContentLoaded', () => {
  const selectAllCheckbox = document.getElementById('selectAllCheckbox');
  if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener('change', (e) => {
      const isChecked = e.target.checked;
      
      if (isChecked) {
        // Select all items
        selectedItems = new Set(cartData.map(item => item.id));
      } else {
        // Deselect all items
        selectedItems.clear();
      }
      
      // Update all checkboxes and cart items
      document.querySelectorAll('.item-checkbox').forEach(checkbox => {
        checkbox.checked = isChecked;
      });
      
      document.querySelectorAll('.cart-item').forEach(item => {
        item.classList.toggle('selected', isChecked);
      });
      
      updateOrderSummary();
    });
  }
});

// Update select all checkbox state
function updateSelectAllCheckbox() {
  const selectAllCheckbox = document.getElementById('selectAllCheckbox');
  if (selectAllCheckbox && cartData.length > 0) {
    selectAllCheckbox.checked = selectedItems.size === cartData.length;
  }
}

// Update quantity
window.updateQuantity = function(cartId, newQuantity) {
  if (newQuantity < 1) return;

  const formData = new FormData();
  formData.append('action', 'update_quantity');
  formData.append('cart_id', cartId);
  formData.append('quantity', newQuantity);

  fetch('/cloths/api/cart.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      loadCartItems(); // Reload to update totals
    }
  });
};

// Remove from cart
window.removeFromCart = function(cartId) {
  if (!confirm('Are you sure you want to remove this item?')) return;

  const formData = new FormData();
  formData.append('action', 'remove_from_cart');
  formData.append('cart_id', cartId);

  fetch('/cloths/api/cart.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      selectedItems.delete(cartId);
      loadCartItems();
    }
  });
};

// Update order summary
function updateOrderSummary() {
  let subtotal = 0;
  let selectedCount = 0;
  
  cartData.forEach(item => {
    if (selectedItems.has(item.id)) {
      const price = parseFloat(item.price);
      const discount = parseInt(item.discount_percentage);
      const finalPrice = discount > 0 ? price * (1 - discount / 100) : price;
      subtotal += finalPrice * item.quantity;
      selectedCount++;
    }
  });

  document.getElementById('selectedCount').textContent = selectedCount;
  document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
  document.getElementById('total').textContent = `$${subtotal.toFixed(2)}`;
  
  // Disable checkout if no items selected
  const placeOrderBtn = document.getElementById('placeOrderBtn');
  placeOrderBtn.disabled = selectedCount === 0;
}

// Update cart count badge
function updateCartCount(count) {
  const badge = document.querySelector('.cart-count');
  if (badge) badge.textContent = count;
}

// Place order
document.addEventListener('DOMContentLoaded', () => {
  const placeOrderBtn = document.getElementById('placeOrderBtn');
  if (placeOrderBtn) {
    placeOrderBtn.addEventListener('click', placeOrder);
  }
});

function placeOrder() {
  if (selectedItems.size === 0) {
    showNotification('Please select at least one item to checkout');
    return;
  }
  
  const selectedCount = selectedItems.size;
  const selectedItemNames = cartData
    .filter(item => selectedItems.has(item.id))
    .map(item => item.name)
    .join(', ');
  
  if (!confirm(`Place order for ${selectedCount} item(s)?\n\nItems: ${selectedItemNames}`)) {
    return;
  }
  
  const placeOrderBtn = document.getElementById('placeOrderBtn');
  placeOrderBtn.disabled = true;
  placeOrderBtn.textContent = 'Processing Order...';
  
  const formData = new FormData();
  formData.append('action', 'place_order');
  formData.append('selected_items', JSON.stringify(Array.from(selectedItems)));
  
  fetch('/cloths/api/orders.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      showNotification(`✅ Order #${data.order_id} placed successfully!\n\n📧 Confirmation email sent to your inbox.`);
      
      // Wait 3 seconds before redirecting
      setTimeout(() => {
        window.location.href = '../home/index.html';
      }, 3000);
    } else {
      showNotification('❌ ' + (data.message || 'Failed to place order'));
      placeOrderBtn.disabled = false;
      placeOrderBtn.textContent = 'Place Order';
    }
  })
  .catch(error => {
    console.error('Error placing order:', error);
    showNotification('❌ Error placing order. Please try again.');
    placeOrderBtn.disabled = false;
    placeOrderBtn.textContent = 'Place Order';
  });
}

// Update navbar for logged in user (reused from other pages)
function updateNavbarForLoggedInUser(user) {
  const userLoginLink = document.getElementById('loginLink');
  
  if (userLoginLink) {
    const initials = getUserInitials(user.name);
    
    const userAvatarHTML = `
      <div class="user-profile-container">
        <button class="user-avatar" id="userAvatarBtn" aria-label="User Menu">
          ${initials}
        </button>
        <div class="user-dropdown" id="userDropdown">
          <div class="user-dropdown-header">
            <div class="user-dropdown-avatar">${initials}</div>
            <div class="user-dropdown-info">
              <p class="user-dropdown-name">${user.name}</p>
              <p class="user-dropdown-email">${user.email}</p>
            </div>
          </div>
          <div class="user-dropdown-divider"></div>
          <a href="../profile/index.html" class="user-dropdown-item">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            Edit Profile
          </a>
          <button class="user-dropdown-item" id="logoutBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Logout
          </button>
        </div>
      </div>
    `;
    
    const container = document.createElement('div');
    container.innerHTML = userAvatarHTML;
    userLoginLink.parentNode.replaceChild(container.firstElementChild, userLoginLink);
    
    setupUserDropdown();
  }
}

function getUserInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return parts[0][0].toUpperCase();
}

function setupUserDropdown() {
  const avatarBtn = document.getElementById('userAvatarBtn');
  const dropdown = document.getElementById('userDropdown');
  const logoutBtn = document.getElementById('logoutBtn');
  
  if (avatarBtn && dropdown) {
    avatarBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('active');
    });
    
    document.addEventListener('click', (e) => {
      if (!avatarBtn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
      }
    });
  }
  
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      const formData = new FormData();
      formData.append('action', 'logout');
      
      fetch('/cloths/api/user_auth.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          window.location.href = '../home/index.html';
        }
      });
    });
  }
}
