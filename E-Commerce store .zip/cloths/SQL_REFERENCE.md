# SQL Reference & Commands

## Initial Setup Commands

### Create Database (if not using SQL file)
```sql
CREATE DATABASE IF NOT EXISTS cloths_db;
USE cloths_db;
```

### Create Tables (if not using SQL file)
```sql
-- Users Table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    city VARCHAR(50),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    country VARCHAR(50),
    profile_picture VARCHAR(255),
    is_active BOOLEAN DEFAULT 1,
    email_verified BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admins Table
CREATE TABLE admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'admin', 'moderator') DEFAULT 'admin',
    phone VARCHAR(20),
    profile_picture VARCHAR(255),
    is_active BOOLEAN DEFAULT 1,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## User Management Commands

### Insert Test User
```sql
-- Password: Password123 (hashed)
INSERT INTO users (name, email, password, is_active) 
VALUES (
    'Test User',
    'test@example.com',
    '$2y$10$YOUR_HASHED_PASSWORD',
    1
);
```

### Get all users
```sql
SELECT * FROM users;
```

### Get specific user by email
```sql
SELECT * FROM users WHERE email = 'test@example.com';
```

### Update user info
```sql
UPDATE users 
SET phone = '1234567890', address = '123 Main St'
WHERE id = 1;
```

### Deactivate user
```sql
UPDATE users SET is_active = 0 WHERE id = 1;
```

### Activate user
```sql
UPDATE users SET is_active = 1 WHERE id = 1;
```

### Count total users
```sql
SELECT COUNT(*) as total_users FROM users;
```

### Count active users
```sql
SELECT COUNT(*) as active_users FROM users WHERE is_active = 1;
```

### Get users created this month
```sql
SELECT * FROM users 
WHERE MONTH(created_at) = MONTH(CURDATE()) 
AND YEAR(created_at) = YEAR(CURDATE());
```

### Delete user (careful!)
```sql
DELETE FROM users WHERE id = 1;
```

---

## Admin Management Commands

### Insert Super Admin
```sql
INSERT INTO admins (name, email, password, role, is_active) 
VALUES (
    'Super Admin',
    'admin@cloths.local',
    '$2y$10$YOUR_HASHED_PASSWORD',
    'super_admin',
    1
);
```

### Insert Regular Admin
```sql
INSERT INTO admins (name, email, password, role, is_active) 
VALUES (
    'Admin User',
    'admin2@cloths.local',
    '$2y$10$YOUR_HASHED_PASSWORD',
    'admin',
    1
);
```

### Insert Moderator
```sql
INSERT INTO admins (name, email, password, role, is_active) 
VALUES (
    'Moderator',
    'mod@cloths.local',
    '$2y$10$YOUR_HASHED_PASSWORD',
    'moderator',
    1
);
```

### Get all admins
```sql
SELECT * FROM admins;
```

### Get admins by role
```sql
SELECT * FROM admins WHERE role = 'admin';
SELECT * FROM admins WHERE role = 'super_admin';
SELECT * FROM admins WHERE role = 'moderator';
```

### Get admin with last login info
```sql
SELECT id, name, email, role, last_login FROM admins;
```

### Update admin last login
```sql
UPDATE admins SET last_login = NOW() WHERE id = 1;
```

### Change admin role
```sql
UPDATE admins SET role = 'moderator' WHERE id = 2;
```

### Deactivate admin
```sql
UPDATE admins SET is_active = 0 WHERE id = 1;
```

### Count admins by role
```sql
SELECT role, COUNT(*) as count FROM admins GROUP BY role;
```

### Delete admin
```sql
DELETE FROM admins WHERE id = 1;
```

---

## Password Management

### Change user password (in PHP)
```php
$newPassword = password_hash('newPassword123', PASSWORD_BCRYPT);
$query = "UPDATE users SET password = ? WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("si", $newPassword, $userId);
$stmt->execute();
```

### Change password in SQL (unsafe - for recovery only)
```sql
-- Get hash first from PHP, then:
UPDATE users SET password = '$2y$10$HASHED_PASSWORD' WHERE id = 1;
UPDATE admins SET password = '$2y$10$HASHED_PASSWORD' WHERE id = 1;
```

### Verify password in PHP
```php
$userPassword = 'passwordToCheck';
$dbPassword = $user['password']; // from database
if (password_verify($userPassword, $dbPassword)) {
    // Password is correct
} else {
    // Password is incorrect
}
```

---

## Product Management Commands

### Add new product
```sql
INSERT INTO products (name, description, category, price, stock_quantity, image_url, created_by, is_active)
VALUES (
    'Womens T-Shirt',
    'Comfortable cotton t-shirt',
    'women_tops',
    45.00,
    50,
    'https://example.com/image.jpg',
    1,
    1
);
```

### Get products by category
```sql
SELECT * FROM products 
WHERE category = 'women_tops' AND is_active = 1
ORDER BY created_at DESC;
```

### Get all categories
```sql
SELECT DISTINCT category FROM products;
```

### Get products on sale
```sql
SELECT * FROM products 
WHERE discount_percentage > 0 AND is_active = 1
ORDER BY discount_percentage DESC;
```

### Update product price
```sql
UPDATE products SET price = 55.00 WHERE id = 1;
```

### Add discount
```sql
UPDATE products SET discount_percentage = 20 WHERE id = 1;
```

### Update stock
```sql
UPDATE products SET stock_quantity = 100 WHERE id = 1;
```

### Get low stock items
```sql
SELECT * FROM products 
WHERE stock_quantity < 10 AND is_active = 1;
```

### Get products by price range
```sql
SELECT * FROM products 
WHERE price >= 50 AND price <= 150 AND is_active = 1;
```

### Count products per category
```sql
SELECT category, COUNT(*) as count 
FROM products 
GROUP BY category;
```

### Delete product (soft delete - deactivate)
```sql
UPDATE products SET is_active = 0 WHERE id = 1;
```

---

## Order Management Commands

### Get all orders
```sql
SELECT * FROM orders;
```

### Get orders by user
```sql
SELECT * FROM orders WHERE user_id = 1;
```

### Get orders by status
```sql
SELECT * FROM orders WHERE status = 'pending';
SELECT * FROM orders WHERE status = 'processing';
SELECT * FROM orders WHERE status = 'shipped';
SELECT * FROM orders WHERE status = 'delivered';
SELECT * FROM orders WHERE status = 'cancelled';
```

### Get order with details
```sql
SELECT o.*, u.name, u.email, u.address,
       oi.product_id, oi.quantity, oi.price,
       p.name as product_name
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN order_items oi ON o.id = oi.order_id
JOIN products p ON oi.product_id = p.id
WHERE o.id = 1;
```

### Update order status
```sql
UPDATE orders SET status = 'shipped' WHERE id = 1;
```

### Get total sales
```sql
SELECT SUM(total_amount) as total_sales FROM orders WHERE status = 'delivered';
```

### Get orders from today
```sql
SELECT * FROM orders WHERE DATE(created_at) = CURDATE();
```

### Get top customers
```sql
SELECT u.id, u.name, COUNT(o.id) as orders, SUM(o.total_amount) as spent
FROM users u
JOIN orders o ON u.id = o.user_id
GROUP BY u.id
ORDER BY spent DESC
LIMIT 10;
```

---

## Cart Management Commands

### Get user's cart
```sql
SELECT c.*, p.name, p.price, p.image_url
FROM cart c
JOIN products p ON c.product_id = p.id
WHERE c.user_id = 1;
```

### Add to cart
```sql
INSERT INTO cart (user_id, product_id, quantity)
VALUES (1, 5, 2)
ON DUPLICATE KEY UPDATE quantity = quantity + 2;
```

### Remove from cart
```sql
DELETE FROM cart WHERE user_id = 1 AND product_id = 5;
```

### Clear entire cart
```sql
DELETE FROM cart WHERE user_id = 1;
```

### Get cart total
```sql
SELECT SUM(c.quantity * p.price) as cart_total
FROM cart c
JOIN products p ON c.product_id = p.id
WHERE c.user_id = 1;
```

---

## Wishlist Management Commands

### Get user's wishlist
```sql
SELECT w.*, p.name, p.price, p.image_url
FROM wishlist w
JOIN products p ON w.product_id = p.id
WHERE w.user_id = 1;
```

### Add to wishlist
```sql
INSERT INTO wishlist (user_id, product_id)
VALUES (1, 5)
ON DUPLICATE KEY UPDATE added_at = CURRENT_TIMESTAMP;
```

### Remove from wishlist
```sql
DELETE FROM wishlist WHERE user_id = 1 AND product_id = 5;
```

---

## Review Management Commands

### Get product reviews
```sql
SELECT r.*, u.name, u.profile_picture
FROM reviews r
JOIN users u ON r.user_id = u.id
WHERE r.product_id = 1 AND r.is_approved = 1
ORDER BY r.created_at DESC;
```

### Add review
```sql
INSERT INTO reviews (product_id, user_id, rating, comment)
VALUES (1, 2, 5, 'Excellent product! Highly recommended.');
```

### Get average rating for product
```sql
SELECT 
    product_id, 
    AVG(rating) as avg_rating, 
    COUNT(*) as review_count,
    MIN(rating) as min_rating,
    MAX(rating) as max_rating
FROM reviews
WHERE is_approved = 1
GROUP BY product_id;
```

### Approve review (moderator)
```sql
UPDATE reviews SET is_approved = 1 WHERE id = 1;
```

### Get pending reviews
```sql
SELECT * FROM reviews WHERE is_approved = 0;
```

---

## Reporting & Analytics Commands

### Sales Report
```sql
SELECT 
    DATE(o.created_at) as date,
    COUNT(o.id) as orders,
    SUM(o.total_amount) as revenue,
    AVG(o.total_amount) as avg_order_value
FROM orders o
WHERE o.status IN ('shipped', 'delivered')
GROUP BY DATE(o.created_at)
ORDER BY date DESC;
```

### Top Selling Products
```sql
SELECT 
    p.id,
    p.name,
    COUNT(oi.id) as times_sold,
    SUM(oi.quantity) as total_quantity,
    SUM(oi.price * oi.quantity) as revenue
FROM products p
JOIN order_items oi ON p.id = oi.product_id
GROUP BY p.id
ORDER BY revenue DESC
LIMIT 10;
```

### Customer Lifetime Value
```sql
SELECT 
    u.id,
    u.name,
    u.email,
    COUNT(o.id) as total_orders,
    SUM(o.total_amount) as lifetime_value,
    MAX(o.created_at) as last_order_date
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id
ORDER BY lifetime_value DESC;
```

### Monthly Revenue
```sql
SELECT 
    YEAR(o.created_at) as year,
    MONTH(o.created_at) as month,
    COUNT(o.id) as orders,
    SUM(o.total_amount) as revenue
FROM orders o
WHERE o.status IN ('shipped', 'delivered')
GROUP BY YEAR(o.created_at), MONTH(o.created_at)
ORDER BY year DESC, month DESC;
```

---

## Database Maintenance Commands

### Show database size
```sql
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
FROM information_schema.TABLES
WHERE table_schema = 'cloths_db'
ORDER BY (data_length + index_length) DESC;
```

### Check table structure
```sql
DESCRIBE users;
DESCRIBE admins;
DESCRIBE products;
```

### Show all indexes
```sql
SHOW INDEXES FROM users;
SHOW INDEXES FROM products;
```

### Repair table (if corrupted)
```sql
REPAIR TABLE users;
```

### Optimize table (improve performance)
```sql
OPTIMIZE TABLE users;
OPTIMIZE TABLE products;
OPTIMIZE TABLE orders;
```

### Backup database (via SQL)
```sql
-- Export from phpMyAdmin: Database → Export
-- Or use: mysqldump -u root cloths_db > backup.sql
```

### Restore database
```sql
-- Import in phpMyAdmin: Import tab
-- Or use: mysql -u root cloths_db < backup.sql
```

---

## Useful Helper Queries

### Get row counts for all tables
```sql
SELECT 
    'users' as table_name, COUNT(*) as count FROM users
UNION ALL SELECT 'admins', COUNT(*) FROM admins
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL SELECT 'cart', COUNT(*) FROM cart
UNION ALL SELECT 'wishlist', COUNT(*) FROM wishlist
UNION ALL SELECT 'reviews', COUNT(*) FROM reviews;
```

### Find duplicate emails
```sql
SELECT email, COUNT(*) FROM users GROUP BY email HAVING COUNT(*) > 1;
SELECT email, COUNT(*) FROM admins GROUP BY email HAVING COUNT(*) > 1;
```

### Get inactive users
```sql
SELECT * FROM users WHERE is_active = 0;
```

### Get users who never made a purchase
```sql
SELECT u.* FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE o.id IS NULL
AND u.created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
```

### Get recently created accounts (last 7 days)
```sql
SELECT * FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);
```

---

## PHP Helper Functions

### Hash a password
```php
$password = "yourPasswordHere";
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
echo $hashedPassword;
```

### Execute insert and get ID
```php
$query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $name, $email, $password);
$stmt->execute();
$newId = $stmt->insert_id;
```

### Check if email exists
```php
$email = "test@example.com";
$query = "SELECT id FROM users WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    echo "Email already exists";
}
```

### Return JSON response
```php
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Operation successful']);
```

---

This comprehensive SQL reference covers all common operations you'll need for managing the cloths database!
