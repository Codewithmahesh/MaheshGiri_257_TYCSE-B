<?php
// Enable error reporting to see any warnings
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/email_config.php';
require_once 'api/SimpleSMTPMail.php';

echo "Testing Email Sending...\n";
echo "Provider: " . EMAIL_PROVIDER . "\n";
echo "Sender: " . GMAIL_SENDER_EMAIL . "\n";

try {
    $mailer = new SimpleSMTPMail(GMAIL_SENDER_EMAIL, GMAIL_APP_PASSWORD);
    $result = $mailer->send('girimahesh1514@gmail.com', 'Test Email', '<h1>Test</h1><p>This is a test email.</p>');
    
    if ($result) {
        echo "Email sent successfully!\n";
    } else {
        echo "Email sending failed.\n";
    }
} catch (Throwable $e) {
    echo "Exception: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString();
}
?>
