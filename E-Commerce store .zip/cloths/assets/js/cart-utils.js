// Shared Cart Utility Functions
// Used across all pages for consistent cart behavior

/**
 * Add product to cart
 * @param {Object} product - Product object with id, name, etc.
 * @param {Function} callback - Optional callback after successful add
 */
async function addToCart(product) {
  console.log('addToCart called with product:', product);
  
  // Check if user is logged in
  const isUserLoggedIn = document.getElementById('userAvatarBtn') !== null;
  console.log('User logged in:', isUserLoggedIn);
  
  if (!isUserLoggedIn) {
    // Redirect to login page
    showNotification('Please login to add items to cart');
    setTimeout(() => {
      window.location.href = '/cloths/auth/index.html';
    }, 1500);
    return;
  }

  const formData = new FormData();
  formData.append('action', 'add_to_cart');
  formData.append('product_id', product.id);
  formData.append('quantity', 1);
  
  console.log('Sending cart request for product ID:', product.id);
  
  try {
    const response = await fetch('/cloths/api/cart.php', {
      method: 'POST',
      body: formData
    });
    
    console.log('Cart API response status:', response.status);
    const data = await response.json();
    console.log('Cart API response data:', data);
    
    if (data.success) {
      updateCartCount();
      showNotification(`${product.name} added to cart!`);
    } else {
      showNotification(data.message || 'Failed to add to cart');
    }
  } catch (error) {
    console.error('Error adding to cart:', error);
    showNotification('Error adding to cart');
  }
}

/**
 * Update cart count badge from server
 */
async function updateCartCount() {
  try {
    const response = await fetch('/cloths/api/cart.php?action=get_cart');
    const data = await response.json();
    
    if (data.success) {
      const cartCount = document.querySelector('.cart-count');
      if (cartCount) {
        cartCount.textContent = data.count;
        
        // Add animation
        cartCount.style.transform = 'scale(1.3)';
        setTimeout(() => {
          cartCount.style.transform = 'scale(1)';
        }, 200);
      }
    }
  } catch (error) {
    console.error('Error fetching cart count:', error);
  }
}

/**
 * Show notification toast
 * @param {string} message - Message to display
 */
function showNotification(message) {
  // Remove existing notification if any
  const existing = document.querySelector('.notification');
  if (existing) existing.remove();

  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    background: #000;
    color: #fff;
    padding: 16px 24px;
    border-radius: 4px;
    z-index: 10000;
    animation: slideIn 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  `;

  document.body.appendChild(notification);

  // Add CSS for animation if not already present
  if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
      @keyframes slideIn {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(400px); opacity: 0; }
      }
    `;
    document.head.appendChild(style);
  }

  // Remove notification after 3 seconds
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}
