// Toggle between login and register forms
const toggleAuthLinks = document.querySelectorAll('.toggle-auth');
const loginBox = document.querySelector('.login-box');
const registerBox = document.querySelector('.register-box');

toggleAuthLinks.forEach((link) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    loginBox.classList.toggle('active');
    registerBox.classList.toggle('active');
  });
});

// Loading Spinner Functions
function showLoading(message = 'Processing...') {
  document.getElementById('loadingOverlay').classList.add('active');
  document.getElementById('loadingSpinner').classList.add('active');
  document.getElementById('spinnerText').textContent = message;
}

function hideLoading() {
  document.getElementById('loadingOverlay').classList.remove('active');
  document.getElementById('loadingSpinner').classList.remove('active');
}

// Toggle Password Visibility
const togglePasswordBtns = document.querySelectorAll('.toggle-password');

togglePasswordBtns.forEach((btn) => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    const targetId = btn.dataset.target;
    const input = document.getElementById(targetId);
    const isPassword = input.type === 'password';
    
    // Toggle input type
    input.type = isPassword ? 'text' : 'password';
    
    // Toggle icon (you can add different SVGs for eye open/closed if desired)
    btn.classList.toggle('active');
  });
});

// Login Form Submission
const loginForm = document.getElementById('loginForm');
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const rememberMe = document.querySelector('input[name="remember"]').checked;
  const submitBtn = loginForm.querySelector('button[type="submit"]');

  if (email && password) {
    showLoading('Logging in...');
    submitBtn.disabled = true;

    const formData = new FormData();
    formData.append('action', 'user_login');
    formData.append('email', email);
    formData.append('password', password);
    formData.append('remember_me', rememberMe ? 'true' : 'false');

    fetch('../api/user_auth.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      hideLoading();
      if (data.success) {
        showNotification('Login successful! Redirecting...', 'success');
        
        // Store remember me preference if checked
        if (rememberMe) {
          localStorage.setItem('rememberedEmail', email);
        }

        // Redirect after 2 seconds
        setTimeout(() => {
          window.location.href = data.redirect;
        }, 2000);
      } else {
        submitBtn.disabled = false;
        showNotification(data.message || 'Login failed', 'error');
      }
    })
    .catch(error => {
      hideLoading();
      submitBtn.disabled = false;
      showNotification('An error occurred. Please try again.', 'error');
      console.error('Error:', error);
    });
  }
});

// Global variables
let otpTimeLeft = 180; // 3 minutes
let otpTimerInterval = null;
let userEmail = '';

// Register Form Submission
const registerForm = document.getElementById('registerForm');
registerForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const name = document.getElementById('register-name').value;
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  const confirmPassword = document.getElementById('register-confirm').value;
  const agreeTerms = document.querySelector('input[name="agree"]').checked;
  const submitBtn = registerForm.querySelector('button[type="submit"]');

  // Optional fields
  const phone = document.getElementById('register-phone').value;
  const address = document.getElementById('register-address').value;
  const city = document.getElementById('register-city').value;
  const state = document.getElementById('register-state').value;
  const zipCode = document.getElementById('register-zip').value;
  const country = document.getElementById('register-country').value;

  // Validate passwords match
  if (password !== confirmPassword) {
    showNotification('Passwords do not match!', 'error');
    return;
  }

  // Validate password strength (at least 6 characters)
  if (password.length < 6) {
    showNotification('Password must be at least 6 characters long', 'error');
    return;
  }

  if (name && email && password && confirmPassword && agreeTerms) {
    showLoading('Creating account and sending OTP...');
    submitBtn.disabled = true;

    const formData = new FormData();
    formData.append('action', 'user_register');
    formData.append('name', name);
    formData.append('email', email);
    formData.append('password', password);
    formData.append('confirmPassword', confirmPassword);
    formData.append('phone', phone);
    formData.append('address', address);
    formData.append('city', city);
    formData.append('state', state);
    formData.append('zip_code', zipCode);
    formData.append('country', country);

    fetch('../api/user_auth.php', {
      method: 'POST',
      body: formData
    })
    .then(async response => {
      const text = await response.text();
      try {
        return JSON.parse(text);
      } catch (e) {
        throw new Error('Server returned invalid JSON: ' + text.substring(0, 100));
      }
    })
    .then(data => {
      hideLoading();
      if (data.success) {
        userEmail = email;
        showNotification('Account created! Please verify your email with the OTP code.', 'success');
        
        // Show OTP modal
        setTimeout(() => {
          showOTPModal();
          startOTPTimer();
        }, 1000);
      } else {
        submitBtn.disabled = false;
        showNotification(data.message || 'Registration failed', 'error');
      }
    })
    .catch(error => {
      hideLoading();
      submitBtn.disabled = false;
      showNotification('Error: ' + error.message, 'error');
      console.error('Error:', error);
    });
  }
});

// OTP Modal Functions
function showOTPModal() {
  document.getElementById('otpModal').classList.add('active');
}

function closeOTPModal() {
  document.getElementById('otpModal').classList.remove('active');
  clearInterval(otpTimerInterval);
}

function startOTPTimer() {
  otpTimeLeft = 180; // Reset to 3 minutes
  updateTimerDisplay();
  
  if (otpTimerInterval) clearInterval(otpTimerInterval);
  
  otpTimerInterval = setInterval(() => {
    otpTimeLeft--;
    updateTimerDisplay();
    
    if (otpTimeLeft <= 0) {
      clearInterval(otpTimerInterval);
      document.getElementById('resendBtn').disabled = false;
      showNotification('OTP expired. Please request a new one.', 'error');
    }
  }, 1000);
}

function updateTimerDisplay() {
  const minutes = Math.floor(otpTimeLeft / 60);
  const seconds = otpTimeLeft % 60;
  document.getElementById('timerValue').textContent = 
    `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

// OTP Input Handling
const otpInputs = document.querySelectorAll('.otp-input');
otpInputs.forEach((input, index) => {
  input.addEventListener('keyup', (e) => {
    if (e.key >= 0 && e.key <= 9) {
      if (input.value) {
        if (index < otpInputs.length - 1) {
          otpInputs[index + 1].focus();
        }
      }
    }
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Backspace' && !input.value && index > 0) {
      otpInputs[index - 1].focus();
    }
  });

  input.addEventListener('paste', (e) => {
    e.preventDefault();
    const pastedData = (e.clipboardData || window.clipboardData).getData('text');
    const digits = pastedData.replace(/\D/g, '');
    
    if (digits.length === 6) {
      for (let i = 0; i < 6; i++) {
        otpInputs[i].value = digits[i];
      }
      otpInputs[5].focus();
    }
  });

  input.addEventListener('input', () => {
    input.value = input.value.replace(/\D/g, '');
    if (input.value.length > 1) {
      input.value = input.value.slice(0, 1);
    }
  });
});

// OTP Form Submission
const otpForm = document.getElementById('otpForm');
otpForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const otp = Array.from(otpInputs).map(input => input.value).join('');
  const submitBtn = otpForm.querySelector('button[type="submit"]');
  
  if (otp.length !== 6) {
    showNotification('Please enter the 6-digit code', 'error');
    return;
  }

  showLoading('Verifying OTP...');
  submitBtn.disabled = true;

  // Send OTP verification
  const formData = new FormData();
  formData.append('action', 'verify_otp');
  formData.append('email', userEmail);
  formData.append('otp', otp);

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    hideLoading();
    if (data.success) {
      showNotification('Email verified successfully! Redirecting...', 'success');
      clearInterval(otpTimerInterval);
      setTimeout(() => {
        window.location.href = '../home/index.html';
      }, 2000);
    } else {
      submitBtn.disabled = false;
      showNotification(data.message || 'Verification failed', 'error');
    }
  })
  .catch(error => {
    hideLoading();
    submitBtn.disabled = false;
    showNotification('An error occurred. Please try again.', 'error');
    console.error('Error:', error);
  });
});

// Resend OTP
document.getElementById('resendBtn').addEventListener('click', (e) => {
  e.preventDefault();
  
  const resendBtn = document.getElementById('resendBtn');
  showLoading('Sending new OTP...');
  resendBtn.disabled = true;

  const formData = new FormData();
  formData.append('action', 'resend_otp');
  formData.append('email', userEmail);

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    hideLoading();
    if (data.success) {
      showNotification('OTP sent to your email', 'success');
      // Clear previous OTP inputs
      otpInputs.forEach(input => input.value = '');
      otpInputs[0].focus();
      
      // Reset timer
      document.getElementById('resendBtn').disabled = true;
      startOTPTimer();
    } else {
      showNotification(data.message || 'Failed to resend OTP', 'error');
    }
  })
  .catch(error => {
    showNotification('An error occurred. Please try again.', 'error');
    console.error('Error:', error);
  });
});

// Close OTP Modal
document.getElementById('otpCloseBtn').addEventListener('click', closeOTPModal);

// Load remembered email if it exists
window.addEventListener('DOMContentLoaded', () => {
  const rememberedEmail = localStorage.getItem('rememberedEmail');
  if (rememberedEmail) {
    document.getElementById('login-email').value = rememberedEmail;
    document.querySelector('input[name="remember"]').checked = true;
  }
});

// Forgot Password Modal Functions
const forgotPasswordLink = document.querySelector('.forgot-password');
const forgotPasswordModal = document.getElementById('forgotPasswordModal');
const forgotPasswordCloseBtn = document.getElementById('forgotPasswordCloseBtn');
const backToLoginBtn = document.getElementById('backToLoginBtn');
const forgotPasswordForm = document.getElementById('forgotPasswordForm');

// Open forgot password modal
forgotPasswordLink.addEventListener('click', (e) => {
  e.preventDefault();
  forgotPasswordModal.classList.add('active');
});

// Close forgot password modal
forgotPasswordCloseBtn.addEventListener('click', () => {
  forgotPasswordModal.classList.remove('active');
});

backToLoginBtn.addEventListener('click', () => {
  forgotPasswordModal.classList.remove('active');
});

// Forgot password form submission
forgotPasswordForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const email = document.getElementById('forgot-email').value;
  const submitBtn = forgotPasswordForm.querySelector('button[type="submit"]');
  
  if (!email) {
    showNotification('Please enter your email address', 'error');
    return;
  }
  
  showLoading('Sending reset link...');
  submitBtn.disabled = true;
  
  const formData = new FormData();
  formData.append('action', 'forgot_password');
  formData.append('email', email);
  
  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    hideLoading();
    submitBtn.disabled = false;
    
    if (data.success) {
      showNotification(data.message, 'success');
      forgotPasswordModal.classList.remove('active');
      document.getElementById('forgot-email').value = '';
    } else {
      showNotification(data.message || 'Failed to send reset link', 'error');
    }
  })
  .catch(error => {
    hideLoading();
    submitBtn.disabled = false;
    showNotification('An error occurred. Please try again.', 'error');
    console.error('Error:', error);
  });
});

// Notification Function
function showNotification(message, type = 'success') {
  // Remove existing notification if any
  const existingNotification = document.querySelector('.notification');
  if (existingNotification) {
    existingNotification.remove();
  }

  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 30px;
    background: ${type === 'success' ? '#28a745' : '#dc3545'};
    color: #fff;
    padding: 16px 24px;
    border-radius: 4px;
    z-index: 10000;
    animation: slideIn 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    font-size: 14px;
  `;

  document.body.appendChild(notification);

  // Add CSS for animation if not already present
  if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
      @keyframes slideIn {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      @keyframes slideOut {
        from {
          transform: translateX(0);
          opacity: 1;
        }
        to {
          transform: translateX(400px);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
  }

  // Remove notification after 4 seconds
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 4000);
}

// Prevent form submission if validation fails (additional client-side checks)
const inputs = document.querySelectorAll('.auth-form input');
inputs.forEach((input) => {
  input.addEventListener('focus', function() {
    this.style.borderColor = 'var(--text-primary)';
  });

  input.addEventListener('blur', function() {
    if (!this.value) {
      this.style.borderColor = 'var(--border)';
    }
  });
});

console.log('Auth page loaded successfully! 🔐');
