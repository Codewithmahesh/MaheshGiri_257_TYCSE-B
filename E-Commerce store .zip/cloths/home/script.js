// Mobile Menu Toggle
const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
const navLinks = document.querySelector(".nav-links");

mobileMenuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("active");
  mobileMenuBtn.classList.toggle("active");

  // Animate hamburger icon
  const spans = mobileMenuBtn.querySelectorAll("span");
  if (mobileMenuBtn.classList.contains("active")) {
    spans[0].style.transform = "rotate(45deg) translate(5px, 5px)";
    spans[1].style.opacity = "0";
    spans[2].style.transform = "rotate(-45deg) translate(7px, -6px)";
  } else {
    spans[0].style.transform = "none";
    spans[1].style.opacity = "1";
    spans[2].style.transform = "none";
  }
});

// Category Tabs
const tabBtns = document.querySelectorAll(".tab-btn");
const categoryCards = document.querySelectorAll(".category-card");

// Initialize - hide men's cards on page load
function initializeCategory() {
  const activeTab = document.querySelector(".tab-btn.active");
  const activeCategory = activeTab.dataset.category;
  
  categoryCards.forEach((card) => {
    if (card.dataset.category !== activeCategory) {
      card.style.display = "none";
    } else {
      card.style.display = "block";
    }
  });
}

initializeCategory();

// Filter function
function filterByCategory(category) {
  categoryCards.forEach((card) => {
    const cardCategory = card.dataset.category;
    if (cardCategory === category) {
      card.style.display = "block";
      // Trigger animation
      setTimeout(() => {
        card.style.opacity = "1";
        card.style.transform = "scale(1)";
      }, 10);
    } else {
      card.style.opacity = "0";
      card.style.transform = "scale(0.95)";
      setTimeout(() => {
        card.style.display = "none";
      }, 300);
    }
  });
}

tabBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    // Remove active class from all tabs
    tabBtns.forEach((tab) => tab.classList.remove("active"));
    // Add active class to clicked tab
    btn.classList.add("active");

    // Get category
    const category = btn.dataset.category;

    // Filter category cards based on selected category
    filterByCategory(category);

    console.log(`Switched to ${category} category`);
  });
});

// Smooth Scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    const href = this.getAttribute("href");
    if (href !== "#" && document.querySelector(href)) {
      e.preventDefault();
      const target = document.querySelector(href);
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  });
});

// Newsletter Form Submission
const newsletterForms = document.querySelectorAll(
  ".newsletter-form, .footer-newsletter"
);

newsletterForms.forEach((form) => {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = form.querySelector('input[type="email"]').value;
    const checkbox = form.querySelector('input[type="checkbox"]').checked;

    if (email && checkbox) {
      alert(
        `Thank you for subscribing! A confirmation email has been sent to ${email}`
      );
      form.reset();
    } else if (!checkbox) {
      alert("Please confirm that you want to subscribe to our newsletter.");
    }
  });
});

// Add to Cart functionality for product cards
document.addEventListener('DOMContentLoaded', () => {
  // Add click handlers to all "Add to Cart" buttons
  const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
  
  addToCartButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const productCard = button.closest('.product-card');
      const productId = productCard.dataset.productId;
      const productName = productCard.querySelector('h3').textContent;
      
      // Create product object
      const product = {
        id: productId,
        name: productName
      };
      
      // Call shared addToCart function
      addToCart(product);
    });
  });
});



// Intersection Observer for scroll animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -100px 0px",
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1";
      entry.target.style.transform = "translateY(0)";
    }
  });
}, observerOptions);

// Observe elements for fade-in animation
const animateElements = document.querySelectorAll(
  ".product-card, .category-card"
);
animateElements.forEach((el) => {
  el.style.opacity = "0";
  el.style.transform = "translateY(30px)";
  el.style.transition = "opacity 0.6s ease, transform 0.6s ease";
  observer.observe(el);
});

// Navbar scroll effect
let lastScroll = 0;
const navbar = document.querySelector(".navbar");

window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset;

  if (currentScroll > 100) {
    navbar.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)";
  } else {
    navbar.style.boxShadow = "none";
  }

  lastScroll = currentScroll;
});

// Duplicate sale banner content for seamless loop
const saleBannerContent = document.querySelector(".sale-banner-content");
const bannerHTML = saleBannerContent.innerHTML;
saleBannerContent.innerHTML = bannerHTML + bannerHTML;

// Log page load
console.log("rnd.apparel website loaded successfully! 🎨");
console.log("All interactive features are ready.");

// Check user session and update navbar
function checkUserSession() {
  console.log('Starting checkUserSession...');
  const formData = new FormData();
  formData.append('action', 'check_session');

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => {
    console.log('Session check response status:', response.status);
    return response.json();
  })
  .then(data => {
    console.log('Session check data:', data);
    if (data.success && data.logged_in) {
      console.log('User is logged in, updating navbar...');
      updateNavbarForLoggedInUser(data.user);
      // Update cart count for logged-in user
      updateCartCount();
    } else {
      console.log('User is NOT logged in or session check failed');
    }
  })
  .catch(error => {
    console.error('Session check error:', error);
  });
}

// Update navbar to show user avatar
function updateNavbarForLoggedInUser(user) {
  console.log('Updating navbar for user:', user);
  const userLoginLink = document.getElementById('loginLink');
  
  if (userLoginLink) {
    console.log('Found login link, replacing with avatar');
    // Get user initials
    const initials = getUserInitials(user.name);
    
    // Create user avatar and dropdown
    const userAvatarHTML = `
      <div class="user-profile-container">
        <button class="user-avatar" id="userAvatarBtn" aria-label="User Menu">
          ${initials}
        </button>
        <div class="user-dropdown" id="userDropdown">
          <div class="user-dropdown-header">
            <div class="user-dropdown-avatar">${initials}</div>
            <div class="user-dropdown-info">
              <p class="user-dropdown-name">${user.name}</p>
              <p class="user-dropdown-email">${user.email}</p>
            </div>
          </div>
          <div class="user-dropdown-divider"></div>
          <a href="../profile/index.html" class="user-dropdown-item">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            Edit Profile
          </a>
          <button class="user-dropdown-item" id="logoutBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Logout
          </button>
        </div>
      </div>
    `;
    
    userLoginLink.outerHTML = userAvatarHTML;
    
    // Add event listeners
    setupUserDropdown();
  } else {
    console.error('Login link element not found!');
  }
}

// Get user initials from name
function getUserInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return parts[0][0].toUpperCase();
}

// Setup user dropdown functionality
function setupUserDropdown() {
  const avatarBtn = document.getElementById('userAvatarBtn');
  const dropdown = document.getElementById('userDropdown');
  const logoutBtn = document.getElementById('logoutBtn');
  
  if (avatarBtn && dropdown) {
    // Toggle dropdown
    avatarBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('active');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!avatarBtn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
      }
    });
  }
  
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      const formData = new FormData();
      formData.append('action', 'logout');
      
      fetch('../api/user_auth.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          showNotification('Logged out successfully!');
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        }
      })
      .catch(error => {
        console.error('Logout error:', error);
      });
    });
  }
}

// Check session on page load - wait for DOM to be ready
document.addEventListener('DOMContentLoaded', () => {
  checkUserSession();
});
