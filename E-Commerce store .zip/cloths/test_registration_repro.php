<?php
$url = 'http://localhost/cloths/api/user_auth.php';
$data = [
    'action' => 'user_register',
    'name' => 'Test User',
    'email' => 'test_' . time() . '@example.com',
    'password' => 'password123',
    'confirmPassword' => 'password123',
    'phone' => '1234567890',
    'address' => '123 Test St',
    'city' => 'Test City',
    'state' => 'Test State',
    'zip_code' => '12345',
    'country' => 'Test Country'
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_HEADER, false); // Disable headers to see body clearly

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

file_put_contents('repro_output.txt', $response);

echo "HTTP Code: $httpCode\n";
echo "Response saved to repro_output.txt\n";
?>
