# Quick Mailtrap Setup (2 minutes)

## Why Mailtrap?
- **Free** (test plan)
- **Works on Windows XAMPP** without any configuration
- **Catches all emails** in a web inbox
- **Perfect for testing** email verification

## Setup Steps:

### Step 1: Create Mailtrap Account
1. Go to https://mailtrap.io
2. Click "Sign Up"
3. Fill in your email and password
4. Verify your email
5. You're done with signup!

### Step 2: Create Inbox
1. Once logged in, you'll see "Inboxes"
2. Click "Create Inbox" or "Add Inbox"
3. Name it: `rnd-apparel`
4. Click Create

### Step 3: Get Your API Token
1. Click on your inbox name
2. Go to **Settings** tab (or gear icon)
3. Look for **API Token** section
4. You'll see a token like: `abc123def456ghi789`
5. **Copy this token**

### Step 4: Configure Your App
1. Open: `C:\xampp\htdocs\cloths\config\email_config.php`
2. Find this line:
   ```php
   define('MAILTRAP_API_TOKEN', 'your-mailtrap-token');
   ```
3. Replace `your-mailtrap-token` with your actual token
4. Save the file

### Step 5: Test It!
1. Go to: http://localhost/cloths/auth/index.html
2. Register with any email
3. Go back to Mailtrap (https://mailtrap.io)
4. Click on your inbox
5. **You should see your OTP email!**

## Check Your Email
In Mailtrap inbox, you can:
- View the full HTML email
- See the OTP code
- Check headers
- Preview how it looks

That's it! Emails will now work perfectly.

---

## Troubleshooting

**Q: I don't see the email in Mailtrap**
- Check if API token is correct (copy-paste again)
- Make sure EMAIL_PROVIDER is set to 'mailtrap' in email_config.php
- Clear browser cache (Ctrl+F5)
- Try registering again

**Q: API token format is wrong**
- Mailtrap tokens are long strings (50+ characters)
- Copy the entire token from the Mailtrap Settings page
- Don't add quotes or extra spaces

**Q: How do I see the OTP code?**
- In Mailtrap, click on the email in your inbox
- Look for the HTML body
- You'll see: `<div class="otp-code">123456</div>`
- That's your OTP code!

