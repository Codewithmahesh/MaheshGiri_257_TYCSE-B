# Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Create Database (2 min)
1. Open http://localhost/phpmyadmin
2. Click **SQL** tab
3. Open file: `cloths/database/cloths_db.sql`
4. Copy entire content and paste in phpMyAdmin
5. Click **Go**

✅ Database created!

### Step 2: Test User Registration (2 min)
1. Go to: http://localhost/cloths/auth/index.html
2. Click **Register here**
3. Fill in:
   - Name: Test User
   - Email: test@example.com
   - Password: Password123
   - Confirm: Password123
4. Check ✓ Terms
5. Click **Create Account**

✅ User registered! Redirects to home.

### Step 3: Test User Login (1 min)
1. Go to: http://localhost/cloths/auth/index.html
2. Click **Log In** (default tab)
3. Enter:
   - Email: test@example.com
   - Password: Password123
4. Click **Log In**

✅ User logged in! Redirects to home.

---

## 🔐 Admin Setup

### Create Admin User in Database
1. Open phpMyAdmin
2. Click **cloths_db** database
3. Click **admins** table
4. Click **Insert**
5. Fill in:
   - Name: Admin User
   - Email: admin@cloths.local
   - Password: Use PHP to hash (see below)
   - Role: super_admin
   - is_active: 1

**To get hashed password:**
Create a file `hash.php` in any folder with:
```php
<?php echo password_hash('yourpassword', PASSWORD_BCRYPT); ?>
```
Visit it in browser, copy output, paste as password.

### Test Admin Login
1. Go to: http://localhost/cloths/admin/login.html
2. Enter admin email and password
3. Click **Login to Dashboard**

---

## 📁 Project Files Overview

| File | Purpose |
|------|---------|
| `config/db_config.php` | Database connection settings |
| `api/user_auth.php` | User login/register API |
| `api/admin_auth.php` | Admin login/register API |
| `auth/index.html` | User login/register page |
| `admin/login.html` | Admin login page |
| `database/cloths_db.sql` | Database schema |

---

## 🔑 API Endpoints Cheat Sheet

### User Login
```
POST /api/user_auth.php
Data: action=user_login&email=test@example.com&password=Password123
```

### User Register
```
POST /api/user_auth.php
Data: action=user_register&name=John&email=john@example.com&password=Pass123&confirmPassword=Pass123
```

### User Logout
```
POST /api/user_auth.php
Data: action=logout
```

### Check User Session
```
POST /api/user_auth.php
Data: action=check_session
```

### Admin Login
```
POST /api/admin_auth.php
Data: action=admin_login&email=admin@cloths.local&password=adminpass
```

### Admin Logout
```
POST /api/admin_auth.php
Data: action=logout
```

---

## 🗂️ Database Tables Summary

| Table | Purpose |
|-------|---------|
| **users** | Customer accounts |
| **admins** | Admin/staff accounts |
| **products** | Product catalog |
| **orders** | Customer orders |
| **order_items** | Items in orders |
| **cart** | Shopping cart items |
| **wishlist** | User wishlists |
| **reviews** | Product reviews |

---

## 🛠️ Config File Location
`cloths/config/db_config.php`

Current settings:
- Host: localhost
- User: root
- Password: (empty)
- Database: cloths_db

Change here if needed.

---

## 📝 Default Credentials (after setup)

**User Account:**
- Email: test@example.com
- Password: Password123

**Admin Account:**
- Email: admin@cloths.local
- Password: (create your own, see admin setup above)

---

## 🚀 Next Features to Build

1. **Admin Dashboard** - View stats, manage products, orders
2. **Product Management** - Add/Edit/Delete products
3. **Order Management** - Process orders, track shipments
4. **User Profile** - Edit profile, view order history
5. **Payment Gateway** - Stripe/PayPal integration
6. **Email Verification** - Send verification emails
7. **Password Reset** - Forgot password feature
8. **Search & Filter** - Product search, category filter
9. **Reviews System** - User product reviews
10. **Analytics** - Sales reports, user analytics

---

## ✅ Checklist

- [ ] Database created (cloths_db)
- [ ] Test user created and login working
- [ ] Admin user created
- [ ] Admin login working
- [ ] API endpoints responding correctly
- [ ] Sessions saving properly
- [ ] Ready for next phase!

---

## 🐛 Troubleshooting

**"Connection failed"** in API
- Check `config/db_config.php` settings
- Ensure MySQL is running in XAMPP
- Check database name matches

**"Invalid email or password"**
- Verify user exists in database
- Check email is correct
- Ensure password is correct

**Redirect not working**
- Check browser console for errors
- Verify API response is JSON
- Check session is created properly

**Can't find phpmyadmin**
- Start Apache and MySQL in XAMPP
- Go to http://localhost/phpmyadmin

---

Good luck! 🎉
