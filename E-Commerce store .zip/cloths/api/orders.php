<?php
// API Endpoint for Order Management
header('Content-Type: application/json');
session_start();
require_once '../config/db_config.php';

// Check user authentication
function checkUserAuth() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'User not logged in']);
        exit;
    }
    return $_SESSION['user_id'];
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Place order
if ($action === 'place_order') {
    $user_id = checkUserAuth();
    
    // Get selected cart items from request
    $selected_items = json_decode($_POST['selected_items'] ?? '[]', true);
    
    if (empty($selected_items)) {
        echo json_encode(['success' => false, 'message' => 'No items selected']);
        exit;
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Calculate total
        $total_amount = 0;
        $order_items = [];
        
        foreach ($selected_items as $cart_id) {
            // Get cart item details
            $query = "SELECT c.*, p.name, p.price, p.discount_percentage, p.stock_quantity 
                     FROM cart c 
                     JOIN products p ON c.product_id = p.id 
                     WHERE c.id = ? AND c.user_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ii", $cart_id, $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                // Check stock
                if ($row['stock_quantity'] < $row['quantity']) {
                    throw new Exception("Insufficient stock for " . $row['name']);
                }
                
                // Calculate price
                $price = $row['price'];
                if ($row['discount_percentage'] > 0) {
                    $price = $price * (1 - $row['discount_percentage'] / 100);
                }
                
                $item_total = $price * $row['quantity'];
                $total_amount += $item_total;
                
                $order_items[] = [
                    'product_id' => $row['product_id'],
                    'product_name' => $row['name'],
                    'quantity' => $row['quantity'],
                    'price' => $price,
                    'cart_id' => $cart_id
                ];
            }
        }
        
        // Create order
        $order_query = "INSERT INTO orders (user_id, total_amount, status, payment_method, shipping_address, created_at) 
                       VALUES (?, ?, 'pending', 'pending', 'User Address', NOW())";
        $order_stmt = $conn->prepare($order_query);
        $order_stmt->bind_param("id", $user_id, $total_amount);
        $order_stmt->execute();
        $order_id = $conn->insert_id;
        
        // Create order items
        foreach ($order_items as $item) {
            $item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $item_stmt = $conn->prepare($item_query);
            $item_stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
            $item_stmt->execute();
            
            // Update product stock
            $stock_query = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?";
            $stock_stmt = $conn->prepare($stock_query);
            $stock_stmt->bind_param("ii", $item['quantity'], $item['product_id']);
            $stock_stmt->execute();
            
            // Remove from cart
            $cart_delete = "DELETE FROM cart WHERE id = ?";
            $cart_stmt = $conn->prepare($cart_delete);
            $cart_stmt->bind_param("i", $item['cart_id']);
            $cart_stmt->execute();
        }
        
        // Commit transaction
        $conn->commit();
        
        // Get user email
        $user_query = "SELECT name, email FROM users WHERE id = ?";
        $user_stmt = $conn->prepare($user_query);
        $user_stmt->bind_param("i", $user_id);
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        $user = $user_result->fetch_assoc();
        
        // Send confirmation email (wrapped in try-catch to not fail the order)
        try {
            if (file_exists(__DIR__ . '/email_service.php')) {
                require_once __DIR__ . '/email_service.php';
                $emailService = new EmailService();
                
                $email_body = generateOrderConfirmationEmail($order_id, $user['name'], $order_items, $total_amount);
                
                $emailService->sendEmail(
                    $user['email'],
                    $user['name'],
                    'Order Confirmation - Order #' . $order_id,
                    $email_body
                );
            }
        } catch (Exception $e) {
            // Log email error but don't fail the order
            error_log("Failed to send order confirmation email: " . $e->getMessage());
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Order placed successfully',
            'order_id' => $order_id,
            'total' => $total_amount
        ]);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Generate order confirmation email HTML
function generateOrderConfirmationEmail($order_id, $customer_name, $items, $total) {
    $items_html = '';
    foreach ($items as $item) {
        $items_html .= "
            <tr>
                <td style='padding: 10px; border-bottom: 1px solid #eee;'>{$item['product_name']}</td>
                <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: center;'>{$item['quantity']}</td>
                <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: right;'>$" . number_format($item['price'], 2) . "</td>
                <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: right;'>$" . number_format($item['price'] * $item['quantity'], 2) . "</td>
            </tr>
        ";
    }
    
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #000; color: #fff; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f5f5f5; }
            .order-details { background: #fff; padding: 20px; margin: 20px 0; }
            table { width: 100%; border-collapse: collapse; }
            th { background: #f5f5f5; padding: 10px; text-align: left; }
            .total { font-size: 18px; font-weight: bold; margin-top: 20px; text-align: right; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>rnd.apparel</h1>
            </div>
            <div class='content'>
                <h2>Order Confirmation</h2>
                <p>Hi {$customer_name},</p>
                <p>Thank you for your order! We're excited to get your items to you.</p>
                
                <div class='order-details'>
                    <h3>Order #" . $order_id . "</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th style='text-align: center;'>Quantity</th>
                                <th style='text-align: right;'>Price</th>
                                <th style='text-align: right;'>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            {$items_html}
                        </tbody>
                    </table>
                    <div class='total'>
                        Total: $" . number_format($total, 2) . "
                    </div>
                </div>
                
                <p>We'll send you another email when your order ships.</p>
                <p>Thank you for shopping with us!</p>
                <p>Best regards,<br>The rnd.apparel Team</p>
            </div>
        </div>
    </body>
    </html>
    ";
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
