<?php
// Quick diagnostic page to check products
require_once '../config/db_config.php';

echo "<h1>Product Diagnostic</h1>";
echo "<style>table { border-collapse: collapse; width: 100%; } th, td { border: 1px solid #ddd; padding: 8px; text-align: left; } th { background: #000; color: white; } .inactive { background: #ffcccc; } .active { background: #ccffcc; }</style>";

// Get all products
$query = "SELECT id, name, category, price, stock_quantity, is_active, created_at FROM products ORDER BY id DESC";
$result = $conn->query($query);

echo "<h2>All Products in Database (" . $result->num_rows . " total)</h2>";
echo "<table>";
echo "<tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Active?</th><th>Created</th></tr>";

while ($row = $result->fetch_assoc()) {
    $class = $row['is_active'] == 1 ? 'active' : 'inactive';
    echo "<tr class='$class'>";
    echo "<td>{$row['id']}</td>";
    echo "<td>{$row['name']}</td>";
    echo "<td>{$row['category']}</td>";
    echo "<td>\${$row['price']}</td>";
    echo "<td>{$row['stock_quantity']}</td>";
    echo "<td>" . ($row['is_active'] == 1 ? '✅ YES' : '❌ NO') . "</td>";
    echo "<td>{$row['created_at']}</td>";
    echo "</tr>";
}

echo "</table>";

echo "<h3>Legend:</h3>";
echo "<p><span style='background: #ccffcc; padding: 5px;'>Green = Active (will show on site)</span></p>";
echo "<p><span style='background: #ffcccc; padding: 5px;'>Red = Inactive (will NOT show on site)</span></p>";

echo "<h3>Category Format Guide:</h3>";
echo "<ul>";
echo "<li><strong>Women's products:</strong> women_tops, women_bottoms, women_accessories</li>";
echo "<li><strong>Men's products:</strong> men_tops, men_bottoms, men_accessories</li>";
echo "</ul>";

echo "<h3>To Fix Inactive Products:</h3>";
echo "<p>Go to Admin Dashboard → Products → Edit the product → Set 'Active' to YES → Save</p>";
?>
