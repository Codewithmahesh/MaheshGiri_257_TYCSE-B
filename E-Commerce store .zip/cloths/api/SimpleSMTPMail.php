<?php
/**
 * Simple SMTP Mail Handler for Gmail
 * Works on Windows XAMPP without external dependencies
 */

class SimpleSMTPMail {
    private $host = 'smtp.gmail.com';
    private $port = 587;
    private $username;
    private $password;
    private $timeout = 30;
    
    public function __construct($username, $password) {
        $this->username = $username;
        $this->password = $password;
    }
    
    public function send($to, $subject, $htmlBody, $fromName = 'rnd.apparel') {
        try {
            // Connect
            $socket = @fsockopen($this->host, $this->port, $errno, $errstr, $this->timeout);
            
            if (!$socket) {
                error_log("SMTP Connection failed: $errstr ($errno)");
                return false;
            }
            
            // Read welcome message
            $response = fgets($socket, 1024);
            if (strpos($response, '220') === false) {
                fclose($socket);
                return false;
            }
            
            // Send EHLO
            fputs($socket, "EHLO " . gethostname() . "\r\n");
            $response = fgets($socket, 1024);
            
            // Read EHLO response
            while (substr($response, 3, 1) === '-') {
                $response = fgets($socket, 1024);
            }
            
            // Start TLS
            fputs($socket, "STARTTLS\r\n");
            $response = fgets($socket, 1024);
            if (strpos($response, '220') === false) {
                fclose($socket);
                error_log("STARTTLS failed: $response");
                return false;
            }
            
            // Enable TLS encryption
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                fclose($socket);
                error_log("TLS encryption failed");
                return false;
            }
            
            // Send EHLO again after TLS
            fputs($socket, "EHLO " . gethostname() . "\r\n");
            $response = fgets($socket, 1024);
            
            // Read EHLO response
            while (substr($response, 3, 1) === '-') {
                $response = fgets($socket, 1024);
            }
            
            // Authenticate
            fputs($socket, "AUTH LOGIN\r\n");
            $response = fgets($socket, 1024);
            
            // Send username (base64)
            fputs($socket, base64_encode($this->username) . "\r\n");
            $response = fgets($socket, 1024);
            
            // Send password (base64)
            fputs($socket, base64_encode($this->password) . "\r\n");
            $response = fgets($socket, 1024);
            
            if (strpos($response, '235') === false) {
                fclose($socket);
                error_log("Authentication failed: $response");
                return false;
            }
            
            // Send MAIL FROM
            fputs($socket, "MAIL FROM:<" . $this->username . ">\r\n");
            $response = fgets($socket, 1024);
            
            // Send RCPT TO
            fputs($socket, "RCPT TO:<" . $to . ">\r\n");
            $response = fgets($socket, 1024);
            
            if (strpos($response, '250') === false) {
                fclose($socket);
                error_log("RCPT TO failed: $response");
                return false;
            }
            
            // Send DATA
            fputs($socket, "DATA\r\n");
            $response = fgets($socket, 1024);
            
            // Build message
            $message = "From: " . $fromName . " <" . $this->username . ">\r\n";
            $message .= "To: <" . $to . ">\r\n";
            $message .= "Subject: " . $subject . "\r\n";
            $message .= "MIME-Version: 1.0\r\n";
            $message .= "Content-Type: text/html; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n";
            $message .= "\r\n";
            $message .= $htmlBody . "\r\n";
            $message .= "\r\n.\r\n";
            
            // Send message
            fputs($socket, $message);
            $response = fgets($socket, 1024);
            
            if (strpos($response, '250') === false) {
                fclose($socket);
                error_log("Message send failed: $response");
                return false;
            }
            
            // Send QUIT
            fputs($socket, "QUIT\r\n");
            fclose($socket);
            
            return true;
        } catch (Exception $e) {
            error_log("SMTP Exception: " . $e->getMessage());
            return false;
        }
    }
}
