<?php
// API Endpoint for Cart Management
header('Content-Type: application/json');
session_start();
require_once '../config/db_config.php';

// Check user authentication
function checkUserAuth() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'User not logged in', 'logged_in' => false]);
        exit;
    }
    return $_SESSION['user_id'];
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Get cart items
if ($action === 'get_cart') {
    if (!$user_id) {
        echo json_encode(['success' => true, 'cart_items' => [], 'count' => 0]);
        exit;
    }

    $query = "SELECT c.id, c.product_id, c.quantity, p.name, p.price, p.image_url, p.discount_percentage 
              FROM cart c 
              JOIN products p ON c.product_id = p.id 
              WHERE c.user_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $cart_items = [];
    $count = 0;
    
    while ($row = $result->fetch_assoc()) {
        $cart_items[] = $row;
        $count += $row['quantity'];
    }
    
    echo json_encode(['success' => true, 'cart_items' => $cart_items, 'count' => $count]);
    exit;
}

// Add to cart
if ($action === 'add_to_cart') {
    $user_id = checkUserAuth();
    
    $product_id = $_POST['product_id'] ?? 0;
    $quantity = $_POST['quantity'] ?? 1;
    
    if (!$product_id) {
        echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
        exit;
    }
    
    // Check if product exists in cart
    $check_query = "SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update quantity
        $row = $result->fetch_assoc();
        $new_quantity = $row['quantity'] + $quantity;
        
        $update_query = "UPDATE cart SET quantity = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("ii", $new_quantity, $row['id']);
        
        if ($update_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Cart updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update cart']);
        }
    } else {
        // Insert new item
        $insert_query = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bind_param("iii", $user_id, $product_id, $quantity);
        
        if ($insert_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Item added to cart']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add item to cart']);
        }
    }
    exit;
}

// Update quantity
if ($action === 'update_quantity') {
    $user_id = checkUserAuth();
    
    $cart_id = $_POST['cart_id'] ?? 0;
    $quantity = $_POST['quantity'] ?? 1;
    
    if (!$cart_id || $quantity < 1) {
        echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
        exit;
    }
    
    $query = "UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $quantity, $cart_id, $user_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Quantity updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update quantity']);
    }
    exit;
}

// Remove from cart
if ($action === 'remove_from_cart') {
    $user_id = checkUserAuth();
    
    $cart_id = $_POST['cart_id'] ?? 0;
    
    if (!$cart_id) {
        echo json_encode(['success' => false, 'message' => 'Invalid cart ID']);
        exit;
    }
    
    $query = "DELETE FROM cart WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $cart_id, $user_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Item removed from cart']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to remove item']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
