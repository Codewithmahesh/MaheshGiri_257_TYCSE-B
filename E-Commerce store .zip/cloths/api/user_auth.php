<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_start();

require_once '../config/db_config.php';
require_once 'email_service.php';

// Debug logging
function logDebug($message) {
    $logFile = __DIR__ . '/../logs/debug_auth.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

$action = $_POST['action'] ?? '';
logDebug("Action received: $action");

// User Login
if ($action === 'user_login') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $remember_me = isset($_POST['remember_me']) && $_POST['remember_me'] === 'true';

    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }

    // Check if user exists
    $query = "SELECT id, name, email, password FROM users WHERE email = ? AND is_active = 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }

    $user = $result->fetch_assoc();

    // Verify password
    if (!password_verify($password, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }

    // Set session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_type'] = 'user';

    // Handle remember me
    if ($remember_me) {
        // Generate secure token
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+30 days'));

        // Store token in database
        $token_query = "INSERT INTO remember_me_tokens (user_id, token, expires_at) VALUES (?, ?, ?)";
        $token_stmt = $conn->prepare($token_query);
        $token_stmt->bind_param("iss", $user['id'], $token, $expires_at);
        $token_stmt->execute();

        // Set cookie (30 days)
        setcookie('remember_me_token', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true);
    }

    echo json_encode(['success' => true, 'message' => 'Login successful', 'redirect' => '../home/index.html']);
    exit;
}

// User Registration
if ($action === 'user_register') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirmPassword'] ?? '');
    
    // Optional fields
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $zip_code = trim($_POST['zip_code'] ?? '');
    $country = trim($_POST['country'] ?? '');

    // Validation
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        echo json_encode(['success' => false, 'message' => 'Name, email, and password are required']);
        exit;
    }

    if ($password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
        exit;
    }

    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }

    // Check if email already exists
    logDebug("Checking if email exists: $email");
    $check_query = "SELECT id FROM users WHERE email = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        logDebug("Email already exists");
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert user with email_verified = 0
    logDebug("Inserting user into database");
    $insert_query = "INSERT INTO users (name, email, password, phone, address, city, state, zip_code, country, email_verified) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
    $insert_stmt = $conn->prepare($insert_query);
    
    if (!$insert_stmt) {
        logDebug("Prepare failed: " . $conn->error);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        exit;
    }

    $insert_stmt->bind_param("sssssssss", $name, $email, $hashed_password, $phone, $address, $city, $state, $zip_code, $country);

    if ($insert_stmt->execute()) {
        $user_id = $insert_stmt->insert_id;
        logDebug("User inserted with ID: $user_id");

        // Generate OTP (6-digit code)
        $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $expires_at = date('Y-m-d H:i:s', strtotime('+3 minutes'));

        // Store OTP in database
        $otp_query = "INSERT INTO otp_verifications (user_id, email, otp_code, expires_at) VALUES (?, ?, ?, ?)";
        $otp_stmt = $conn->prepare($otp_query);
        $otp_stmt->bind_param("isss", $user_id, $email, $otp, $expires_at);
        
        if ($otp_stmt->execute()) {
            // Send OTP email
            logDebug("Sending OTP email to $email");
            $emailService = new EmailService();
            $emailSent = $emailService->sendOTPEmail($email, $name, $otp);
            logDebug("Email sent result: " . ($emailSent ? 'true' : 'false'));

            // Set session (account created but not verified)
            $_SESSION['user_id'] = $user_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_type'] = 'user';
            $_SESSION['pending_verification'] = true;

            echo json_encode([
                'success' => true, 
                'message' => $emailSent ? 'Account created! OTP sent to your email.' : 'Account created! Please verify with OTP.',
                'user_id' => $user_id,
                'email' => $email,
                'email_sent' => $emailSent
            ]);
        } else {
            logDebug("Failed to store OTP: " . $conn->error);
            echo json_encode(['success' => false, 'message' => 'Failed to generate OTP. Please try again.']);
        }
    } else {
        logDebug("Failed to insert user: " . $insert_stmt->error);
        echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
    }
    exit;
}

// Verify OTP
if ($action === 'verify_otp') {
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');

    if (empty($email) || empty($otp)) {
        echo json_encode(['success' => false, 'message' => 'Email and OTP are required']);
        exit;
    }

    // Find user
    $user_query = "SELECT id, name FROM users WHERE email = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bind_param("s", $email);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();

    if ($user_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    $user = $user_result->fetch_assoc();
    $user_id = $user['id'];
    $user_name = $user['name'];

    // Check OTP
    $otp_query = "SELECT id, otp_code, expires_at, attempts FROM otp_verifications 
                  WHERE user_id = ? AND email = ? AND is_verified = 0
                  ORDER BY created_at DESC LIMIT 1";
    $otp_stmt = $conn->prepare($otp_query);
    $otp_stmt->bind_param("is", $user_id, $email);
    $otp_stmt->execute();
    $otp_result = $otp_stmt->get_result();

    if ($otp_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'No active OTP found']);
        exit;
    }

    $otp_record = $otp_result->fetch_assoc();
    $otp_id = $otp_record['id'];
    $stored_otp = $otp_record['otp_code'];
    $expires_at = $otp_record['expires_at'];
    $attempts = $otp_record['attempts'];

    // Check if OTP has expired
    if (strtotime($expires_at) < time()) {
        echo json_encode(['success' => false, 'message' => 'OTP has expired. Please request a new one.']);
        exit;
    }

    // Check attempts
    if ($attempts >= 3) {
        echo json_encode(['success' => false, 'message' => 'Too many attempts. Please request a new OTP.']);
        exit;
    }

    // Verify OTP
    if ($otp !== $stored_otp) {
        // Increment attempts
        $update_attempts = "UPDATE otp_verifications SET attempts = attempts + 1 WHERE id = ?";
        $update_stmt = $conn->prepare($update_attempts);
        $update_stmt->bind_param("i", $otp_id);
        $update_stmt->execute();

        echo json_encode(['success' => false, 'message' => 'Invalid OTP. Please try again.']);
        exit;
    }

    // Mark OTP as verified and update user email_verified flag
    $update_otp = "UPDATE otp_verifications SET is_verified = 1 WHERE id = ?";
    $update_otp_stmt = $conn->prepare($update_otp);
    $update_otp_stmt->bind_param("i", $otp_id);
    $update_otp_stmt->execute();

    $update_user = "UPDATE users SET email_verified = 1 WHERE id = ?";
    $update_user_stmt = $conn->prepare($update_user);
    $update_user_stmt->bind_param("i", $user_id);
    $update_user_stmt->execute();

    // Send welcome email
    $emailService = new EmailService();
    $emailService->sendWelcomeEmail($email, $user_name);

    // Update session
    $_SESSION['email_verified'] = true;
    unset($_SESSION['pending_verification']);

    echo json_encode(['success' => true, 'message' => 'Email verified successfully!']);
    exit;
}

// Resend OTP
if ($action === 'resend_otp') {
    $email = trim($_POST['email'] ?? '');

    if (empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Email is required']);
        exit;
    }

    // Find user
    $user_query = "SELECT id, name FROM users WHERE email = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bind_param("s", $email);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();

    if ($user_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    $user = $user_result->fetch_assoc();
    $user_id = $user['id'];
    $user_name = $user['name'];

    // Generate new OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires_at = date('Y-m-d H:i:s', strtotime('+3 minutes'));

    // Insert new OTP record
    $otp_query = "INSERT INTO otp_verifications (user_id, email, otp_code, expires_at) VALUES (?, ?, ?, ?)";
    $otp_stmt = $conn->prepare($otp_query);
    $otp_stmt->bind_param("isss", $user_id, $email, $otp, $expires_at);

    if ($otp_stmt->execute()) {
        // Send OTP email
        $emailService = new EmailService();
        $emailSent = $emailService->sendOTPEmail($email, $user_name, $otp);

        echo json_encode([
            'success' => true, 
            'message' => 'OTP sent to your email',
            'email_sent' => $emailSent
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to generate new OTP']);
    }
    exit;
}

// Logout
if ($action === 'logout') {
    // Delete remember me token if exists
    if (isset($_COOKIE['remember_me_token'])) {
        $token = $_COOKIE['remember_me_token'];
        
        // Delete from database
        $delete_query = "DELETE FROM remember_me_tokens WHERE token = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("s", $token);
        $delete_stmt->execute();
        
        // Clear cookie
        setcookie('remember_me_token', '', time() - 3600, '/');
    }
    
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
    exit;
}

// Check if user is logged in
if ($action === 'check_session') {
    // First check session
    if (isset($_SESSION['user_id'])) {
        echo json_encode(['success' => true, 'logged_in' => true, 'user' => [
            'id' => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'],
            'email' => $_SESSION['user_email'],
            'email_verified' => isset($_SESSION['email_verified']) ? $_SESSION['email_verified'] : false
        ]]);
        exit;
    }

    // Check remember me cookie if session doesn't exist
    if (isset($_COOKIE['remember_me_token'])) {
        $token = $_COOKIE['remember_me_token'];

        // Verify token in database
        $query = "SELECT rt.user_id, u.name, u.email, rt.expires_at 
                  FROM remember_me_tokens rt
                  JOIN users u ON rt.user_id = u.id
                  WHERE rt.token = ? AND u.is_active = 1
                  ORDER BY rt.created_at DESC LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $token_data = $result->fetch_assoc();

            // Check if token has expired
            if (strtotime($token_data['expires_at']) > time()) {
                // Token is valid, create session
                $_SESSION['user_id'] = $token_data['user_id'];
                $_SESSION['user_name'] = $token_data['name'];
                $_SESSION['user_email'] = $token_data['email'];
                $_SESSION['user_type'] = 'user';

                echo json_encode(['success' => true, 'logged_in' => true, 'user' => [
                    'id' => $token_data['user_id'],
                    'name' => $token_data['name'],
                    'email' => $token_data['email'],
                    'email_verified' => true
                ]]);
                exit;
            } else {
                // Token expired, delete it and clear cookie
                $delete_query = "DELETE FROM remember_me_tokens WHERE token = ?";
                $delete_stmt = $conn->prepare($delete_query);
                $delete_stmt->bind_param("s", $token);
                $delete_stmt->execute();
                setcookie('remember_me_token', '', time() - 3600, '/');
            }
        }
    }

    echo json_encode(['success' => true, 'logged_in' => false]);
    exit;
}

// Forgot Password - Send reset link
if ($action === 'forgot_password') {
    $email = trim($_POST['email'] ?? '');

    if (empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Email is required']);
        exit;
    }

    // Check if user exists
    $user_query = "SELECT id, name FROM users WHERE email = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bind_param("s", $email);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();

    if ($user_result->num_rows === 0) {
        // Don't reveal if email exists or not for security
        echo json_encode(['success' => true, 'message' => 'If this email exists, a password reset link has been sent']);
        exit;
    }

    $user = $user_result->fetch_assoc();
    $user_id = $user['id'];
    $user_name = $user['name'];

    // Generate secure token
    $token = bin2hex(random_bytes(32));
    $expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));

    // Store token in database
    $token_query = "INSERT INTO password_reset_tokens (user_id, email, token, expires_at) VALUES (?, ?, ?, ?)";
    $token_stmt = $conn->prepare($token_query);
    $token_stmt->bind_param("isss", $user_id, $email, $token, $expires_at);

    if ($token_stmt->execute()) {
        // Send reset email
        $resetLink = "http://" . $_SERVER['HTTP_HOST'] . "/cloths/auth/reset-password.html?token=" . $token;
        $emailService = new EmailService();
        $emailSent = $emailService->sendPasswordResetEmail($email, $user_name, $resetLink);

        echo json_encode([
            'success' => true,
            'message' => 'Password reset link has been sent to your email',
            'email_sent' => $emailSent
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to generate reset link. Please try again.']);
    }
    exit;
}

// Verify Reset Token
if ($action === 'verify_reset_token') {
    $token = trim($_POST['token'] ?? '');

    if (empty($token)) {
        echo json_encode(['success' => false, 'message' => 'Token is required']);
        exit;
    }

    // Check if token exists and is valid
    $query = "SELECT id, user_id, email, expires_at, is_used FROM password_reset_tokens 
              WHERE token = ? AND is_used = 0";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired reset link']);
        exit;
    }

    $reset_record = $result->fetch_assoc();

    // Check if token has expired
    if (strtotime($reset_record['expires_at']) < time()) {
        echo json_encode(['success' => false, 'message' => 'Reset link has expired. Please request a new one.']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'Token is valid', 'email' => $reset_record['email']]);
    exit;
}

// Reset Password
if ($action === 'reset_password') {
    $token = trim($_POST['token'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (empty($token) || empty($new_password) || empty($confirm_password)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }

    if ($new_password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
        exit;
    }

    if (strlen($new_password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
        exit;
    }

    // Verify token
    $query = "SELECT id, user_id, email, expires_at, is_used FROM password_reset_tokens 
              WHERE token = ? AND is_used = 0";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired reset link']);
        exit;
    }

    $reset_record = $result->fetch_assoc();

    // Check if token has expired
    if (strtotime($reset_record['expires_at']) < time()) {
        echo json_encode(['success' => false, 'message' => 'Reset link has expired. Please request a new one.']);
        exit;
    }

    // Hash new password
    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

    // Update user password
    $update_query = "UPDATE users SET password = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("si", $hashed_password, $reset_record['user_id']);

    if ($update_stmt->execute()) {
        // Mark token as used
        $mark_used = "UPDATE password_reset_tokens SET is_used = 1 WHERE id = ?";
        $mark_stmt = $conn->prepare($mark_used);
        $mark_stmt->bind_param("i", $reset_record['id']);
        $mark_stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Password reset successfully! You can now login with your new password.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to reset password. Please try again.']);
    }
    exit;
}

// Update Profile
if ($action === 'update_profile') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not logged in']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $zip_code = trim($_POST['zip_code'] ?? '');
    $country = trim($_POST['country'] ?? '');

    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => 'Name is required']);
        exit;
    }

    // Update user profile
    $update_query = "UPDATE users SET name = ?, phone = ?, address = ?, city = ?, state = ?, zip_code = ?, country = ? 
                     WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sssssssi", $name, $phone, $address, $city, $state, $zip_code, $country, $user_id);

    if ($update_stmt->execute()) {
        // Update session
        $_SESSION['user_name'] = $name;

        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update profile']);
    }
    exit;
}

// Change Password (when logged in)
if ($action === 'change_password') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not logged in']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $current_password = trim($_POST['current_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }

    if ($new_password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'New passwords do not match']);
        exit;
    }

    if (strlen($new_password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
        exit;
    }

    // Verify current password
    $query = "SELECT password FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!password_verify($current_password, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
        exit;
    }

    // Update password
    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
    $update_query = "UPDATE users SET password = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("si", $hashed_password, $user_id);

    if ($update_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to change password']);
    }
    exit;
}

// Get User Profile
if ($action === 'get_profile') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not logged in']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $query = "SELECT id, name, email, phone, address, city, state, zip_code, country, profile_picture FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
