<?php
header('Content-Type: application/json');
session_start();

require_once '../config/db_config.php';

$action = $_POST['action'] ?? '';

// Admin Login
if ($action === 'admin_login') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }

    // Check if admin exists
    $query = "SELECT id, name, email, password, role FROM admins WHERE email = ? AND is_active = 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }

    $admin = $result->fetch_assoc();

    // Verify password
    if (!password_verify($password, $admin['password'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }

    // Update last login
    $update_query = "UPDATE admins SET last_login = NOW() WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("i", $admin['id']);
    $update_stmt->execute();

    // Set session
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_name'] = $admin['name'];
    $_SESSION['admin_email'] = $admin['email'];
    $_SESSION['admin_role'] = $admin['role'];
    $_SESSION['user_type'] = 'admin';

    echo json_encode(['success' => true, 'message' => 'Login successful', 'redirect' => '../dashboard/index.php']);
    exit;
}

// Admin Registration (Super admin only)
if ($action === 'admin_register') {
    // Check if user is super admin
    if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] !== 'super_admin') {
        echo json_encode(['success' => false, 'message' => 'Unauthorized. Only super admin can create admin accounts.']);
        exit;
    }

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = $_POST['role'] ?? 'admin';

    // Validation
    if (empty($name) || empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }

    if (!in_array($role, ['admin', 'moderator'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid role']);
        exit;
    }

    if (strlen($password) < 8) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters long']);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }

    // Check if email already exists
    $check_query = "SELECT id FROM admins WHERE email = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert admin
    $insert_query = "INSERT INTO admins (name, email, password, role) VALUES (?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_query);
    $insert_stmt->bind_param("ssss", $name, $email, $hashed_password, $role);

    if ($insert_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Admin account created successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
    }
    exit;
}

// Admin Logout
if ($action === 'logout') {
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
    exit;
}

// Check if admin is logged in
if ($action === 'check_session') {
    if (isset($_SESSION['admin_id'])) {
        echo json_encode(['success' => true, 'logged_in' => true, 'admin' => [
            'id' => $_SESSION['admin_id'],
            'name' => $_SESSION['admin_name'],
            'email' => $_SESSION['admin_email'],
            'role' => $_SESSION['admin_role']
        ]]);
    } else {
        echo json_encode(['success' => true, 'logged_in' => false]);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
