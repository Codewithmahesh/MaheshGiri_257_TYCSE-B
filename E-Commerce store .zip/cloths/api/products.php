<?php
header('Content-Type: application/json');
session_start();

require_once '../config/db_config.php';

// Check if admin is logged in
function checkAdminAuth() {
    if (!isset($_SESSION['admin_id']) || $_SESSION['user_type'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
        exit;
    }
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Get all products
if ($action === 'get_products') {
    $category = $_GET['category'] ?? '';
    
    $query = "SELECT * FROM products";
    if ($category) {
        $query .= " WHERE category = ?";
    }
    $query .= " ORDER BY created_at DESC";
    
    if ($category) {
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $category);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($query);
    }
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    echo json_encode(['success' => true, 'products' => $products]);
    exit;
}

// Get single product
if ($action === 'get_product') {
    checkAdminAuth();
    
    $id = $_GET['id'] ?? 0;
    
    $query = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        exit;
    }
    
    $product = $result->fetch_assoc();
    echo json_encode(['success' => true, 'product' => $product]);
    exit;
}

// Add product
if ($action === 'add_product') {
    checkAdminAuth();
    
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? '';
    $price = $_POST['price'] ?? 0;
    $discount_percentage = $_POST['discount_percentage'] ?? 0;
    $stock_quantity = $_POST['stock_quantity'] ?? 0;
    $is_active = $_POST['is_active'] ?? 1;
    $created_by = $_SESSION['admin_id'];
    
    // Validation
    if (empty($name) || empty($category) || $price <= 0) {
        echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
        exit;
    }
    
    // Handle image upload
    $image_url = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_result = handleImageUpload($_FILES['image']);
        if ($upload_result['success']) {
            $image_url = $upload_result['path'];
        } else {
            echo json_encode(['success' => false, 'message' => $upload_result['message']]);
            exit;
        }
    }
    
    // Insert product
    $query = "INSERT INTO products (name, description, category, price, discount_percentage, image_url, stock_quantity, is_active, created_by) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssdisiii", $name, $description, $category, $price, $discount_percentage, $image_url, $stock_quantity, $is_active, $created_by);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product added successfully', 'product_id' => $conn->insert_id]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add product: ' . $conn->error]);
    }
    exit;
}

// Update product
if ($action === 'update_product') {
    checkAdminAuth();
    
    $id = $_POST['id'] ?? 0;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? '';
    $price = $_POST['price'] ?? 0;
    $discount_percentage = $_POST['discount_percentage'] ?? 0;
    $stock_quantity = $_POST['stock_quantity'] ?? 0;
    $is_active = $_POST['is_active'] ?? 1;
    
    // Validation
    if (empty($name) || empty($category) || $price <= 0) {
        echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
        exit;
    }
    
    // Get current product to check if image exists
    $current_query = "SELECT image_url FROM products WHERE id = ?";
    $current_stmt = $conn->prepare($current_query);
    $current_stmt->bind_param("i", $id);
    $current_stmt->execute();
    $current_result = $current_stmt->get_result();
    $current_product = $current_result->fetch_assoc();
    
    $image_url = $current_product['image_url'];
    
    // Handle new image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Delete old image if exists
        if ($image_url && file_exists('../' . $image_url)) {
            unlink('../' . $image_url);
        }
        
        $upload_result = handleImageUpload($_FILES['image']);
        if ($upload_result['success']) {
            $image_url = $upload_result['path'];
        } else {
            echo json_encode(['success' => false, 'message' => $upload_result['message']]);
            exit;
        }
    }
    
    // Update product
    $query = "UPDATE products SET name = ?, description = ?, category = ?, price = ?, discount_percentage = ?, 
              image_url = ?, stock_quantity = ?, is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssdisiii", $name, $description, $category, $price, $discount_percentage, $image_url, $stock_quantity, $is_active, $id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update product: ' . $conn->error]);
    }
    exit;
}

// Delete product
if ($action === 'delete_product') {
    checkAdminAuth();
    
    $id = $_POST['id'] ?? 0;
    
    // Get product to delete image
    $query = "SELECT image_url FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    
    // Delete image file if exists
    if ($product && $product['image_url'] && file_exists('../' . $product['image_url'])) {
        unlink('../' . $product['image_url']);
    }
    
    // Soft delete (set is_active to 0) - uncomment this for soft delete
    // $delete_query = "UPDATE products SET is_active = 0 WHERE id = ?";
    
    // Hard delete - comment this out if you want soft delete
    $delete_query = "DELETE FROM products WHERE id = ?";
    
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $id);
    
    if ($delete_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete product: ' . $conn->error]);
    }
    exit;
}

// Handle image upload
function handleImageUpload($file) {
    $upload_dir = '../assets/images/products/';
    
    // Create directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Validate file type
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowed_types)) {
        return ['success' => false, 'message' => 'Invalid file type. Only JPG, PNG, GIF, and WEBP are allowed.'];
    }
    
    // Validate file size (max 5MB)
    if ($file['size'] > 5 * 1024 * 1024) {
        return ['success' => false, 'message' => 'File size too large. Maximum 5MB allowed.'];
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('product_') . '.' . $extension;
    $filepath = $upload_dir . $filename;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => true, 'path' => 'assets/images/products/' . $filename];
    } else {
        return ['success' => false, 'message' => 'Failed to upload image'];
    }
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
