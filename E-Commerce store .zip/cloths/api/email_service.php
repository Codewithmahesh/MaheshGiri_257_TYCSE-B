<?php
/**
 * Email Service for OTP Verification
 * Supports multiple SMTP providers for real email delivery
 */

require_once __DIR__ . '/../config/email_config.php';
require_once __DIR__ . '/SimpleSMTPMail.php';

class EmailService {
    private $senderEmail;
    private $senderName;
    
    public function __construct() {
        if (EMAIL_PROVIDER === 'gmail') {
            $this->senderEmail = GMAIL_SENDER_EMAIL;
            $this->senderName = GMAIL_SENDER_NAME;
        } elseif (EMAIL_PROVIDER === 'mailtrap') {
            $this->senderEmail = MAILTRAP_SENDER_EMAIL;
            $this->senderName = MAILTRAP_SENDER_NAME;
        } elseif (EMAIL_PROVIDER === 'custom') {
            $this->senderEmail = CUSTOM_SENDER_EMAIL;
            $this->senderName = CUSTOM_SENDER_NAME;
        } else {
            $this->senderEmail = 'noreply@rndapparel.com';
            $this->senderName = 'rnd.apparel';
        }
    }

    /**
     * Send OTP Email
     */
    public function sendOTPEmail($toEmail, $toName, $otp) {
        $subject = 'Email Verification - Your OTP Code';
        $htmlBody = $this->getOTPEmailTemplate($toName, $otp);
        
        if (EMAIL_PROVIDER === 'gmail') {
            return $this->sendViaGmail($toEmail, $toName, $subject, $htmlBody, $otp);
        } elseif (EMAIL_PROVIDER === 'mailtrap') {
            return $this->sendViaMailtrap($toEmail, $toName, $subject, $htmlBody, $otp);
        } elseif (EMAIL_PROVIDER === 'custom') {
            return $this->sendViaCustomSMTP($toEmail, $toName, $subject, $htmlBody, $otp);
        } else {
            // Fallback to PHP mail()
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
            $headers .= "From: " . $this->senderName . " <" . $this->senderEmail . ">" . "\r\n";
            $headers .= "Reply-To: " . $this->senderEmail . "\r\n";
            
            $mailResult = @mail($toEmail, $subject, $htmlBody, $headers);
            
            // Also log for development
            $this->logEmailToFile('OTP Email', $toEmail, $toName, $subject, $htmlBody, $otp);
            
            return true;
        }
    }

    /**
     * Get OTP Email HTML Template
     */
    private function getOTPEmailTemplate($name, $otp) {
        return "
        <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                        background-color: #f9f9f9;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                    }
                    .header {
                        text-align: center;
                        padding-bottom: 20px;
                        border-bottom: 2px solid #000;
                        margin-bottom: 20px;
                    }
                    .header h1 {
                        margin: 0;
                        font-size: 24px;
                        font-weight: 300;
                        letter-spacing: -0.5px;
                    }
                    .content {
                        padding: 20px 0;
                    }
                    .otp-box {
                        text-align: center;
                        background-color: #fff;
                        padding: 20px;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                        margin: 20px 0;
                    }
                    .otp-code {
                        font-size: 32px;
                        font-weight: 600;
                        letter-spacing: 5px;
                        color: #000;
                        margin: 10px 0;
                    }
                    .otp-expiry {
                        color: #666;
                        font-size: 14px;
                        margin-top: 15px;
                    }
                    .footer {
                        text-align: center;
                        padding-top: 20px;
                        border-top: 1px solid #ddd;
                        color: #666;
                        font-size: 12px;
                    }
                    .warning {
                        background-color: #fff3cd;
                        border: 1px solid #ffc107;
                        color: #856404;
                        padding: 10px;
                        border-radius: 3px;
                        margin: 15px 0;
                        font-size: 13px;
                    }
                </style>
            </head>
            <body>
                <div class=\"container\">
                    <div class=\"header\">
                        <h1>rnd.apparel</h1>
                    </div>
                    
                    <div class=\"content\">
                        <p>Hi <strong>" . htmlspecialchars($name) . "</strong>,</p>
                        
                        <p>Welcome to rnd.apparel! To complete your email verification, please use the following One-Time Password (OTP):</p>
                        
                        <div class=\"otp-box\">
                            <p style=\"margin: 0; color: #666; font-size: 14px;\">Your verification code:</p>
                            <div class=\"otp-code\">" . $otp . "</div>
                            <div class=\"otp-expiry\">This code expires in 3 minutes</div>
                        </div>
                        
                        <div class=\"warning\">
                            <strong>Security Note:</strong> Never share this code with anyone. rnd.apparel staff will never ask for your OTP.
                        </div>
                        
                        <p>If you didn't create an account with rnd.apparel, please ignore this email.</p>
                        
                        <p>Best regards,<br>The rnd.apparel Team</p>
                    </div>
                    
                    <div class=\"footer\">
                        <p>&copy; " . date('Y') . " rnd.apparel. All rights reserved.</p>
                        <p>This is an automated email, please do not reply to this address.</p>
                    </div>
                </div>
            </body>
        </html>";
    }

    /**
     * Send Welcome Email
     */
    public function sendWelcomeEmail($toEmail, $toName) {
        $subject = 'Welcome to rnd.apparel!';
        
        $htmlBody = "
        <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                        background-color: #f9f9f9;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                    }
                    .header {
                        text-align: center;
                        padding-bottom: 20px;
                        border-bottom: 2px solid #000;
                        margin-bottom: 20px;
                    }
                    .header h1 {
                        margin: 0;
                        font-size: 24px;
                        font-weight: 300;
                        letter-spacing: -0.5px;
                    }
                    .footer {
                        text-align: center;
                        padding-top: 20px;
                        border-top: 1px solid #ddd;
                        color: #666;
                        font-size: 12px;
                    }
                </style>
            </head>
            <body>
                <div class=\"container\">
                    <div class=\"header\">
                        <h1>rnd.apparel</h1>
                    </div>
                    
                    <div class=\"content\">
                        <p>Hi <strong>" . htmlspecialchars($toName) . "</strong>,</p>
                        
                        <p>Your email has been verified! Your account is now fully active.</p>
                        
                        <p>You can now:</p>
                        <ul>
                            <li>Browse our exclusive collection of apparel</li>
                            <li>Add items to your wishlist</li>
                            <li>Manage your orders</li>
                            <li>View your profile and preferences</li>
                        </ul>
                        
                        <p>Start exploring and find your perfect style at rnd.apparel!</p>
                        
                        <p>Best regards,<br>The rnd.apparel Team</p>
                    </div>
                    
                    <div class=\"footer\">
                        <p>&copy; " . date('Y') . " rnd.apparel. All rights reserved.</p>
                    </div>
                </div>
            </body>
        </html>";
        
        if (EMAIL_PROVIDER === 'gmail') {
            return $this->sendViaGmail($toEmail, $toName, $subject, $htmlBody, null);
        } elseif (EMAIL_PROVIDER === 'mailtrap') {
            return $this->sendViaMailtrap($toEmail, $toName, $subject, $htmlBody, null);
        } elseif (EMAIL_PROVIDER === 'custom') {
            return $this->sendViaCustomSMTP($toEmail, $toName, $subject, $htmlBody, null);
        } else {
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
            $headers .= "From: " . $this->senderName . " <" . $this->senderEmail . ">" . "\r\n";
            
            $mailResult = @mail($toEmail, $subject, $htmlBody, $headers);
            
            $this->logEmailToFile('Welcome Email', $toEmail, $toName, $subject, $htmlBody, null);
            
            return true;
        }
    }

    /**
     * Send Password Reset Email
     */
    public function sendPasswordResetEmail($toEmail, $toName, $resetLink) {
        $subject = 'Password Reset Request - rnd.apparel';
        
        $htmlBody = "
        <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                        background-color: #f9f9f9;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                    }
                    .header {
                        text-align: center;
                        padding-bottom: 20px;
                        border-bottom: 2px solid #000;
                        margin-bottom: 20px;
                    }
                    .header h1 {
                        margin: 0;
                        font-size: 24px;
                        font-weight: 300;
                        letter-spacing: -0.5px;
                    }
                    .content {
                        padding: 20px 0;
                    }
                    .reset-button {
                        display: inline-block;
                        padding: 12px 30px;
                        background-color: #000;
                        color: #fff;
                        text-decoration: none;
                        border-radius: 3px;
                        margin: 20px 0;
                        font-weight: 600;
                    }
                    .reset-link-box {
                        background-color: #fff;
                        padding: 15px;
                        border: 1px solid #ddd;
                        border-radius: 3px;
                        margin: 15px 0;
                        word-break: break-all;
                        font-size: 12px;
                        color: #666;
                    }
                    .footer {
                        text-align: center;
                        padding-top: 20px;
                        border-top: 1px solid #ddd;
                        color: #666;
                        font-size: 12px;
                    }
                    .warning {
                        background-color: #fff3cd;
                        border: 1px solid #ffc107;
                        color: #856404;
                        padding: 10px;
                        border-radius: 3px;
                        margin: 15px 0;
                        font-size: 13px;
                    }
                </style>
            </head>
            <body>
                <div class=\"container\">
                    <div class=\"header\">
                        <h1>rnd.apparel</h1>
                    </div>
                    
                    <div class=\"content\">
                        <p>Hi <strong>" . htmlspecialchars($toName) . "</strong>,</p>
                        
                        <p>We received a request to reset your password for your rnd.apparel account. Click the button below to create a new password:</p>
                        
                        <div style=\"text-align: center;\">
                            <a href=\"" . $resetLink . "\" class=\"reset-button\">Reset Password</a>
                        </div>
                        
                        <p style=\"font-size: 13px; color: #666;\">Or copy and paste this link into your browser:</p>
                        <div class=\"reset-link-box\">" . $resetLink . "</div>
                        
                        <div class=\"warning\">
                            <strong>Security Note:</strong> This link will expire in 15 minutes. If you didn't request a password reset, please ignore this email or contact support if you have concerns.
                        </div>
                        
                        <p>Best regards,<br>The rnd.apparel Team</p>
                    </div>
                    
                    <div class=\"footer\">
                        <p>&copy; " . date('Y') . " rnd.apparel. All rights reserved.</p>
                        <p>This is an automated email, please do not reply to this address.</p>
                    </div>
                </div>
            </body>
        </html>";
        
        if (EMAIL_PROVIDER === 'gmail') {
            return $this->sendViaGmail($toEmail, $toName, $subject, $htmlBody, null);
        } elseif (EMAIL_PROVIDER === 'mailtrap') {
            return $this->sendViaMailtrap($toEmail, $toName, $subject, $htmlBody, null);
        } elseif (EMAIL_PROVIDER === 'custom') {
            return $this->sendViaCustomSMTP($toEmail, $toName, $subject, $htmlBody, null);
        } else {
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
            $headers .= "From: " . $this->senderName . " <" . $this->senderEmail . ">" . "\r\n";
            
            $mailResult = @mail($toEmail, $subject, $htmlBody, $headers);
            
            $this->logEmailToFile('Password Reset Email', $toEmail, $toName, $subject, $htmlBody, null);
            
            return true;
        }
    }
    /**
     * Send via Gmail SMTP
     */
    private function sendViaGmail($toEmail, $toName, $subject, $htmlBody, $otp) {
        // Use SimpleSMTPMail class to send via Gmail
        $mailer = new SimpleSMTPMail(GMAIL_SENDER_EMAIL, GMAIL_APP_PASSWORD);
        $result = $mailer->send($toEmail, $subject, $htmlBody, $this->senderName);
        
        // Always log for debugging
        $this->logEmailToFile('Gmail Email', $toEmail, $toName, $subject, $htmlBody, $otp);
        
        return $result;
    }
    
    /**
     * Send via Mailtrap
     */
    private function sendViaMailtrap($toEmail, $toName, $subject, $htmlBody, $otp) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://send.api.mailtrap.io/api/send');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        
        $postData = json_encode([
            'from' => [
                'email' => $this->senderEmail,
                'name' => $this->senderName
            ],
            'to' => [
                [
                    'email' => $toEmail,
                    'name' => $toName
                ]
            ],
            'subject' => $subject,
            'html' => $htmlBody
        ]);
        
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Api-Token: ' . MAILTRAP_API_TOKEN
        ]);
        
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // Log for development
        $this->logEmailToFile('Mailtrap Email', $toEmail, $toName, $subject, $htmlBody, $otp);
        
        // Return true if successful (2xx response) or always true to continue
        return $httpCode >= 200 && $httpCode < 300;
    }
    
    /**
     * Send via Custom SMTP Server
     */
    private function sendViaCustomSMTP($toEmail, $toName, $subject, $htmlBody, $otp) {
        try {
            $connection = fsockopen(
                CUSTOM_SMTP_SECURITY === 'ssl' ? 'ssl://' . CUSTOM_SMTP_HOST : CUSTOM_SMTP_HOST,
                CUSTOM_SMTP_PORT,
                $errno,
                $errstr,
                10
            );
            
            if (!$connection) {
                // Fallback to file logging
                $this->logEmailToFile('Custom SMTP (Failed) OTP Email', $toEmail, $toName, $subject, $htmlBody, $otp);
                return false;
            }
            
            // Send SMTP commands
            $this->sendSMTPCommand($connection, "EHLO " . gethostname());
            $this->sendSMTPCommand($connection, "AUTH LOGIN");
            $this->sendSMTPCommand($connection, base64_encode(CUSTOM_SMTP_USERNAME));
            $this->sendSMTPCommand($connection, base64_encode(CUSTOM_SMTP_PASSWORD));
            $this->sendSMTPCommand($connection, "MAIL FROM:<" . $this->senderEmail . ">");
            $this->sendSMTPCommand($connection, "RCPT TO:<" . $toEmail . ">");
            $this->sendSMTPCommand($connection, "DATA");
            
            // Send email content
            $emailContent = "From: " . $this->senderName . " <" . $this->senderEmail . ">\r\n";
            $emailContent .= "To: " . $toName . " <" . $toEmail . ">\r\n";
            $emailContent .= "Subject: " . $subject . "\r\n";
            $emailContent .= "MIME-Version: 1.0\r\n";
            $emailContent .= "Content-type: text/html; charset=UTF-8\r\n\r\n";
            $emailContent .= $htmlBody . "\r\n.\r\n";
            
            fwrite($connection, $emailContent);
            
            $this->sendSMTPCommand($connection, "QUIT");
            fclose($connection);
            
            // Log for development
            $this->logEmailToFile('Custom SMTP OTP Email', $toEmail, $toName, $subject, $htmlBody, $otp);
            
            return true;
        } catch (Exception $e) {
            $this->logEmailToFile('Custom SMTP Error', $toEmail, $toName, $subject, $htmlBody, $otp);
            return false;
        }
    }
    
    /**
     * Helper to send SMTP commands
     */
    private function sendSMTPCommand($connection, $command) {
        fwrite($connection, $command . "\r\n");
        $response = fgets($connection, 515);
        return $response;
    }

    /**
     * Log emails to file for development/testing
     */
    private function logEmailToFile($type, $toEmail, $toName, $subject, $htmlBody, $otp = null) {
        $logsDir = __DIR__ . '/../logs';
        if (!is_dir($logsDir)) {
            mkdir($logsDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logFile = $logsDir . '/emails_' . date('Y-m-d') . '.log';
        
        $logEntry = "\n========== $timestamp ==========\n";
        $logEntry .= "Type: $type\n";
        $logEntry .= "To: $toEmail ($toName)\n";
        $logEntry .= "Subject: $subject\n";
        if ($otp) {
            $logEntry .= "OTP Code: $otp\n";
        }
        $logEntry .= "HTML Body:\n$htmlBody\n";
        $logEntry .= "====================================\n";
        
        file_put_contents($logFile, $logEntry, FILE_APPEND);
    }
}
