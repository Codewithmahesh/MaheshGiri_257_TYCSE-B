// Check if user is logged in
function checkSession() {
  const formData = new FormData();
  formData.append('action', 'check_session');

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (!data.success || !data.logged_in) {
      // Redirect to login if not logged in
      window.location.href = '../auth/index.html';
    } else {
      // Load user profile data
      loadUserProfile();
      // Update navbar with avatar
      updateNavbarForLoggedInUser(data.user);
      // Update cart count
      updateCartCount();
    }
  })
  .catch(error => {
    console.error('Session check error:', error);
    window.location.href = '../auth/index.html';
  });
}

// Update cart count from server
function updateCartCount() {
  fetch('../api/cart.php?action=get_cart')
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const cartCount = document.querySelector(".cart-count");
        if (cartCount) cartCount.textContent = data.count;
      }
    })
    .catch(error => console.error('Error fetching cart count:', error));
}

// Update navbar to show user avatar
function updateNavbarForLoggedInUser(user) {
  const placeholder = document.getElementById('user-menu-placeholder');
  
  if (placeholder) {
    const initials = getUserInitials(user.name);
    
    const userAvatarHTML = `
      <div class="user-profile-container">
        <button class="user-avatar" id="userAvatarBtn" aria-label="User Menu">
          ${initials}
        </button>
        <div class="user-dropdown" id="userDropdown">
          <div class="user-dropdown-header">
            <div class="user-dropdown-avatar">${initials}</div>
            <div class="user-dropdown-info">
              <p class="user-dropdown-name">${user.name}</p>
              <p class="user-dropdown-email">${user.email}</p>
            </div>
          </div>
          <div class="user-dropdown-divider"></div>
          <a href="../profile/index.html" class="user-dropdown-item">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            Edit Profile
          </a>
          <button class="user-dropdown-item" id="logoutBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Logout
          </button>
        </div>
      </div>
    `;
    
    placeholder.outerHTML = userAvatarHTML;
    setupUserDropdown();
  }
}

function getUserInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return parts[0][0].toUpperCase();
}

function setupUserDropdown() {
  const avatarBtn = document.getElementById('userAvatarBtn');
  const dropdown = document.getElementById('userDropdown');
  const logoutBtn = document.getElementById('logoutBtn');
  
  if (avatarBtn && dropdown) {
    avatarBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('active');
    });
    
    document.addEventListener('click', (e) => {
      if (!avatarBtn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
      }
    });
  }
  
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      const formData = new FormData();
      formData.append('action', 'logout');
      
      fetch('../api/user_auth.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          window.location.href = '../home/index.html';
        }
      });
    });
  }
}

// Load user profile data
function loadUserProfile() {
  showLoading('Loading profile...');

  const formData = new FormData();
  formData.append('action', 'get_profile');

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    hideLoading();
    if (data.success) {
      populateForm(data.user);
    } else {
      showNotification('Failed to load profile', 'error');
    }
  })
  .catch(error => {
    hideLoading();
    console.error('Error loading profile:', error);
    showNotification('An error occurred while loading profile', 'error');
  });
}

// Populate form with user data
function populateForm(user) {
  document.getElementById('profile-name').value = user.name || '';
  document.getElementById('profile-email').value = user.email || '';
  document.getElementById('profile-phone').value = user.phone || '';
  document.getElementById('profile-address').value = user.address || '';
  document.getElementById('profile-city').value = user.city || '';
  document.getElementById('profile-state').value = user.state || '';
  document.getElementById('profile-zip').value = user.zip_code || '';
  document.getElementById('profile-country').value = user.country || '';
}

// Loading functions
function showLoading(message = 'Processing...') {
  document.getElementById('loadingOverlay').classList.add('active');
  document.getElementById('loadingSpinner').classList.add('active');
  document.getElementById('spinnerText').textContent = message;
}

function hideLoading() {
  document.getElementById('loadingOverlay').classList.remove('active');
  document.getElementById('loadingSpinner').classList.remove('active');
}

// Notification function
function showNotification(message, type = 'success') {
  const existingNotification = document.querySelector('.notification');
  if (existingNotification) {
    existingNotification.remove();
  }

  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 30px;
    background: ${type === 'success' ? '#28a745' : '#dc3545'};
    color: #fff;
    padding: 16px 24px;
    border-radius: 4px;
    z-index: 10000;
    animation: slideIn 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    font-size: 14px;
  `;

  document.body.appendChild(notification);

  // Add CSS for animation if not already present
  if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
      @keyframes slideIn {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      @keyframes slideOut {
        from {
          transform: translateX(0);
          opacity: 1;
        }
        to {
          transform: translateX(400px);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
  }

  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => notification.remove(), 300);
  }, 4000);
}

// Toggle password visibility
const togglePasswordBtns = document.querySelectorAll('.toggle-password');
togglePasswordBtns.forEach((btn) => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    const targetId = btn.dataset.target;
    const input = document.getElementById(targetId);
    const isPassword = input.type === 'password';
    input.type = isPassword ? 'text' : 'password';
    btn.classList.toggle('active');
  });
});

// Profile form submission
const profileForm = document.getElementById('profileForm');
profileForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const name = document.getElementById('profile-name').value;
  const phone = document.getElementById('profile-phone').value;
  const address = document.getElementById('profile-address').value;
  const city = document.getElementById('profile-city').value;
  const state = document.getElementById('profile-state').value;
  const zipCode = document.getElementById('profile-zip').value;
  const country = document.getElementById('profile-country').value;
  const submitBtn = profileForm.querySelector('button[type="submit"]');

  if (!name) {
    showNotification('Name is required', 'error');
    return;
  }

  showLoading('Updating profile...');
  submitBtn.disabled = true;

  const formData = new FormData();
  formData.append('action', 'update_profile');
  formData.append('name', name);
  formData.append('phone', phone);
  formData.append('address', address);
  formData.append('city', city);
  formData.append('state', state);
  formData.append('zip_code', zipCode);
  formData.append('country', country);

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    hideLoading();
    submitBtn.disabled = false;

    if (data.success) {
      showNotification('Profile updated successfully!', 'success');
    } else {
      showNotification(data.message || 'Failed to update profile', 'error');
    }
  })
  .catch(error => {
    hideLoading();
    submitBtn.disabled = false;
    showNotification('An error occurred. Please try again.', 'error');
    console.error('Error:', error);
  });
});

// Change password form submission
const changePasswordForm = document.getElementById('changePasswordForm');
changePasswordForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const currentPassword = document.getElementById('current-password').value;
  const newPassword = document.getElementById('new-password').value;
  const confirmPassword = document.getElementById('confirm-new-password').value;
  const submitBtn = changePasswordForm.querySelector('button[type="submit"]');

  if (!currentPassword || !newPassword || !confirmPassword) {
    showNotification('All password fields are required', 'error');
    return;
  }

  if (newPassword !== confirmPassword) {
    showNotification('New passwords do not match', 'error');
    return;
  }

  if (newPassword.length < 6) {
    showNotification('Password must be at least 6 characters long', 'error');
    return;
  }

  showLoading('Changing password...');
  submitBtn.disabled = true;

  const formData = new FormData();
  formData.append('action', 'change_password');
  formData.append('current_password', currentPassword);
  formData.append('new_password', newPassword);
  formData.append('confirm_password', confirmPassword);

  fetch('../api/user_auth.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    hideLoading();
    submitBtn.disabled = false;

    if (data.success) {
      showNotification('Password changed successfully!', 'success');
      changePasswordForm.reset();
    } else {
      showNotification(data.message || 'Failed to change password', 'error');
    }
  })
  .catch(error => {
    hideLoading();
    submitBtn.disabled = false;
    showNotification('An error occurred. Please try again.', 'error');
    console.error('Error:', error);
  });
});

// Check session on page load
checkSession();

console.log('Profile page loaded successfully!');
