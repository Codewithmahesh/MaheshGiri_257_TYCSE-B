<?php
/**
 * Database Setup Script - Password Reset Tokens Table
 * 
 * This script creates the password_reset_tokens table for handling
 * forgot password functionality with secure token-based reset links.
 */

require_once '../config/db_config.php';

// Get the actual file path
$dir = dirname(__FILE__);
require_once dirname($dir) . '/config/db_config.php';

// Drop table if exists (for clean setup)
$drop_sql = "DROP TABLE IF EXISTS password_reset_tokens";
if ($conn->query($drop_sql) === TRUE) {
    echo "✓ Dropped existing password_reset_tokens table (if any)\n";
} else {
    echo "✗ Error dropping table: " . $conn->error . "\n";
}

// Create password_reset_tokens table
$create_sql = "CREATE TABLE password_reset_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    is_used BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_email (email),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_sql) === TRUE) {
    echo "✓ Created password_reset_tokens table successfully\n";
    echo "\nTable Structure:\n";
    echo "  - id: Primary key\n";
    echo "  - user_id: Foreign key to users table\n";
    echo "  - email: User's email address\n";
    echo "  - token: Unique reset token (hashed)\n";
    echo "  - expires_at: Token expiration time (15 minutes)\n";
    echo "  - is_used: Flag to prevent token reuse\n";
    echo "  - created_at: Token creation timestamp\n";
} else {
    echo "✗ Error creating table: " . $conn->error . "\n";
    exit(1);
}

echo "\n✓ Password reset tokens table setup completed!\n";

$conn->close();
?>
