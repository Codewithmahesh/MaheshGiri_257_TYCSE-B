<?php
/**
 * Database Setup Script - Remember Me Tokens Table
 * 
 * This script creates the remember_me_tokens table for handling
 * persistent login sessions with secure token-based authentication.
 */

require_once '../config/db_config.php';

// Get the actual file path
$dir = dirname(__FILE__);
require_once dirname($dir) . '/config/db_config.php';

// Drop table if exists (for clean setup)
$drop_sql = "DROP TABLE IF EXISTS remember_me_tokens";
if ($conn->query($drop_sql) === TRUE) {
    echo "✓ Dropped existing remember_me_tokens table (if any)\n";
} else {
    echo "✗ Error dropping table: " . $conn->error . "\n";
}

// Create remember_me_tokens table
$create_sql = "CREATE TABLE remember_me_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_sql) === TRUE) {
    echo "✓ Created remember_me_tokens table successfully\n";
    echo "\nTable Structure:\n";
    echo "  - id: Primary key\n";
    echo "  - user_id: Foreign key to users table\n";
    echo "  - token: Unique remember me token (hashed)\n";
    echo "  - expires_at: Token expiration time (30 days)\n";
    echo "  - created_at: Token creation timestamp\n";
} else {
    echo "✗ Error creating table: " . $conn->error . "\n";
    exit(1);
}

echo "\n✓ Remember me tokens table setup completed!\n";

$conn->close();
?>
