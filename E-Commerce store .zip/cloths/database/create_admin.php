<?php
/**
 * One-time setup script to create initial super admin account
 * Run this once, then delete or secure this file
 */

require_once '../config/db_config.php';

// Default super admin credentials
$name = "Super Admin";
$email = "admin@rndapparel.com";
$password = "Admin@123"; // Change this to a secure password
$role = "super_admin";

echo "<h2>Creating Super Admin Account</h2>";

// Check if admin already exists
$check_query = "SELECT id FROM admins WHERE email = ?";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bind_param("s", $email);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows > 0) {
    echo "<p style='color: orange;'>⚠️ Admin account with email '$email' already exists!</p>";
    echo "<p>If you need to reset the password, please do so manually in the database.</p>";
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Insert super admin
$insert_query = "INSERT INTO admins (name, email, password, role) VALUES (?, ?, ?, ?)";
$insert_stmt = $conn->prepare($insert_query);
$insert_stmt->bind_param("ssss", $name, $email, $hashed_password, $role);

if ($insert_stmt->execute()) {
    echo "<div style='background: #d4edda; color: #155724; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>✅ Super Admin Account Created Successfully!</h3>";
    echo "<p><strong>Email:</strong> $email</p>";
    echo "<p><strong>Password:</strong> $password</p>";
    echo "<p><strong>Role:</strong> $role</p>";
    echo "</div>";
    echo "<p style='color: red;'><strong>IMPORTANT:</strong> Please save these credentials and delete or secure this file immediately!</p>";
    echo "<p><a href='../admin/login.html' style='background: #000; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Admin Login</a></p>";
} else {
    echo "<p style='color: red;'>❌ Error creating admin account: " . $conn->error . "</p>";
}

$conn->close();
?>
