<?php
header('Content-Type: application/json');

// Test Gmail configuration
echo "Testing Gmail Email Configuration...\n\n";

// Check if curl is enabled
if (!extension_loaded('curl')) {
    die(json_encode(['error' => 'CURL extension not enabled in PHP']));
}

echo "✓ CURL is enabled\n";

// Check email config
require_once 'config/email_config.php';

echo "✓ EMAIL_PROVIDER: " . EMAIL_PROVIDER . "\n";
echo "✓ GMAIL_SENDER_EMAIL: " . GMAIL_SENDER_EMAIL . "\n";
echo "✓ GMAIL_APP_PASSWORD: " . (strlen(GMAIL_APP_PASSWORD) > 0 ? "***configured***" : "NOT SET") . "\n\n";

// Try a simple test email
echo "Attempting to send test email via Gmail...\n";

require_once 'api/email_service.php';

$emailService = new EmailService();
$testEmail = 'girimahesh1514@gmail.com';
$testName = 'Test User';
$testOTP = '123456';

// Check if the method exists
if (method_exists($emailService, 'sendOTPEmail')) {
    echo "✓ sendOTPEmail method exists\n";
    
    // Try sending
    $result = $emailService->sendOTPEmail($testEmail, $testName, $testOTP);
    
    echo "Result: " . ($result ? "Success" : "Failed") . "\n";
} else {
    echo "✗ sendOTPEmail method not found\n";
}

echo "\nCheck your email inbox for the test email.";
?>
