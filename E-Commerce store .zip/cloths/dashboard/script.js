// Global variables
let currentProducts = [];
let editingProductId = null;

// DOM Elements
const productModal = document.getElementById('productModal');
const productForm = document.getElementById('productForm');
const addProductBtn = document.getElementById('addProductBtn');
const closeModalBtn = document.getElementById('closeModal');
const cancelBtn = document.getElementById('cancelBtn');
const logoutBtn = document.getElementById('logoutBtn');
const productsTableBody = document.getElementById('productsTableBody');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const statusFilter = document.getElementById('statusFilter');
const productImage = document.getElementById('productImage');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    setupEventListeners();
});

// Event Listeners
function setupEventListeners() {
    addProductBtn.addEventListener('click', openAddModal);
    closeModalBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    productForm.addEventListener('submit', handleFormSubmit);
    logoutBtn.addEventListener('click', handleLogout);
    
    // Filters
    searchInput.addEventListener('input', filterProducts);
    categoryFilter.addEventListener('change', filterProducts);
    statusFilter.addEventListener('change', filterProducts);
    
    // Image preview
    productImage.addEventListener('change', handleImagePreview);
    
    // Close modal on outside click
    productModal.addEventListener('click', (e) => {
        if (e.target === productModal) {
            closeModal();
        }
    });
}

// Load Products
async function loadProducts() {
    try {
        const response = await fetch('../api/products.php?action=get_products');
        const data = await response.json();
        
        if (data.success) {
            currentProducts = data.products;
            renderProducts(currentProducts);
        } else {
            showNotification(data.message || 'Failed to load products', 'error');
            renderEmptyState();
        }
    } catch (error) {
        console.error('Error loading products:', error);
        showNotification('Error loading products', 'error');
        renderEmptyState();
    }
}

// Render Products
function renderProducts(products) {
    if (products.length === 0) {
        renderEmptyState();
        return;
    }
    
    productsTableBody.innerHTML = products.map(product => `
        <tr>
            <td>${product.id}</td>
            <td class="product-image-cell">
                ${product.image_url ? 
                    `<img src="../${product.image_url}" alt="${product.name}">` : 
                    `<div style="width: 60px; height: 60px; background: #f0f0f0; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #999;">No Image</div>`
                }
            </td>
            <td>
                <div class="product-name">${product.name}</div>
                ${product.description ? `<div class="product-description">${product.description}</div>` : ''}
            </td>
            <td>${formatCategory(product.category)}</td>
            <td>$${parseFloat(product.price).toFixed(2)}</td>
            <td>${product.discount_percentage}%</td>
            <td>
                ${product.stock_quantity === 0 ? 
                    `<span class="badge badge-danger">Out of Stock</span>` : 
                    product.stock_quantity < 10 ? 
                        `<span class="badge badge-warning">${product.stock_quantity}</span>` : 
                        `<span class="badge badge-success">${product.stock_quantity}</span>`
                }
            </td>
            <td>
                ${product.is_active == 1 ? 
                    `<span class="badge badge-success">Active</span>` : 
                    `<span class="badge badge-danger">Inactive</span>`
                }
            </td>
            <td class="action-buttons-cell">
                <button class="btn btn-sm btn-secondary" onclick="editProduct(${product.id})">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                    </svg>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteProduct(${product.id}, '${product.name}')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                    </svg>
                </button>
            </td>
        </tr>
    `).join('');
}

// Render Empty State
function renderEmptyState() {
    productsTableBody.innerHTML = `
        <tr>
            <td colspan="9">
                <div class="empty-state">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                    <h3>No products found</h3>
                    <p>Start by adding your first product</p>
                </div>
            </td>
        </tr>
    `;
}

// Filter Products
function filterProducts() {
    const searchTerm = searchInput.value.toLowerCase();
    const category = categoryFilter.value;
    const status = statusFilter.value;
    
    const filtered = currentProducts.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                            (product.description && product.description.toLowerCase().includes(searchTerm));
        const matchesCategory = !category || product.category === category;
        const matchesStatus = status === '' || product.is_active == status;
        
        return matchesSearch && matchesCategory && matchesStatus;
    });
    
    renderProducts(filtered);
}

// Format Category
function formatCategory(category) {
    return category.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
}

// Modal Functions
function openAddModal() {
    editingProductId = null;
    document.getElementById('modalTitle').textContent = 'Add Product';
    document.getElementById('submitBtnText').textContent = 'Add Product';
    productForm.reset();
    imagePreview.classList.remove('active');
    productModal.classList.add('active');
}

function openEditModal(product) {
    editingProductId = product.id;
    document.getElementById('modalTitle').textContent = 'Edit Product';
    document.getElementById('submitBtnText').textContent = 'Update Product';
    
    // Populate form
    document.getElementById('productId').value = product.id;
    document.getElementById('productName').value = product.name;
    document.getElementById('productDescription').value = product.description || '';
    document.getElementById('productCategory').value = product.category;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productDiscount').value = product.discount_percentage;
    document.getElementById('productStock').value = product.stock_quantity;
    document.getElementById('productActive').checked = product.is_active == 1;
    
    // Show existing image
    if (product.image_url) {
        previewImg.src = '../' + product.image_url;
        imagePreview.classList.add('active');
    }
    
    productModal.classList.add('active');
}

function closeModal() {
    productModal.classList.remove('active');
    productForm.reset();
    imagePreview.classList.remove('active');
    editingProductId = null;
}

// Edit Product
async function editProduct(id) {
    try {
        const response = await fetch(`../api/products.php?action=get_product&id=${id}`);
        const data = await response.json();
        
        if (data.success) {
            openEditModal(data.product);
        } else {
            showNotification(data.message || 'Failed to load product', 'error');
        }
    } catch (error) {
        console.error('Error loading product:', error);
        showNotification('Error loading product', 'error');
    }
}

// Delete Product
async function deleteProduct(id, name) {
    if (!confirm(`Are you sure you want to delete "${name}"?`)) {
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('action', 'delete_product');
        formData.append('id', id);
        
        const response = await fetch('../api/products.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Product deleted successfully', 'success');
            loadProducts();
        } else {
            showNotification(data.message || 'Failed to delete product', 'error');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        showNotification('Error deleting product', 'error');
    }
}

// Handle Form Submit
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const submitBtn = document.getElementById('submitBtn');
    const submitBtnText = document.getElementById('submitBtnText');
    const originalText = submitBtnText.textContent;
    
    // Disable button and show loading
    submitBtn.disabled = true;
    submitBtnText.innerHTML = '<span class="loading"></span> Saving...';
    
    try {
        const formData = new FormData(productForm);
        formData.append('action', editingProductId ? 'update_product' : 'add_product');
        formData.append('is_active', document.getElementById('productActive').checked ? 1 : 0);
        
        if (editingProductId) {
            formData.append('id', editingProductId);
        }
        
        const response = await fetch('../api/products.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(
                editingProductId ? 'Product updated successfully' : 'Product added successfully',
                'success'
            );
            closeModal();
            loadProducts();
        } else {
            showNotification(data.message || 'Failed to save product', 'error');
        }
    } catch (error) {
        console.error('Error saving product:', error);
        showNotification('Error saving product', 'error');
    } finally {
        submitBtn.disabled = false;
        submitBtnText.textContent = originalText;
    }
}

// Image Preview
function handleImagePreview(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            previewImg.src = e.target.result;
            imagePreview.classList.add('active');
        };
        reader.readAsDataURL(file);
    }
}

// Logout
function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        fetch('../api/admin_auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=logout'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = '../admin/login.html';
            }
        })
        .catch(error => {
            console.error('Logout error:', error);
            window.location.href = '../admin/login.html';
        });
    }
}

// Show Notification
function showNotification(message, type = 'success') {
    // Remove existing notification
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type === 'error' ? 'error' : ''}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 4000);
}
