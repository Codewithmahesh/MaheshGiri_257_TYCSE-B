# Cloths Project - Database & Authentication Setup Guide

## Project Overview
This is an e-commerce platform for clothing using XAMPP (PHP + MySQL).

## Database Setup

### Step 1: Create the Database
1. Open **phpMyAdmin** in your browser: `http://localhost/phpmyadmin`
2. Go to the **SQL** tab
3. Copy and paste the entire content from `cloths/database/cloths_db.sql`
4. Click **Go** to execute

This will create:
- `cloths_db` database with the following tables:
  - `users` - Regular customer accounts
  - `admins` - Admin/staff accounts
  - `products` - Product catalog
  - `orders` - Customer orders
  - `order_items` - Items in each order
  - `cart` - Shopping cart
  - `wishlist` - User wishlist
  - `reviews` - Product reviews

### Step 2: Create Initial Admin Account (Optional)
After database is created, insert a super admin user:

```sql
INSERT INTO admins (name, email, password, role, is_active) VALUES (
  'Super Admin',
  'admin@cloths.local',
  '$2y$10$YOUR_HASHED_PASSWORD_HERE',
  'super_admin',
  1
);
```

To generate a password hash, use PHP:
```php
<?php
echo password_hash('your_password_here', PASSWORD_BCRYPT);
?>
```

## Project Structure

```
cloths/
├── config/
│   └── db_config.php          # Database configuration
├── api/
│   ├── user_auth.php          # User login/registration API
│   └── admin_auth.php         # Admin login/registration API
├── database/
│   └── cloths_db.sql          # Database schema
├── admin/
│   └── login.html             # Admin login page
├── auth/
│   ├── index.html             # User login/registration
│   ├── script.js              # Updated with API calls
│   └── style.css
├── home/
│   ├── index.html
│   ├── script.js
│   └── style.css
├── category/
│   ├── index.html
│   ├── script.js
│   └── style.css
└── assets/
    ├── images/
    └── videos/
```

## API Endpoints

### User Authentication (`/api/user_auth.php`)

**User Login:**
```
POST /api/user_auth.php
action: user_login
email: user@example.com
password: password123
```

Response:
```json
{
  "success": true,
  "message": "Login successful",
  "redirect": "../home/index.html"
}
```

**User Registration:**
```
POST /api/user_auth.php
action: user_register
name: John Doe
email: john@example.com
password: password123
confirmPassword: password123
```

**Check Session:**
```
POST /api/user_auth.php
action: check_session
```

Response:
```json
{
  "success": true,
  "logged_in": true,
  "user": {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

**Logout:**
```
POST /api/user_auth.php
action: logout
```

### Admin Authentication (`/api/admin_auth.php`)

**Admin Login:**
```
POST /api/admin_auth.php
action: admin_login
email: admin@cloths.local
password: adminpassword
```

Response:
```json
{
  "success": true,
  "message": "Login successful",
  "redirect": "../dashboard/index.php"
}
```

**Admin Registration** (Super Admin only):
```
POST /api/admin_auth.php
action: admin_register
name: New Admin
email: newadmin@cloths.local
password: strongpassword123
role: admin
```

## Database Tables Overview

### Users Table
- `id` - Primary key
- `name` - Full name
- `email` - Unique email address
- `password` - Hashed password
- `phone`, `address`, `city`, `state`, `zip_code`, `country` - Address info
- `profile_picture` - URL to profile image
- `is_active` - Account status
- `email_verified` - Email verification flag
- `created_at`, `updated_at` - Timestamps

### Admins Table
- `id` - Primary key
- `name` - Admin name
- `email` - Unique email
- `password` - Hashed password
- `role` - ENUM: 'super_admin', 'admin', 'moderator'
- `phone`, `profile_picture` - Contact info
- `is_active` - Account status
- `last_login` - Last login timestamp
- `created_at`, `updated_at` - Timestamps

### Products Table
- `id` - Primary key
- `name` - Product name
- `description` - Product description
- `category` - ENUM: women_tops, women_bottoms, women_accessories, men_tops, men_bottoms, men_accessories
- `price` - Product price
- `discount_percentage` - Discount if any
- `image_url` - Product image URL
- `stock_quantity` - Available stock
- `is_active` - Product visibility
- `created_by` - Admin who created it (FK to admins)
- `created_at`, `updated_at` - Timestamps

### Orders Table
- `id` - Primary key
- `user_id` - FK to users
- `total_amount` - Order total
- `status` - ENUM: pending, processing, shipped, delivered, cancelled
- `payment_method` - ENUM: credit_card, debit_card, paypal, bank_transfer
- `shipping_address` - Delivery address
- `notes` - Order notes
- `created_at`, `updated_at` - Timestamps

### Order Items Table
- `id` - Primary key
- `order_id` - FK to orders
- `product_id` - FK to products
- `quantity` - Items count
- `price` - Price at purchase
- `created_at` - Timestamp

### Cart Table
- `id` - Primary key
- `user_id` - FK to users
- `product_id` - FK to products
- `quantity` - Items in cart
- `added_at` - Timestamp

### Wishlist Table
- `id` - Primary key
- `user_id` - FK to users
- `product_id` - FK to products
- `added_at` - Timestamp

### Reviews Table
- `id` - Primary key
- `product_id` - FK to products
- `user_id` - FK to users
- `rating` - 1-5 rating
- `comment` - Review text
- `is_approved` - Moderation flag
- `created_at`, `updated_at` - Timestamps

## Usage

### For Users
1. Navigate to `/auth/index.html`
2. Register new account or login with existing credentials
3. Passwords are hashed using bcrypt for security
4. Session data is stored server-side

### For Admins
1. Navigate to `/admin/login.html`
2. Login with admin credentials
3. Will be redirected to dashboard after successful login
4. Different roles (super_admin, admin, moderator) for permission control

## Security Features
- Password hashing with bcrypt
- SQL prepared statements (prevent SQL injection)
- Session-based authentication
- Email validation
- Password strength validation
- CSRF protection via session tokens (can be enhanced)

## Next Steps
1. ✅ Database schema created
2. ✅ User login/registration API implemented
3. ✅ Admin login API implemented
4. ✅ Frontend forms updated to use APIs
5. **TODO:** Create admin dashboard
6. **TODO:** Product management interface
7. **TODO:** Order management system
8. **TODO:** Payment gateway integration
9. **TODO:** Email verification system
10. **TODO:** Password reset functionality

## Configuration
Edit `config/db_config.php` if you need to change:
- Database host
- Database user credentials
- Database name

Default settings:
- Host: localhost
- User: root
- Password: (empty)
- Database: cloths_db

## Testing
Access the application:
- **User Login:** http://localhost/cloths/auth/index.html
- **Admin Login:** http://localhost/cloths/admin/login.html
- **Home Page:** http://localhost/cloths/home/index.html
