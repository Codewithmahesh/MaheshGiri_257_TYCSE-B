# Email Configuration Guide - rnd.apparel

## How to Setup Real Email Delivery

### Option 1: Gmail SMTP (Recommended for Development)

Gmail SMTP is the easiest option for sending real emails on your development machine.

#### Steps to Setup Gmail:

1. **Enable 2-Factor Authentication on your Gmail account:**
   - Go to https://myaccount.google.com
   - Click "Security" in the left menu
   - Scroll down and enable "2-Step Verification"

2. **Generate App Password:**
   - After enabling 2-Step Verification, go back to Security settings
   - Scroll down to "App passwords" (should appear only if 2FA is enabled)
   - Select "Mail" and "Windows Computer"
   - Google will generate a 16-character password
   - Copy this password

3. **Configure email_config.php:**
   - Open `C:\xampp\htdocs\cloths\config\email_config.php`
   - Change:
     ```php
     define('EMAIL_PROVIDER', 'gmail');
     define('GMAIL_SENDER_EMAIL', 'your-email@gmail.com');  // Your actual Gmail
     define('GMAIL_APP_PASSWORD', 'your-app-password');     // The 16-char password from Google
     ```

4. **Test the configuration:**
   - Register a new account at `http://localhost/cloths/auth/index.html`
   - You should receive an OTP email in your inbox!

---

### Option 2: Mailtrap (Free Tier Available)

Mailtrap is a fake SMTP service that catches all emails in a test inbox. Perfect for testing.

#### Steps to Setup Mailtrap:

1. **Create Mailtrap Account:**
   - Go to https://mailtrap.io
   - Sign up for a free account
   - Verify your email

2. **Create Inbox & Get API Token:**
   - Create a new Inbox (e.g., "rnd.apparel-dev")
   - Go to Settings → API Tokens
   - Copy your API token

3. **Configure email_config.php:**
   - Open `C:\xampp\htdocs\cloths\config\email_config.php`
   - Change:
     ```php
     define('EMAIL_PROVIDER', 'mailtrap');
     define('MAILTRAP_API_TOKEN', 'your-api-token-here');
     define('MAILTRAP_SENDER_EMAIL', 'hello@rndapparel.com');
     ```

4. **Test the configuration:**
   - Register a new account at `http://localhost/cloths/auth/index.html`
   - Go to Mailtrap dashboard → Your Inbox
   - You'll see all test emails there (not in real mailbox)

---

### Option 3: Custom SMTP Server

If you have your own SMTP server (office mail server, etc.):

#### Steps to Setup Custom SMTP:

1. **Get your SMTP credentials:**
   - SMTP Host (e.g., smtp.office365.com)
   - SMTP Port (usually 587 for TLS or 465 for SSL)
   - Username and Password

2. **Configure email_config.php:**
   - Open `C:\xampp\htdocs\cloths\config\email_config.php`
   - Change:
     ```php
     define('EMAIL_PROVIDER', 'custom');
     define('CUSTOM_SMTP_HOST', 'smtp.your-provider.com');
     define('CUSTOM_SMTP_PORT', 587);
     define('CUSTOM_SMTP_SECURITY', 'tls');  // or 'ssl'
     define('CUSTOM_SMTP_USERNAME', 'your-email@company.com');
     define('CUSTOM_SMTP_PASSWORD', 'your-password');
     define('CUSTOM_SENDER_EMAIL', 'noreply@company.com');
     define('CUSTOM_SENDER_NAME', 'rnd.apparel');
     ```

3. **Test the configuration:**
   - Register a new account
   - Email should be sent via your SMTP server

---

## Current Configuration

**Active Provider:** `php_mail` (default fallback)
- Emails are logged to: `C:\xampp\htdocs\cloths\logs\emails_YYYY-MM-DD.log`
- No emails are sent to actual mailboxes in this mode

**To enable real email:**
- Configure one of the options above (Gmail recommended)
- Update `EMAIL_PROVIDER` in `email_config.php`
- Restart your browser/clear cache and register again

---

## Troubleshooting

### Gmail Setup Issues:
- **"App password not generated?"** - Make sure 2-Step Verification is enabled
- **"Email not received?"** - Check Gmail spam folder, or check browser console for errors
- **"Connection refused?"** - Gmail may have rate limiting; try again in a few minutes

### Mailtrap Issues:
- **"No emails in inbox?"** - Check if MAILTRAP_API_TOKEN is correct
- **"Authentication error?"** - Regenerate a new API token from Mailtrap settings

### General:
- Check browser console (F12) for JavaScript errors
- Check `logs/emails_*.log` to see what email was generated
- Check `config/email_config.php` is properly configured

---

## Email Log File Format

Every email sent is logged to: `C:\xampp\htdocs\cloths\logs\emails_2025-12-01.log`

Example log entry:
```
========== 2025-12-01 16:00:00 ==========
Type: OTP Email
To: user@example.com (John Doe)
Subject: Email Verification - Your OTP Code
OTP Code: 123456
HTML Body:
[Full HTML email content...]
====================================
```

You can always check this log to verify what OTP code was generated for testing.

