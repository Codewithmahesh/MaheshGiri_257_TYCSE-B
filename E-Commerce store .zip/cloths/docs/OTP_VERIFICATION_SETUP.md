# Email OTP Verification Setup Guide

## Overview
The registration form has been completely redesigned with a **two-column layout** to minimize scrolling, and a comprehensive **email OTP verification system** has been implemented.

## What's New

### 1. **Two-Column Form Layout**
- **Left Column**: Personal Information (Name, Email, Phone) + Security (Password Fields)
- **Right Column**: Address Information (Address, City, State, ZIP, Country)
- **Responsive**: Automatically switches to single column on mobile devices
- **Benefits**: Better UX, less scrolling, all fields visible at once (when possible)

### 2. **Email OTP Verification System**
- Users receive a **6-digit OTP code** via email after registration
- **3-minute countdown timer** for security
- **6 OTP input boxes** with automatic focus navigation
- **Auto-paste support** (paste the entire code into the first box)
- **Resend functionality** with cooldown timer
- **3 attempt limit** to prevent brute force attacks

### 3. **Database Changes**
A new table `otp_verifications` has been created to store OTP codes:

```sql
CREATE TABLE IF NOT EXISTS otp_verifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    email VARCHAR(100) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    attempts INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    is_verified BOOLEAN DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_email (email),
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## Setup Instructions

### Step 1: Create the OTP Table
Run the setup script in your browser:
```
http://localhost/cloths/database/setup_otp.php
```

Or manually import the SQL table using phpMyAdmin.

### Step 2: Configure Email Settings
Edit `/api/email_service.php` and update the sender email if needed:

```php
private $senderEmail = 'noreply@rndapparel.com';  // Change this
private $senderName = 'rnd.apparel';              // And this
```

### Step 3: Enable PHP Mail Function
Make sure your XAMPP PHP mail function is configured. On Windows XAMPP:

1. Open `C:\xampp\sendmail\sendmail.ini`
2. Configure SMTP settings (if using SMTP)
3. Or use the default local mail function

**For testing without real email:**
You can check the output in `C:\xampp\mailoutput\` folder (if configured in php.ini)

## File Changes Summary

### New Files Created:
1. **`/api/email_service.php`** - Email service class for OTP and welcome emails
2. **`/database/setup_otp.php`** - Database setup script
3. **`/database/add_otp_table.sql`** - SQL migration file

### Modified Files:
1. **`/auth/index.html`**
   - Redesigned registration form with two-column layout
   - Added OTP verification modal with 6 input boxes
   - Added timer and resend button

2. **`/auth/style.css`**
   - Added `.register-two-col` grid layout
   - Added `.form-column` styles for left/right columns
   - Added `.otp-modal` and `.otp-input` styles
   - Added `.otp-timer` and `.resend-btn` styles
   - Updated responsive breakpoints

3. **`/auth/script.js`**
   - Complete OTP verification flow implementation
   - OTP input handling with auto-focus
   - Timer countdown logic
   - Resend OTP functionality
   - OTP verification via API

4. **`/api/user_auth.php`**
   - New `user_register` action: Generates OTP and sends email
   - New `verify_otp` action: Validates OTP and marks email as verified
   - New `resend_otp` action: Resends OTP if expired
   - Updated `check_session` action: Returns email verification status
   - All actions include proper error handling

## Registration Flow

### Step 1: User Registration
```
User fills form → Submits → Account created with email_verified = 0 → OTP generated → OTP sent to email → Modal appears
```

### Step 2: OTP Verification
```
User enters 6-digit OTP → Validates against stored OTP → Email marked as verified → Welcome email sent → User redirected
```

### Step 3: Login
```
User can login immediately after registration, but email_verified status is available in session
```

## API Endpoints

### 1. User Registration
**Endpoint**: `POST /api/user_auth.php`
**Action**: `user_register`

**Request Body**:
```json
{
  "action": "user_register",
  "name": "John Doe",
  "email": "john@example.com",
  "password": "secure_password",
  "confirmPassword": "secure_password",
  "phone": "+1234567890",
  "address": "123 Main St",
  "city": "New York",
  "state": "NY",
  "zip_code": "10001",
  "country": "USA"
}
```

**Response** (Success):
```json
{
  "success": true,
  "message": "Account created! OTP sent to your email.",
  "user_id": 1,
  "email": "john@example.com",
  "email_sent": true
}
```

### 2. Verify OTP
**Endpoint**: `POST /api/user_auth.php`
**Action**: `verify_otp`

**Request Body**:
```json
{
  "action": "verify_otp",
  "email": "john@example.com",
  "otp": "123456"
}
```

**Response** (Success):
```json
{
  "success": true,
  "message": "Email verified successfully!"
}
```

### 3. Resend OTP
**Endpoint**: `POST /api/user_auth.php`
**Action**: `resend_otp`

**Request Body**:
```json
{
  "action": "resend_otp",
  "email": "john@example.com"
}
```

**Response** (Success):
```json
{
  "success": true,
  "message": "OTP sent to your email",
  "email_sent": true
}
```

## Security Features

1. **OTP Expiration**: 3 minutes
2. **Attempt Limiting**: 3 attempts maximum per OTP
3. **Timing Safe Comparison**: Uses direct string comparison (can be upgraded to hash_equals())
4. **Database Indexing**: Optimized queries with indexes on email, user_id, and expires_at
5. **SQL Injection Prevention**: All queries use prepared statements
6. **Password Hashing**: bcrypt with PASSWORD_BCRYPT algorithm

## Testing the System

### Test 1: Basic Registration
1. Visit `http://localhost/cloths/auth/index.html`
2. Fill the registration form
3. Click "Create Account"
4. OTP modal should appear with 6 empty input boxes

### Test 2: OTP Verification
1. Check your email (or XAMPP mailoutput folder)
2. Copy the 6-digit OTP
3. Enter it in the OTP input boxes
4. Click "Verify Email"
5. Should see success message and redirect

### Test 3: Resend OTP
1. If OTP expires (3 minutes), click "Resend OTP"
2. New OTP should be generated and sent
3. Timer should reset

### Test 4: Error Handling
- Enter wrong OTP (should show error after 3 attempts)
- Try expired OTP (should show expiration message)
- Missing required fields (should show validation errors)

## Troubleshooting

### OTP not being sent?
1. Check if email service is enabled in PHP
2. Verify sender email address is configured
3. Check XAMPP mailoutput folder for test emails
4. Enable error reporting in php.ini

### Email table not found?
1. Run `http://localhost/cloths/database/setup_otp.php`
2. Or manually import `add_otp_table.sql` in phpMyAdmin

### OTP modal not appearing?
1. Check browser console for JavaScript errors
2. Verify API response includes success status
3. Check if JavaScript events are properly bound

### Users can't log in after email verification?
1. Check `users.email_verified` field is set to 1
2. Verify user `is_active` field is set to 1
3. Check password is correctly hashed

## Future Enhancements

1. **Email Provider Integration**:
   - PHPMailer with SMTP support
   - SendGrid API integration
   - AWS SES integration

2. **Advanced Security**:
   - Rate limiting on OTP requests
   - IP-based verification
   - Multi-factor authentication

3. **User Experience**:
   - SMS OTP as alternative
   - Biometric verification
   - Social login integration

4. **Analytics**:
   - Track OTP success rates
   - Monitor failed verification attempts
   - User registration funnel analysis

## Support

For issues or questions:
1. Check the browser console for JavaScript errors
2. Review PHP error logs in `C:\xampp\php\logs\`
3. Check XAMPP MySQL logs for database errors
4. Verify all files are in correct locations

---
**Last Updated**: December 1, 2025
**Version**: 1.0
