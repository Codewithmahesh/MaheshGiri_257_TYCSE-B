# Visual Preview - Form Redesign & OTP Verification

## 🎨 Registration Form - Two Column Layout

### Desktop View (1920px)
```
┌─────────────────────────────────────────────────────────────────┐
│                        rnd.apparel                              │
│                                                                 │
│ ┌──────────────────────────────────────────────────────────┐   │
│ │  CREATE ACCOUNT                                          │   │
│ │  Join rnd.apparel today                                  │   │
│ │                                                          │   │
│ │  ┌─────────────────────┬─────────────────────────────┐  │   │
│ │  │ LEFT COLUMN         │ RIGHT COLUMN                │  │   │
│ │  │                     │                             │  │   │
│ │  │ PERSONAL INFO       │ ADDRESS INFORMATION        │  │   │
│ │  │ ┌─────────────────┐ │ ┌─────────────────────────┐ │  │   │
│ │  │ │ Full Name       │ │ │ Street Address          │ │  │   │
│ │  │ │ (required)      │ │ │                         │ │  │   │
│ │  │ └─────────────────┘ │ └─────────────────────────┘ │  │   │
│ │  │                     │                             │  │   │
│ │  │ ┌─────────────────┐ │ ┌─────────────────────────┐ │  │   │
│ │  │ │ Email Address   │ │ │ City                    │ │  │   │
│ │  │ │ (required)      │ │ │                         │ │  │   │
│ │  │ └─────────────────┘ │ └─────────────────────────┘ │  │   │
│ │  │                     │                             │  │   │
│ │  │ ┌─────────────────┐ │ ┌─────────────────────────┐ │  │   │
│ │  │ │ Phone Number    │ │ │ State/Province          │ │  │   │
│ │  │ │ (optional)      │ │ │                         │ │  │   │
│ │  │ └─────────────────┘ │ └─────────────────────────┘ │  │   │
│ │  │                     │                             │  │   │
│ │  │ SECURITY            │ ┌─────────────────────────┐ │  │   │
│ │  │ ┌─────────────────┐ │ │ ZIP/Postal Code         │ │  │   │
│ │  │ │ Password        │ │ │                         │ │  │   │
│ │  │ │ (min 6 chars)   │ │ └─────────────────────────┘ │  │   │
│ │  │ │ [✓] Show/Hide   │ │                             │  │   │
│ │  │ └─────────────────┘ │ ┌─────────────────────────┐ │  │   │
│ │  │                     │ │ Country                 │ │  │   │
│ │  │ ┌─────────────────┐ │ │                         │ │  │   │
│ │  │ │ Confirm Pwd     │ │ └─────────────────────────┘ │  │   │
│ │  │ │ [✓] Show/Hide   │ │                             │  │   │
│ │  │ └─────────────────┘ │                             │  │   │
│ │  └─────────────────────┴─────────────────────────────┘  │   │
│ │                                                          │   │
│ │  ☑ I agree to the Terms & Conditions                    │   │
│ │                                                          │   │
│ │  ┌───────────────────────────────────────────────────┐  │   │
│ │  │        CREATE ACCOUNT                             │  │   │
│ │  └───────────────────────────────────────────────────┘  │   │
│ │                                                          │   │
│ │  Already have an account? Log in here                   │   │
│ │                                                          │   │
│ └──────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Tablet View (768px)
```
┌────────────────────────────────────┐
│      rnd.apparel                   │
│                                    │
│ ┌──────────────────────────────┐   │
│ │  CREATE ACCOUNT              │   │
│ │  Join rnd.apparel today      │   │
│ │                              │   │
│ │  PERSONAL INFORMATION        │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Full Name              │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Email Address          │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Phone Number           │  │   │
│ │  └────────────────────────┘  │   │
│ │                              │   │
│ │  ADDRESS INFORMATION         │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Street Address         │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ City                   │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ State/Province         │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ ZIP/Postal Code        │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Country                │  │   │
│ │  └────────────────────────┘  │   │
│ │                              │   │
│ │  SECURITY                    │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Password [✓]           │  │   │
│ │  └────────────────────────┘  │   │
│ │  ┌────────────────────────┐  │   │
│ │  │ Confirm Password [✓]   │  │   │
│ │  └────────────────────────┘  │   │
│ │                              │   │
│ │  ☑ I agree to Terms          │   │
│ │  [Create Account]            │   │
│ │                              │   │
│ │  Log in here                 │   │
│ │                              │   │
│ └──────────────────────────────┘   │
└────────────────────────────────────┘
```

### Mobile View (375px)
```
┌──────────────────────┐
│   rnd.apparel        │
│                      │
│ ┌──────────────────┐ │
│ │ CREATE ACCOUNT   │ │
│ │ Join us today    │ │
│ │                  │ │
│ │ PERSONAL INFO    │ │
│ │ ┌──────────────┐ │ │
│ │ │ Full Name    │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ Email        │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ Phone        │ │ │
│ │ └──────────────┘ │ │
│ │                  │ │
│ │ ADDRESS INFO     │ │
│ │ ┌──────────────┐ │ │
│ │ │ Address      │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ City         │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ State        │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ ZIP          │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ Country      │ │ │
│ │ └──────────────┘ │ │
│ │                  │ │
│ │ SECURITY         │ │
│ │ ┌──────────────┐ │ │
│ │ │ Password [✓] │ │ │
│ │ └──────────────┘ │ │
│ │ ┌──────────────┐ │ │
│ │ │ Confirm [✓]  │ │ │
│ │ └──────────────┘ │ │
│ │                  │ │
│ │ ☑ I agree       │ │
│ │ [Create]        │ │
│ │ Log in          │ │
│ │                  │ │
│ └──────────────────┘ │
└──────────────────────┘
```

---

## 📱 OTP Verification Modal

### Modal Appearance (After Registration)
```
┌─────────────────────────────────────────┐
│        Verify Your Email        ✕       │
│                                         │
│  We've sent a 6-digit code to your      │
│  email address                          │
│                                         │
│  ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐         │
│  │1 │ │2 │ │3 │ │4 │ │5 │ │6 │         │
│  └──┘ └──┘ └──┘ └──┘ └──┘ └──┘         │
│   (auto-focus) (auto-focus) ...         │
│                                         │
│  Code expires in: 2:45                  │
│  ⏱ (countdown timer)                   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │   VERIFY EMAIL BUTTON           │   │
│  └─────────────────────────────────┘   │
│                                         │
│  Didn't receive the code?               │
│  [Resend OTP] (disabled during timer)   │
│                                         │
└─────────────────────────────────────────┘
```

### OTP Input Interaction
```
Step 1: Click first box
┌─────┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐
│ 1   │ │   │ │   │ │   │ │   │ │   │
└─────┘ └───┘ └───┘ └───┘ └───┘ └───┘
 ↑
 (cursor active)

Step 2: Type digit "1"
┌─────┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐
│ 1   │ │   │ │   │ │   │ │   │ │   │
└─────┘ └───┘ └───┘ └───┘ └───┘ └───┘
         ↑
         (auto-focus to next)

Step 3: Type digit "2"
┌─────┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐
│ 1   │ │ 2 │ │   │ │   │ │   │ │   │
└─────┘ └───┘ └───┘ └───┘ └───┘ └───┘
               ↑
               (auto-focus continues)

Continue entering all 6 digits...

Complete:
┌─────┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐
│ 1   │ │ 2 │ │ 3 │ │ 4 │ │ 5 │ │ 6 │
└─────┘ └───┘ └───┘ └───┘ └───┘ └───┘
                                      ↑
                                      (click Verify)
```

### Alternative: Auto-Paste
```
1. User has: 123456 (copied from email)
2. Click first OTP box
3. Right-click → Paste
4. All 6 boxes automatically fill:

┌─────┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐
│ 1   │ │ 2 │ │ 3 │ │ 4 │ │ 5 │ │ 6 │
└─────┘ └───┘ └───┘ └───┘ └───┘ └───┘

5. Click "Verify Email" button
```

---

## 📊 User Journey

### Registration Journey (Happy Path)
```
START
  │
  ├─→ User visits: http://localhost/cloths/auth/index.html
  │
  ├─→ Click "Register here" link
  │
  ├─→ Form appears with 2 columns:
  │   - Left: Personal Info + Security
  │   - Right: Address Info
  │
  ├─→ User fills all fields
  │   (all inputs have placeholders & labels)
  │
  ├─→ User checks "I agree to Terms"
  │
  ├─→ User clicks "Create Account"
  │
  ├─→ Form validation
  │   ├─ Email format: ✅
  │   ├─ Password strength (6+ chars): ✅
  │   ├─ Passwords match: ✅
  │   └─ Terms agreed: ✅
  │
  ├─→ Account created
  │   └─ Database: user inserted with email_verified = 0
  │
  ├─→ OTP generated (6 digits)
  │   └─ Database: OTP stored with 3-min expiry
  │
  ├─→ Email sent
  │   └─ HTML formatted with OTP code
  │
  ├─→ OTP Modal appears
  │   ├─ 6 empty input boxes
  │   ├─ Timer: 3:00 countdown
  │   └─ Resend button (disabled)
  │
  ├─→ User opens email
  │   └─ Reads: "Your verification code: 123456"
  │
  ├─→ User enters OTP
  │   ├─ Types digit → auto-focus to next
  │   ├─ All 6 digits entered
  │   └─ Can also: Paste entire code
  │
  ├─→ User clicks "Verify Email"
  │
  ├─→ API validates:
  │   ├─ OTP matches: ✅
  │   ├─ Not expired: ✅
  │   ├─ Attempts < 3: ✅
  │   └─ Success!
  │
  ├─→ Database updated:
  │   ├─ users.email_verified = 1
  │   ├─ otp_verifications.is_verified = 1
  │   └─ Welcome email sent
  │
  ├─→ Success notification: "Email verified successfully!"
  │
  ├─→ Auto-redirect (2 seconds)
  │   └─ To: /home/index.html
  │
  ├─→ User logged in with active session
  │   └─ Full access to platform
  │
  END ✅
```

### Registration Journey (Error Cases)
```
Case 1: WRONG OTP
├─ User enters: 654321 (incorrect)
├─ Click "Verify Email"
├─ API response: ❌ "Invalid OTP. Please try again."
├─ Notification appears (red)
├─ Attempt counter increments: 1/3
├─ User can retry
└─ After 3 attempts: "Resend OTP" button enabled

Case 2: EXPIRED OTP
├─ Wait 3+ minutes
├─ Timer reaches: 0:00
├─ Notification: "OTP expired. Please request a new one."
├─ Resend button enabled
├─ Click "Resend OTP"
├─ New OTP sent to email
├─ Timer resets to 3:00
└─ User can verify with new code

Case 3: FORM VALIDATION ERROR
├─ User leaves "Email" field empty
├─ Click "Create Account"
├─ Browser: "Please fill out this field"
├─ Form doesn't submit
└─ User corrects and retries

Case 4: EMAIL ALREADY REGISTERED
├─ User tries to register with existing email
├─ Click "Create Account"
├─ API response: ❌ "Email already registered"
├─ Notification appears (red)
├─ User can try different email or login
└─ Form remains open
```

---

## 🎯 Key Interactions

### Form Field Focus Behavior
```
Normal focus:
│ Full Name                    │ ← Yellow border on focus
│ [__________________________] │
│                              │

Password field with toggle:
│ Password                     │
│ [_______________] [👁️ Icon] │
│                       ↑
│                       Click to show/hide
```

### Notification Toast
```
Top-right corner, auto-dismisses after 4 seconds:

Success (Green):
╔════════════════════════════════════════════╗
║ ✓ Email verified successfully!             ║
╚════════════════════════════════════════════╝

Error (Red):
╔════════════════════════════════════════════╗
║ ✗ Invalid OTP. Please try again.           ║
╚════════════════════════════════════════════╝
```

---

## 📧 Email Templates Preview

### OTP Email
```
From: rnd.apparel <noreply@rndapparel.com>
To: user@example.com
Subject: Email Verification - Your OTP Code

┌─────────────────────────────────────┐
│                                     │
│         rnd.apparel                 │
│                                     │
│  Hi John Doe,                       │
│                                     │
│  Welcome to rnd.apparel!            │
│  To complete your email              │
│  verification, please use the        │
│  following One-Time Password (OTP):  │
│                                     │
│  Your verification code:             │
│                                     │
│        1 2 3 4 5 6                  │
│                                     │
│  This code expires in 3 minutes     │
│                                     │
│  ⚠️ Never share this code with      │
│  anyone. rnd.apparel staff will      │
│  never ask for your OTP.            │
│                                     │
│  If you didn't create an account,   │
│  please ignore this email.          │
│                                     │
│  Best regards,                      │
│  The rnd.apparel Team               │
│                                     │
│  ─────────────────────────────────  │
│  © 2025 rnd.apparel                 │
│  This is automated, don't reply     │
│                                     │
└─────────────────────────────────────┘
```

### Welcome Email
```
From: rnd.apparel <noreply@rndapparel.com>
To: user@example.com
Subject: Welcome to rnd.apparel!

┌─────────────────────────────────────┐
│                                     │
│         rnd.apparel                 │
│                                     │
│  Hi John Doe,                       │
│                                     │
│  Your email has been verified!      │
│  Your account is now fully active.  │
│                                     │
│  You can now:                       │
│  • Browse our exclusive collection  │
│  • Add items to your wishlist       │
│  • Manage your orders              │
│  • View your profile and prefs      │
│                                     │
│  Start exploring and find your      │
│  perfect style at rnd.apparel!      │
│                                     │
│  Best regards,                      │
│  The rnd.apparel Team               │
│                                     │
│  ─────────────────────────────────  │
│  © 2025 rnd.apparel                 │
│  All rights reserved                │
│                                     │
└─────────────────────────────────────┘
```

---

## 🎬 Animation Examples

### Form Transition
```
Login Form visible → User clicks "Register here"
│
├─ Login form slides left (opacity 0)
└─ Register form slides in from left (opacity 1)
  Duration: 400ms with easing

Register form hidden → User clicks "Log in here"
│
├─ Register form slides left (opacity 0)
└─ Login form slides in from left (opacity 1)
  Duration: 400ms with easing
```

### Notification Toast
```
Notification appears:
└─ Slides in from right + fade in (300ms)
   From: x = 400px, opacity = 0
   To: x = 0px, opacity = 1

After 4 seconds:
└─ Slides out to right + fade out (300ms)
   From: x = 0px, opacity = 1
   To: x = 400px, opacity = 0
   Then: Element removed from DOM
```

### OTP Modal Appearance
```
Modal background: Dark overlay with fade-in
Modal content: Scales in from center (optional)

Initial: opacity = 0, display = none
Active: opacity = 1, display = flex

Smooth transition with CSS
```

---

This visual guide shows exactly what users will see at each step of the registration and OTP verification process.
