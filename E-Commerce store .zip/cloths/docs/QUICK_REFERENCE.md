# Quick Reference Card - Form Redesign & OTP System

## 🚀 Quick Start (Copy & Paste)

### Setup OTP Table
```
Browser: http://localhost/cloths/database/setup_otp.php
Response: {"success": true, "message": "OTP table created successfully"}
```

### Test Registration
```
1. http://localhost/cloths/auth/index.html
2. Click "Register here"
3. Fill form → Click "Create Account"
4. OTP modal appears → Check email for 6-digit code
5. Enter code → Click "Verify Email"
6. Success! ✅
```

---

## 📁 Key Files

| File | Purpose |
|------|---------|
| `auth/index.html` | Form + OTP modal |
| `auth/style.css` | Styling & responsive design |
| `auth/script.js` | Form & OTP logic |
| `api/user_auth.php` | Register, verify_otp, resend_otp |
| `api/email_service.php` | Email templates |
| `database/setup_otp.php` | Auto-create OTP table |

---

## 🔧 Configuration

### OTP Expiry Time
**File**: `api/user_auth.php:109`
```php
$expires_at = date('Y-m-d H:i:s', strtotime('+3 minutes'));
```

### Max Attempts
**File**: `api/user_auth.php:214`
```php
if ($attempts >= 3) {
```

### Email Sender
**File**: `api/email_service.php:8-9`
```php
private $senderEmail = 'noreply@rndapparel.com';
private $senderName = 'rnd.apparel';
```

---

## 🔐 API Endpoints

### 1. Register User
```
POST /api/user_auth.php
{
  "action": "user_register",
  "name": "John Doe",
  "email": "john@example.com",
  "password": "SecurePass123",
  "confirmPassword": "SecurePass123",
  "phone": "+1234567890",
  "address": "123 Main St",
  "city": "New York",
  "state": "NY",
  "zip_code": "10001",
  "country": "USA"
}
```

### 2. Verify OTP
```
POST /api/user_auth.php
{
  "action": "verify_otp",
  "email": "john@example.com",
  "otp": "123456"
}
```

### 3. Resend OTP
```
POST /api/user_auth.php
{
  "action": "resend_otp",
  "email": "john@example.com"
}
```

---

## 📊 Database Schema

### users table
```sql
-- New/Updated fields:
email_verified BOOLEAN DEFAULT 0  -- 0=unverified, 1=verified
```

### otp_verifications table (NEW)
```sql
CREATE TABLE otp_verifications (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  email VARCHAR(100) NOT NULL,
  otp_code VARCHAR(6) NOT NULL,
  attempts INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP,
  is_verified BOOLEAN DEFAULT 0
)
```

---

## 📱 Form Layout

### Desktop (900px+)
```
LEFT COLUMN          RIGHT COLUMN
Name                 Address
Email                City
Phone                State
                     ZIP
Password             Country
Confirm Pwd          
```

### Mobile (<640px)
```
Name
Email
Phone
Address
City
State
ZIP
Country
Password
Confirm Pwd
```

---

## 🎯 OTP Modal Features

- **6 Input Boxes**: One digit each
- **Auto-Focus**: Move to next box automatically
- **Auto-Paste**: Paste entire code at once
- **Timer**: 3:00 countdown
- **Resend**: Button enabled when timer expires
- **Error Messages**: Clear feedback on invalid codes
- **Max Attempts**: 3 wrong attempts before resend required

---

## ✅ Testing Checklist

- [ ] OTP table created successfully
- [ ] Registration form displays correctly
- [ ] Two-column layout shows on desktop
- [ ] Form responsive on mobile
- [ ] Can register new user
- [ ] OTP sent to email
- [ ] OTP modal appears after registration
- [ ] Can enter OTP codes
- [ ] Auto-paste OTP works
- [ ] Timer countdown visible
- [ ] Verification successful
- [ ] Email marked as verified in database
- [ ] User redirected to home page
- [ ] Welcome email sent
- [ ] Can login after verification
- [ ] Resend OTP works
- [ ] Wrong OTP shows error
- [ ] Expired OTP shows error
- [ ] Max attempts works

---

## 🐛 Debugging

### Check Email Output
```
Location: C:\xampp\mailoutput\
Open with: Any text editor
Look for: "OTP Code:" or "verification code"
```

### Check Database
```
URL: http://localhost/phpmyadmin
Database: cloths_db
Tables: users, otp_verifications
Check: email_verified field (should be 1 after verification)
```

### Check JavaScript Errors
```
Browser: F12 → Console tab
Look for: Red error messages
Check: Network tab for API calls
```

### Check PHP Errors
```
Location: C:\xampp\php\logs\php_error_log
Look for: Database or syntax errors
```

---

## 📞 Documentation Files

| File | Content |
|------|---------|
| `SETUP_CHECKLIST.md` | Setup instructions + configuration |
| `TESTING_GUIDE.md` | 10+ test scenarios + verification |
| `OTP_VERIFICATION_SETUP.md` | Technical implementation details |
| `FORM_REDESIGN_SUMMARY.md` | Overview of changes made |
| `VISUAL_PREVIEW.md` | UI/UX visual examples |
| `IMPLEMENTATION_COMPLETE.md` | Executive summary |

---

## 🎨 Color Scheme

| Element | Color |
|---------|-------|
| Primary Text | #000000 (Black) |
| Secondary Text | #666666 (Gray) |
| Background | #ffffff (White) |
| Input Border | #e0e0e0 (Light Gray) |
| Focus Border | #000000 (Black) |
| Success Message | #28a745 (Green) |
| Error Message | #dc3545 (Red) |
| Focus Shadow | rgba(0,0,0,0.05) |

---

## ⚙️ Key Functions

### JavaScript (script.js)
```
showOTPModal()              Show OTP modal
closeOTPModal()             Hide OTP modal
startOTPTimer()             Start 3-min countdown
updateTimerDisplay()        Update timer display
showNotification()          Show toast message
```

### PHP (user_auth.php)
```
user_register               Create account, generate OTP
verify_otp                  Validate OTP, mark verified
resend_otp                  Generate new OTP
```

### PHP (email_service.php)
```
sendOTPEmail()              Send OTP email
sendWelcomeEmail()          Send welcome email
```

---

## 🔐 Security

| Feature | Implementation |
|---------|-----------------|
| Password Hashing | bcrypt (PASSWORD_BCRYPT) |
| Min Password Length | 6 characters |
| SQL Injection Prevention | Prepared statements |
| OTP Expiration | 3 minutes |
| Attempt Limiting | Max 3 wrong attempts |
| Email Verification | Required for full account access |
| Session Security | PHP $_SESSION variables |

---

## 📊 Response Examples

### Success Response
```json
{
  "success": true,
  "message": "Email verified successfully!"
}
```

### Error Response
```json
{
  "success": false,
  "message": "Invalid OTP. Please try again."
}
```

---

## 🔗 URLs

| URL | Purpose |
|-----|---------|
| `http://localhost/cloths/auth/index.html` | Registration & Login |
| `http://localhost/cloths/database/setup_otp.php` | Auto-setup OTP table |
| `http://localhost/phpmyadmin` | Database management |
| `http://localhost/cloths/api/user_auth.php` | API endpoint |

---

## 💡 Tips

- **Test Emails**: Check `C:\xampp\mailoutput\` folder
- **OTP Code**: Usually formatted as "123456" or "1 2 3 4 5 6"
- **Paste OTP**: Click first box, paste entire code with Ctrl+V
- **Browser Validation**: Chrome/Firefox show validation errors for required fields
- **Session**: User is logged in during verification (email_verified = false initially)
- **Welcome Email**: Sent automatically after successful OTP verification

---

## 🎯 Form Validation

| Field | Rules |
|-------|-------|
| Name | Required, text only |
| Email | Required, valid email format |
| Password | Required, min 6 characters |
| Confirm Pwd | Required, must match password |
| Phone | Optional, text/numbers |
| Address | Optional, text |
| City | Optional, text |
| State | Optional, text |
| ZIP | Optional, text/numbers |
| Country | Optional, text |

---

## 📈 Performance Targets

- Form loads: < 2 seconds
- OTP email sent: < 5 seconds
- OTP verification: < 2 seconds
- Timer update: Every 1 second
- Modal animation: 300-400ms
- Form submission: No lag

---

## ✨ Features at a Glance

✅ Two-column responsive form
✅ 6-digit OTP verification
✅ Email delivery system
✅ 3-minute expiration timer
✅ Resend functionality
✅ 3-attempt limiting
✅ HTML email templates
✅ Password hashing (bcrypt)
✅ SQL injection prevention
✅ Complete documentation
✅ Multiple test scenarios
✅ Production-ready code

---

**Last Updated**: December 1, 2025
**Status**: ✅ Complete & Ready
**Version**: 1.0
