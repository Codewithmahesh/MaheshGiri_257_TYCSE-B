# Quick Testing Guide - Form Redesign & OTP Verification

## 🎯 Test Scenarios

### Test 1: Basic Registration Flow
**Objective**: Verify complete registration and OTP verification works

**Steps**:
1. Open http://localhost/cloths/auth/index.html
2. Click "Register here" link
3. Fill form:
   ```
   Name: John Doe
   Email: john@example.com
   Phone: +1234567890
   Address: 123 Main Street
   City: New York
   State: NY
   ZIP: 10001
   Country: USA
   Password: Password123
   Confirm Password: Password123
   ✓ Agree to Terms
   ```
4. Click "Create Account" button
5. **Expected**: OTP modal appears with 6 empty input boxes and 3:00 timer

**Verification**:
- Check XAMPP mailoutput folder or email inbox for OTP email
- OTP format: 6 digits (e.g., 123456)
- Email subject: "Email Verification - Your OTP Code"

---

### Test 2: OTP Input and Verification
**Objective**: Verify OTP input functionality and verification logic

**Steps**:
1. After registration (from Test 1), OTP modal is visible
2. Get OTP from email
3. Enter OTP by clicking first box and typing:
   - Type: 1 → auto-focus to next
   - Type: 2 → auto-focus to next
   - Continue until all 6 digits entered
4. Click "Verify Email" button

**Expected Behavior**:
- Each digit moves focus to next box automatically
- Success message: "Email verified successfully!"
- Page redirects to home after 2 seconds
- Database updated: users.email_verified = 1

**Error Cases**:
- Wrong OTP: Shows "Invalid OTP. Please try again."
- Expired OTP: Shows "OTP has expired. Please request a new one."
- Too many attempts (3+): Shows "Too many attempts. Please request a new OTP."

---

### Test 3: OTP Auto-Paste Feature
**Objective**: Verify users can paste entire OTP code

**Steps**:
1. Get OTP from email (e.g., "123456")
2. Click first OTP input box
3. Right-click → Paste the entire code
4. **Expected**: All 6 digits automatically fill in the boxes
5. Click "Verify Email" button

**Verification**:
- All boxes fill with correct digits
- Auto-paste only accepts 6 digits
- Non-numeric characters are rejected

---

### Test 4: Resend OTP Functionality
**Objective**: Verify users can request new OTP

**Steps**:
1. In OTP modal, wait for timer to expire (3:00 → 0:00)
   - OR manually navigate away and back to trigger resend need
2. Click "Resend OTP" button (should be enabled after timer expires)
3. **Expected**: New OTP generated and sent to email
4. Timer resets to 3:00
5. Input new OTP and verify

**Verification**:
- Resend button is disabled while timer is active (with opacity)
- Resend button becomes enabled when timer reaches 0:00
- New OTP is different from previous one
- New OTP works for verification

---

### Test 5: OTP Timer Countdown
**Objective**: Verify timer displays and expires correctly

**Steps**:
1. OTP modal appears after registration
2. Observe timer countdown from 3:00
3. Wait or manually trigger timer to reach 0:00
4. **Expected**: Resend button becomes enabled
5. Error message appears: "OTP expired. Please request a new one."

**Verification**:
- Timer displays in format: M:SS (e.g., 2:45, 1:30, 0:15)
- Timer counts down correctly
- Message appears when expired
- Resend button becomes enabled

---

### Test 6: Form Validation
**Objective**: Verify form validation before submission

**Steps**:

**Case 1 - Missing Required Fields**:
1. Fill only Name and Email
2. Click "Create Account"
3. **Expected**: Browser validation error (HTML5 required attribute)

**Case 2 - Invalid Email Format**:
1. Enter "notanemail" in email field
2. Click Create Account
3. **Expected**: Browser validation or API error

**Case 3 - Password Mismatch**:
1. Enter Password: "Pass123"
2. Enter Confirm: "Pass456"
3. Click "Create Account"
4. **Expected**: Error message: "Passwords do not match!"

**Case 4 - Weak Password**:
1. Enter Password: "Pass" (less than 6 chars)
2. Click "Create Account"
3. **Expected**: Error message: "Password must be at least 6 characters long"

**Case 5 - Terms Not Agreed**:
1. Fill all required fields correctly
2. Leave "I agree to Terms & Conditions" unchecked
3. Click "Create Account"
4. **Expected**: Form doesn't submit or shows error

---

### Test 7: Two-Column Form Layout (Responsive)

**Desktop (900px+)**:
```
┌────────────────────────────────────────┐
│         LEFT COLUMN | RIGHT COLUMN      │
│ Name            | Address               │
│ Email           | City                  │
│ Phone           | State                 │
│                 | ZIP                   │
│ Password        | Country               │
│ Confirm Pwd     |                       │
│ [Terms] [Create]                        │
└────────────────────────────────────────┘
```

**Tablet (640-900px)**:
- May show two columns or single column depending on content
- All fields still visible without excessive scrolling

**Mobile (<640px)**:
```
┌──────────────────┐
│ Name             │
│ Email            │
│ Phone            │
│ Address          │
│ City             │
│ State            │
│ ZIP              │
│ Country          │
│ Password         │
│ Confirm Pwd      │
│ [Terms] [Create] │
└──────────────────┘
```

**Testing Steps**:
1. Open form on desktop (zoom to 100%)
2. Verify two-column layout displays
3. Resize browser to tablet width (640-900px)
4. Verify layout adapts
5. Resize to mobile width (<640px)
6. Verify single column layout

---

### Test 8: Duplicate Email Prevention
**Objective**: Verify users can't register with existing email

**Steps**:
1. Register with email: "test@example.com"
2. Complete OTP verification
3. Try to register again with same email: "test@example.com"
4. Click "Create Account"
5. **Expected**: Error message: "Email already registered"

---

### Test 9: Form Sections and Organization
**Objective**: Verify form is properly organized into sections

**Visual Verification**:
- [x] "Personal Information" section title (left column)
  - Name field
  - Email field
  - Phone field
- [x] "Security" section title (left column)
  - Password field
  - Confirm Password field
- [x] "Address Information" section title (right column)
  - Address field
  - City field
  - State field
  - ZIP field
  - Country field
- [x] Terms checkbox (full width)
- [x] Create Account button (full width)

---

### Test 10: Error Handling and Messages

**Test Cases**:

| Scenario | Input | Expected Error |
|----------|-------|-----------------|
| Missing name | (empty) | Required validation |
| Invalid email | test@invalid | Invalid email format |
| Short password | Pass1 | Password must be at least 6 characters |
| Password mismatch | Pass123 / Pass456 | Passwords do not match! |
| Duplicate email | existing@email.com | Email already registered |
| Invalid OTP | 000000 | Invalid OTP. Please try again. |
| Expired OTP | (wait 3+ min) | OTP has expired. Please request a new one. |
| Max attempts | (wrong 3x) | Too many attempts. Please request a new OTP. |

---

## 📊 Performance Checklist

- [ ] Form loads in under 2 seconds
- [ ] OTP modal appears instantly after registration
- [ ] OTP email sent within 5 seconds
- [ ] OTP verification completes within 2 seconds
- [ ] No console errors or warnings
- [ ] All animations are smooth (no lag)
- [ ] Timer countdown is accurate

---

## 🔒 Security Testing

### SQL Injection Prevention
**Test**: Try to inject SQL in form fields
- Input: `"; DROP TABLE users; --`
- **Expected**: Treated as normal text, not executed
- **Verify**: Check database is unchanged

### Password Security
**Test**: Verify passwords are hashed
- **Steps**:
  1. Register with password: "SecurePass123"
  2. Check database users table
  3. **Expected**: password column shows hash (not readable plain text)
  4. **Verify**: Starts with `$2y$` (bcrypt indicator)

### Session Security
**Test**: Verify session is created after registration
- **Steps**:
  1. Register and verify email
  2. Check browser console: `console.log(sessionStorage)` or Network tab
  3. **Expected**: Session cookie created with secure flags
  4. **Verify**: Can call check_session API and get user info

---

## 🐛 Debugging Tips

### Check Email Delivery
```
Location: C:\xampp\mailoutput\
Files will be created with timestamp
View with any text editor
```

### Check Database
```
1. Visit: http://localhost/phpmyadmin
2. Database: cloths_db
3. Tables:
   - users (check: email_verified column)
   - otp_verifications (check: otp_code, expires_at columns)
```

### Check JavaScript Errors
```
1. Press F12 to open Developer Tools
2. Click "Console" tab
3. Look for red errors
4. Check Network tab for API calls
```

### Check PHP Errors
```
Location: C:\xampp\php\logs\
Files: php_error_log
Check for database connection or syntax errors
```

---

## ✅ Sign-Off Checklist

After testing, verify all items are checked:

- [ ] Two-column form layout displays correctly
- [ ] Form validation works for all fields
- [ ] Registration creates user account
- [ ] OTP is generated and sent to email
- [ ] OTP modal appears after registration
- [ ] OTP input works with auto-focus
- [ ] OTP verification marks email as verified
- [ ] Welcome email is sent after verification
- [ ] User can login after verification
- [ ] Resend OTP functionality works
- [ ] Timer countdown displays correctly
- [ ] Error messages display appropriately
- [ ] Form is responsive on mobile/tablet
- [ ] No console errors or warnings
- [ ] Database tables created successfully
- [ ] email_verified flag updates correctly

---

**Test Environment**: XAMPP Local Development
**Tested Date**: December 1, 2025
**Tester Name**: QA Team
**Status**: Ready for User Acceptance Testing ✅
