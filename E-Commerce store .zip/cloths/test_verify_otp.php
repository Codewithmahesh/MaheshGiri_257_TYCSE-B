<?php
header('Content-Type: application/json');
session_start();

require_once 'config/db_config.php';

// Use the last email we registered
$email = 'testuser1764603650@example.com';
$otp = '977436';  // From the log above

// Find user
$user_query = "SELECT id, name FROM users WHERE email = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("s", $email);
$user_stmt->execute();
$user_result = $user_stmt->get_result();

if ($user_result->num_rows === 0) {
    die(json_encode(['success' => false, 'message' => 'User not found']));
}

$user = $user_result->fetch_assoc();
$user_id = $user['id'];

// Check OTP
$otp_query = "SELECT id, otp_code, expires_at, attempts FROM otp_verifications 
              WHERE user_id = ? AND email = ? AND is_verified = 0
              ORDER BY created_at DESC LIMIT 1";
$otp_stmt = $conn->prepare($otp_query);
$otp_stmt->bind_param("is", $user_id, $email);
$otp_stmt->execute();
$otp_result = $otp_stmt->get_result();

if ($otp_result->num_rows === 0) {
    die(json_encode(['success' => false, 'message' => 'No active OTP found']));
}

$otp_record = $otp_result->fetch_assoc();
$otp_id = $otp_record['id'];
$stored_otp = $otp_record['otp_code'];
$expires_at = $otp_record['expires_at'];

echo json_encode([
    'success' => true,
    'message' => 'OTP record found',
    'stored_otp' => $stored_otp,
    'provided_otp' => $otp,
    'expires_at' => $expires_at,
    'is_expired' => strtotime($expires_at) < time(),
    'otp_matches' => $otp === $stored_otp
]);
?>
