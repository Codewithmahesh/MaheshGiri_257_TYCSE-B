<?php
/**
 * Email Configuration for SMTP
 * 
 * Supports multiple email providers:
 * 1. Gmail SMTP
 * 2. Mailtrap (for development)
 * 3. Custom SMTP server
 */

// Email Provider Settings
// Options: 'gmail', 'mailtrap', 'custom', 'php_mail'
define('EMAIL_PROVIDER', 'gmail');

// GMAIL SETTINGS (if using Gmail)
define('GMAIL_SENDER_EMAIL', 'girimahesh1514@gmail.com');  // Change this to your Gmail address
define('GMAIL_APP_PASSWORD', 'flibucgzlflrpcrr');     // Generate at: https://myaccount.google.com/apppasswords
define('GMAIL_SENDER_NAME', 'rnd.apparel');

// MAILTRAP SETTINGS (if using Mailtrap)
define('MAILTRAP_API_TOKEN', 'your-mailtrap-token');
define('MAILTRAP_SENDER_EMAIL', 'hello@rndapparel.com');
define('MAILTRAP_SENDER_NAME', 'rnd.apparel');

// CUSTOM SMTP SETTINGS (if using custom server)
define('CUSTOM_SMTP_HOST', 'smtp.example.com');
define('CUSTOM_SMTP_PORT', 587);
define('CUSTOM_SMTP_USERNAME', 'your-username');
define('CUSTOM_SMTP_PASSWORD', 'your-password');
define('CUSTOM_SMTP_SECURITY', 'tls'); // 'tls' or 'ssl'
define('CUSTOM_SENDER_EMAIL', 'noreply@example.com');
define('CUSTOM_SENDER_NAME', 'Your Company');

// Fallback email (for development/testing)
define('FALLBACK_EMAIL_LOG', true); // Also save emails to log file
