# Project Architecture & Flow Diagrams

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT (Browser)                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────┐         ┌──────────────────────────┐      │
│  │  User Auth Page  │         │   Admin Login Page       │      │
│  │  (HTML + JS)     │         │   (HTML + JS)            │      │
│  │                  │         │                          │      │
│  │ - Login Form     │         │ - Admin Login Form       │      │
│  │ - Register Form  │         │ - Password Toggle        │      │
│  │ - Validation     │         │ - Notifications          │      │
│  └────────┬─────────┘         └────────┬─────────────────┘      │
│           │                            │                         │
│           │ Form Submission            │ Form Submission         │
│           │ (POST JSON)                │ (POST JSON)            │
└───────────┼────────────────────────────┼──────────────────────────┘
            │                            │
            ▼                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                     PHP Backend Server                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │              API Layer (PHP Files)                        │  │
│  ├───────────────────────────────────────────────────────────┤  │
│  │                                                            │  │
│  │  ┌──────────────────────┐  ┌───────────────────────┐     │  │
│  │  │  user_auth.php       │  │  admin_auth.php       │     │  │
│  │  │  ─────────────────   │  │  ─────────────────    │     │  │
│  │  │  - user_login        │  │  - admin_login        │     │  │
│  │  │  - user_register     │  │  - admin_register     │     │  │
│  │  │  - check_session     │  │  - check_session      │     │  │
│  │  │  - logout            │  │  - logout             │     │  │
│  │  └──────────┬───────────┘  └───────────┬───────────┘     │  │
│  │             │                          │                  │  │
│  │  ┌──────────────────────────────────────────┐             │  │
│  │  │  db_config.php                           │             │  │
│  │  │  (Database Connection Configuration)     │             │  │
│  │  └────────────────┬─────────────────────────┘             │  │
│  │                   │                                        │  │
│  └───────────────────┼────────────────────────────────────────┘  │
│                      │                                            │
│                      ▼                                            │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │            Session Management Layer                       │  │
│  ├───────────────────────────────────────────────────────────┤  │
│  │  Session Variables:                                       │  │
│  │  - $_SESSION['user_id']      (for users)                 │  │
│  │  - $_SESSION['user_name']    (for users)                 │  │
│  │  - $_SESSION['user_type']    ('user' or 'admin')         │  │
│  │  - $_SESSION['admin_id']     (for admins)                │  │
│  │  - $_SESSION['admin_role']   ('super_admin','admin'...)  │  │
│  └───────────────────────────────────────────────────────────┘  │
│                      │                                            │
└──────────────────────┼────────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                   MySQL Database                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Database: cloths_db                                            │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   users      │  │   admins     │  │  products    │          │
│  │ ────────────│  │ ────────────│  │ ────────────│          │
│  │ id (PK)     │  │ id (PK)     │  │ id (PK)     │          │
│  │ name        │  │ name        │  │ name        │          │
│  │ email (UQ)  │  │ email (UQ)  │  │ category    │          │
│  │ password    │  │ password    │  │ price       │          │
│  │ phone       │  │ role        │  │ stock_qty   │          │
│  │ address     │  │ is_active   │  │ is_active   │          │
│  │ created_at  │  │ created_at  │  │ created_at  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   orders     │  │  order_items │  │    cart      │          │
│  │ ────────────│  │ ────────────│  │ ────────────│          │
│  │ id (PK)     │  │ id (PK)     │  │ id (PK)     │          │
│  │ user_id (FK)│  │ order_id(FK)│  │ user_id(FK) │          │
│  │ total       │  │ product_id  │  │ product_id  │          │
│  │ status      │  │ quantity    │  │ quantity    │          │
│  │ created_at  │  │ created_at  │  │ added_at    │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐                             │
│  │  wishlist    │  │   reviews    │                             │
│  │ ────────────│  │ ────────────│                             │
│  │ id (PK)     │  │ id (PK)     │                             │
│  │ user_id (FK)│  │ product_id  │                             │
│  │ product_id  │  │ user_id (FK)│                             │
│  │ added_at    │  │ rating      │                             │
│  └──────────────┘  │ comment     │                             │
│                    │ created_at  │                             │
│                    └──────────────┘                             │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## User Registration Flow

```
START
  │
  ▼
┌─────────────────────────────┐
│  User fills Registration    │
│  Form (Client-side)         │
│ - Name                      │
│ - Email                     │
│ - Password                  │
│ - Confirm Password          │
│ - Accept Terms              │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Client-side Validation (script.js)    │
│ ✓ Passwords match?                      │
│ ✓ Password length ≥ 6?                  │
│ ✓ All fields filled?                    │
└────────┬────────────────────────────────┘
         │
      NO │  (Show error)
         ├─────────────────┐
         │                 │
      YES│                 │
         │         (Notification)
         ▼                 │
┌─────────────────────────────────────────┐
│  POST to /api/user_auth.php             │
│  action=user_register                   │
│  name, email, password, confirmPassword │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  user_auth.php Processing               │
│ ✓ Validate email format                 │
│ ✓ Passwords match?                      │
│ ✓ Password length ≥ 6?                  │
│ ✓ All fields non-empty?                 │
└────────┬────────────────────────────────┘
         │
      NO │  (Return error JSON)
         ├──────────────────┐
         │                  │
      YES│                  │
         │          (Show notification)
         ▼                  │
┌─────────────────────────────────────────┐
│  Check if email already exists          │
│  SELECT FROM users WHERE email=?        │
└────────┬────────────────────────────────┘
         │
     YES │  (Email exists)
         ├─────────────────────────────┐
         │ (Return: "Email registered")│
      NO │                             │
         │                    (Error)  │
         ▼                             │
┌─────────────────────────────────────────┐
│  Hash password with bcrypt              │
│  password_hash($pwd, PASSWORD_BCRYPT)   │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Insert user into database              │
│  INSERT INTO users                      │
│  (name, email, password)                │
└────────┬────────────────────────────────┘
         │
      FAIL │  (Query error)
         ├──────────────────┐
         │ (Return error)   │
       OK │                 │
         │         (Show notification)
         ▼                  │
┌─────────────────────────────────────────┐
│  Create Session                         │
│  $_SESSION['user_id']                   │
│  $_SESSION['user_name']                 │
│  $_SESSION['user_email']                │
│  $_SESSION['user_type'] = 'user'        │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Return Success JSON Response           │
│  {                                      │
│    "success": true,                     │
│    "message": "Account created",        │
│    "redirect": "../home/index.html"     │
│  }                                      │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  JavaScript receives response           │
│  Show success notification              │
│  Wait 2 seconds                         │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Redirect to home page                  │
│  window.location.href = redirect        │
└────────┬────────────────────────────────┘
         │
         ▼
        END
```

---

## User Login Flow

```
START
  │
  ▼
┌─────────────────────────────┐
│  User fills Login Form      │
│ - Email                     │
│ - Password                  │
│ - Remember me (optional)    │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Client-side Validation (script.js)    │
│ ✓ Email filled?                         │
│ ✓ Password filled?                      │
└────────┬────────────────────────────────┘
         │
      NO │  (Show error)
         ├─────────────────┐
         │                 │
      YES│                 │
         │         (Notification)
         ▼                 │
┌─────────────────────────────────────────┐
│  POST to /api/user_auth.php             │
│  action=user_login                      │
│  email, password                        │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  user_auth.php Processing               │
│ ✓ Email and password non-empty?         │
└────────┬────────────────────────────────┘
         │
      NO │  (Return error JSON)
         ├──────────────────┐
         │                  │
      YES│                  │
         │          (Show notification)
         ▼                  │
┌─────────────────────────────────────────┐
│  Query database for user                │
│  SELECT * FROM users                    │
│  WHERE email=? AND is_active=1          │
└────────┬────────────────────────────────┘
         │
     NOT FOUND │
         ├──────────────────────────┐
         │ (Return: "Invalid cred") │
       FOUND │                       │
         │                  (Error) │
         ▼                          │
┌─────────────────────────────────────────┐
│  Verify password                        │
│  password_verify($pwd, $dbPassword)     │
└────────┬────────────────────────────────┘
         │
     FALSE │  (Wrong password)
         ├─────────────────────┐
         │ (Return: "Invalid") │
      TRUE │                    │
         │            (Error)  │
         ▼                     │
┌─────────────────────────────────────────┐
│  Create Session                         │
│  $_SESSION['user_id']                   │
│  $_SESSION['user_name']                 │
│  $_SESSION['user_email']                │
│  $_SESSION['user_type'] = 'user'        │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Return Success JSON Response           │
│  {                                      │
│    "success": true,                     │
│    "message": "Login successful",       │
│    "redirect": "../home/index.html"     │
│  }                                      │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  JavaScript receives response           │
│  Check Remember me checkbox             │
└────────┬────────────────────────────────┘
         │
    CHECKED │  Store email in localStorage
         │  localStorage.setItem(email)
    UNCHECKED│
         │
         ▼
┌─────────────────────────────────────────┐
│  Show success notification              │
│  Wait 2 seconds                         │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Redirect to home page                  │
│  window.location.href = redirect        │
└────────┬────────────────────────────────┘
         │
         ▼
        END
```

---

## Admin Login Flow

```
START
  │
  ▼
┌─────────────────────────────┐
│  Admin fills Login Form     │
│ - Email                     │
│ - Password                  │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Client-side Validation (script.js)    │
│ ✓ Email filled?                         │
│ ✓ Password filled?                      │
└────────┬────────────────────────────────┘
         │
      NO │  (Show error)
         ├─────────────────┐
         │                 │
      YES│                 │
         │         (Notification)
         ▼                 │
┌─────────────────────────────────────────┐
│  POST to /api/admin_auth.php            │
│  action=admin_login                     │
│  email, password                        │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  admin_auth.php Processing              │
│ ✓ Email and password non-empty?         │
└────────┬────────────────────────────────┘
         │
      NO │  (Return error JSON)
         ├──────────────────┐
         │                  │
      YES│                  │
         │          (Show notification)
         ▼                  │
┌─────────────────────────────────────────┐
│  Query database for admin               │
│  SELECT * FROM admins                   │
│  WHERE email=? AND is_active=1          │
└────────┬────────────────────────────────┘
         │
     NOT FOUND │
         ├──────────────────────────┐
         │ (Return: "Invalid cred") │
       FOUND │                       │
         │                  (Error) │
         ▼                          │
┌─────────────────────────────────────────┐
│  Verify password                        │
│  password_verify($pwd, $dbPassword)     │
└────────┬────────────────────────────────┘
         │
     FALSE │  (Wrong password)
         ├─────────────────────┐
         │ (Return: "Invalid") │
      TRUE │                    │
         │            (Error)  │
         ▼                     │
┌─────────────────────────────────────────┐
│  Update last_login timestamp            │
│  UPDATE admins                          │
│  SET last_login=NOW()                   │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Create Session                         │
│  $_SESSION['admin_id']                  │
│  $_SESSION['admin_name']                │
│  $_SESSION['admin_email']               │
│  $_SESSION['admin_role'] (super_admin,  │
│  admin, or moderator)                   │
│  $_SESSION['user_type'] = 'admin'       │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Return Success JSON Response           │
│  {                                      │
│    "success": true,                     │
│    "message": "Login successful",       │
│    "redirect": "../dashboard/index.php" │
│  }                                      │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  JavaScript receives response           │
│  Show success notification              │
│  Wait 2 seconds                         │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Redirect to dashboard                  │
│  window.location.href = redirect        │
└────────┬────────────────────────────────┘
         │
         ▼
        END
```

---

## Session Check Flow

```
START (Page Load or Need Verification)
  │
  ▼
┌─────────────────────────────────────────┐
│  POST to /api/user_auth.php or          │
│  /api/admin_auth.php                    │
│  action=check_session                   │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Check if session exists                │
│  isset($_SESSION['user_id']) OR         │
│  isset($_SESSION['admin_id'])           │
└────────┬────────────────────────────────┘
         │
    LOGGED IN │
         ├──────────────────────┐
         │ (Return user/admin)  │
    NOT LOGGED IN│
         │                      │
         ▼                      ▼
┌──────────────────┐  ┌──────────────────────┐
│  Return:         │  │  Return:             │
│  {               │  │  {                   │
│    "success":    │  │    "success": true,  │
│    true,         │  │    "logged_in": true,│
│    "logged_in":  │  │    "user": {         │
│    false         │  │      "id": 1,        │
│  }               │  │      "name": "John", │
│                  │  │      "email": "..."  │
│                  │  │    }                 │
│                  │  │  }                   │
└──────────────────┘  └──────────────────────┘
         │                      │
         ▼                      ▼
        END                    END
```

---

## Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    User Browser                             │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  JavaScript (script.js)                                      │
│  ↓ Collects form data                                        │
│  ↓ Validates locally                                         │
│  ↓ Sends POST request to API                                 │
│                                                               │
└────────────────────────────┬────────────────────────────────┘
                             │
                             │ HTTP POST (JSON)
                             │ {action, email, password, ...}
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                    PHP Backend                              │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  API Endpoint (user_auth.php or admin_auth.php)             │
│  ↓ Receive POST data                                         │
│  ↓ Validate input                                            │
│  ↓ Parse action parameter                                    │
│                                                               │
└────────────────────────────┬────────────────────────────────┘
                             │
                ┌────────────┼────────────┐
                │            │            │
            LOGIN │      REGISTER │   CHECK_SESSION
                │            │            │
                ▼            ▼            ▼
            ┌─────────┐  ┌─────────┐  ┌──────────┐
            │Check    │  │Validate │  │Check     │
            │email in │  │email &  │  │session   │
            │database │  │password │  │exists    │
            └────┬────┘  └────┬────┘  └──────┬───┘
                 │            │             │
         ┌───────┴────────────┴────────────┴────────┐
         │                                           │
    ERROR CASE                                  SUCCESS CASE
         │                                           │
         ▼                                           ▼
    ┌─────────────┐                         ┌─────────────────┐
    │Return Error │                         │Create/Update    │
    │JSON         │                         │Session Variables│
    │{success:    │                         └────────┬────────┘
    │ false,      │                                 │
    │ message: ...}                                 │
    └─────────────┘                                 ▼
         │                                  ┌─────────────────┐
         │                                  │Return Success   │
         │                                  │JSON with data   │
         │                                  │{success: true,  │
         │                                  │ user/admin: ...}│
         │                                  └────────┬────────┘
         │                                           │
         └───────────────┬───────────────────────────┘
                         │
                         │ HTTP Response (JSON)
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    User Browser                             │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  JavaScript (script.js)                                      │
│  ↓ Receives JSON response                                    │
│  ↓ Checks success flag                                       │
│  ↓ Shows notification (success/error)                        │
│  ↓ If success: redirects to new page                         │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## File Dependency Tree

```
cloths/
├── home/
│   └── index.html
│       ↓ Links to
│       ├── auth/index.html
│       └── admin/login.html
│
├── auth/
│   ├── index.html
│   │   ↓ Includes
│   │   └── script.js
│   │       ↓ Calls API
│   │       └── api/user_auth.php
│   │           ↓ Uses config
│   │           └── config/db_config.php
│   │               ↓ Connects to
│   │               └── MySQL Database
│   │
│   ├── script.js (UPDATED)
│   │   ↓ Posts to
│   │   └── api/user_auth.php
│   │
│   └── style.css
│
├── admin/
│   └── login.html
│       ↓ Includes JS
│       └── JavaScript (inline)
│           ↓ Calls API
│           └── api/admin_auth.php
│               ↓ Uses config
│               └── config/db_config.php
│                   ↓ Connects to
│                   └── MySQL Database
│
├── api/
│   ├── user_auth.php
│   │   ├── Requires config/db_config.php
│   │   └── Queries users table
│   │
│   └── admin_auth.php
│       ├── Requires config/db_config.php
│       └── Queries admins table
│
├── config/
│   └── db_config.php
│       ↓ Configures
│       └── MySQL Connection
│
└── database/
    └── cloths_db.sql
        ↓ Creates database structure
        └── 8 Tables (users, admins, products, etc.)
```

This architecture ensures proper separation of concerns and makes it easy to maintain and scale!
