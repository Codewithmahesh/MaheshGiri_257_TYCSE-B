<?php
require_once 'db_config.php';

$name = "Checkout Tester";
$email = "test_checkout@example.com";
$password = password_hash("password123", PASSWORD_DEFAULT);

// 1. Create User
$check_user = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check_user->bind_param("s", $email);
$check_user->execute();
$result = $check_user->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $user_id = $user['id'];
    echo "User already exists. ID: $user_id<br>";
} else {
    $insert_user = $conn->prepare("INSERT INTO users (name, email, password, is_active) VALUES (?, ?, ?, 1)");
    $insert_user->bind_param("sss", $name, $email, $password);
    if ($insert_user->execute()) {
        $user_id = $conn->insert_id;
        echo "User created. ID: $user_id<br>";
    } else {
        die("Failed to create user: " . $conn->error);
    }
}

// 2. Get a Product
$product_res = $conn->query("SELECT id FROM products LIMIT 1");
if ($product_res->num_rows > 0) {
    $product = $product_res->fetch_assoc();
    $product_id = $product['id'];
    echo "Using Product ID: $product_id<br>";
} else {
    die("No products found in database.");
}

// 3. Add to Cart
$check_cart = $conn->prepare("SELECT id FROM cart WHERE user_id = ? AND product_id = ?");
$check_cart->bind_param("ii", $user_id, $product_id);
$check_cart->execute();
if ($check_cart->get_result()->num_rows == 0) {
    $add_cart = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 2)");
    $add_cart->bind_param("ii", $user_id, $product_id);
    if ($add_cart->execute()) {
        echo "Added product $product_id to cart for user $user_id.<br>";
    } else {
        echo "Failed to add to cart: " . $conn->error . "<br>";
    }
} else {
    echo "Product already in cart.<br>";
}

echo "Setup Complete. You can now login as $email / password123";
?>
