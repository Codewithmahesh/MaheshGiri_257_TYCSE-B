<?php
// Test login endpoint
error_reporting(E_ALL);
ini_set('display_errors', 1);

$_POST['action'] = 'user_login';
$_POST['email'] = 'girimahesh1514@gmail.com';
$_POST['password'] = 'test123'; // Use the password you set
$_POST['remember_me'] = 'true';

session_start();

require_once 'api/user_auth.php';
?>
