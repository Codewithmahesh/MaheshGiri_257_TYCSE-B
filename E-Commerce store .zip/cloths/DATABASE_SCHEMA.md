# Database Schema - Visual Reference

## Entity Relationship Diagram (ERD)

```
┌─────────────┐         ┌──────────────┐
│   USERS     │         │    ADMINS    │
├─────────────┤         ├──────────────┤
│ id (PK)     │         │ id (PK)      │
│ name        │         │ name         │
│ email (UQ)  │         │ email (UQ)   │
│ password    │         │ password     │
│ phone       │         │ role         │
│ address     │         │ phone        │
│ city        │         │ is_active    │
│ state       │         │ last_login   │
│ zip_code    │         │ created_at   │
│ country     │         │ updated_at   │
│ profile_pic │         └──────────────┘
│ is_active   │               │
│ email_ver   │               │ (1:N)
│ created_at  │               ↓
│ updated_at  │         ┌──────────────┐
└─────┬───────┘         │  PRODUCTS    │
      │ (1:N)           ├──────────────┤
      ├──────────┬──────→│ id (PK)      │
      │          │      │ name         │
      │          │      │ description  │
      ↓          │      │ category     │
  ┌────────┐     │      │ price        │
  │ ORDERS │     │      │ discount %   │
  ├────────┤     │      │ image_url    │
  │ id (PK)│     │      │ stock_qty    │
  │ user_id├─────┘      │ is_active    │
  │ total  │            │ created_by───┘
  │ status │            │ created_at
  │ payment│            │ updated_at
  │ address│            └──┬───────────┘
  │ notes  │               │ (1:N)
  │ created│               │
  └───┬────┘               ↓
      │ (1:N)          ┌────────────┐
      │                │  REVIEWS   │
      │                ├────────────┤
      ↓                │ id (PK)    │
  ┌──────────┐         │ product_id │
  │ORDER_ITEMS          │ user_id────┘
  ├──────────┤         │ rating     │
  │ id (PK)  │         │ comment    │
  │ order_id │         │ is_approved│
  │ product_id          │ created_at │
  │ quantity │         │ updated_at │
  │ price    │         └────────────┘
  │ created  │
  └─────┬────┘
        │ (1:N)
        ↓
   ┌────────────┐
   │    CART    │
   ├────────────┤
   │ id (PK)    │
   │ user_id────┘
   │ product_id │
   │ quantity   │
   │ added_at   │
   └────────────┘

        ┌───────────────┐
        │   WISHLIST    │
        ├───────────────┤
        │ id (PK)       │
        │ user_id───────┘
        │ product_id    │
        │ added_at      │
        └───────────────┘
```

## Table Details

### 1. USERS
**Purpose:** Store customer account information

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| name | VARCHAR(100) | NOT NULL | Full name |
| email | VARCHAR(100) | UNIQUE, NOT NULL | Login email |
| password | VARCHAR(255) | NOT NULL | Bcrypt hashed |
| phone | VARCHAR(20) | | Optional |
| address | VARCHAR(255) | | Street address |
| city | VARCHAR(50) | | City |
| state | VARCHAR(50) | | State/Province |
| zip_code | VARCHAR(20) | | Postal code |
| country | VARCHAR(50) | | Country |
| profile_picture | VARCHAR(255) | | Image URL |
| is_active | BOOLEAN | DEFAULT 1 | Account status |
| email_verified | BOOLEAN | DEFAULT 0 | Email verification status |
| created_at | TIMESTAMP | DEFAULT NOW | Account creation |
| updated_at | TIMESTAMP | ON UPDATE NOW | Last update |

**Indexes:** email, created_at

---

### 2. ADMINS
**Purpose:** Store admin/staff account information

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| name | VARCHAR(100) | NOT NULL | Admin name |
| email | VARCHAR(100) | UNIQUE, NOT NULL | Login email |
| password | VARCHAR(255) | NOT NULL | Bcrypt hashed |
| role | ENUM | DEFAULT 'admin' | super_admin, admin, moderator |
| phone | VARCHAR(20) | | Optional |
| profile_picture | VARCHAR(255) | | Image URL |
| is_active | BOOLEAN | DEFAULT 1 | Account status |
| last_login | TIMESTAMP | NULL | Last login time |
| created_at | TIMESTAMP | DEFAULT NOW | Account creation |
| updated_at | TIMESTAMP | ON UPDATE NOW | Last update |

**Indexes:** email, role, created_at

---

### 3. PRODUCTS
**Purpose:** Store product catalog

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| name | VARCHAR(255) | NOT NULL | Product name |
| description | TEXT | | Product details |
| category | ENUM | NOT NULL | women_tops, women_bottoms, women_accessories, men_tops, men_bottoms, men_accessories |
| price | DECIMAL(10, 2) | NOT NULL | Base price |
| discount_percentage | INT | DEFAULT 0 | Sale discount % |
| image_url | VARCHAR(255) | | Product image |
| stock_quantity | INT | DEFAULT 0 | Available stock |
| is_active | BOOLEAN | DEFAULT 1 | Listed status |
| created_by | INT | FK to admins | Admin who added |
| created_at | TIMESTAMP | DEFAULT NOW | Creation date |
| updated_at | TIMESTAMP | ON UPDATE NOW | Last update |

**Indexes:** category, price, created_at
**Foreign Keys:** created_by → admins(id)

---

### 4. ORDERS
**Purpose:** Store customer orders

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| user_id | INT | FK to users | Customer |
| total_amount | DECIMAL(10, 2) | NOT NULL | Order total |
| status | ENUM | DEFAULT 'pending' | pending, processing, shipped, delivered, cancelled |
| payment_method | ENUM | NOT NULL | credit_card, debit_card, paypal, bank_transfer |
| shipping_address | VARCHAR(255) | NOT NULL | Delivery address |
| notes | TEXT | | Order notes |
| created_at | TIMESTAMP | DEFAULT NOW | Order date |
| updated_at | TIMESTAMP | ON UPDATE NOW | Last update |

**Indexes:** user_id, status, created_at
**Foreign Keys:** user_id → users(id) CASCADE

---

### 5. ORDER_ITEMS
**Purpose:** Store individual items in orders

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| order_id | INT | FK to orders | Which order |
| product_id | INT | FK to products | Which product |
| quantity | INT | NOT NULL | Quantity ordered |
| price | DECIMAL(10, 2) | NOT NULL | Price at purchase |
| created_at | TIMESTAMP | DEFAULT NOW | |

**Indexes:** order_id
**Foreign Keys:** order_id → orders(id) CASCADE, product_id → products(id)

---

### 6. CART
**Purpose:** Store shopping cart items

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| user_id | INT | FK to users | Customer |
| product_id | INT | FK to products | Product in cart |
| quantity | INT | NOT NULL | Quantity in cart |
| added_at | TIMESTAMP | DEFAULT NOW | When added |

**Indexes:** user_id
**Unique Key:** user_id + product_id (one entry per product per user)
**Foreign Keys:** user_id → users(id) CASCADE, product_id → products(id) CASCADE

---

### 7. WISHLIST
**Purpose:** Store user wishlist items

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| user_id | INT | FK to users | Customer |
| product_id | INT | FK to products | Wishlisted product |
| added_at | TIMESTAMP | DEFAULT NOW | When added |

**Indexes:** user_id
**Unique Key:** user_id + product_id
**Foreign Keys:** user_id → users(id) CASCADE, product_id → products(id) CASCADE

---

### 8. REVIEWS
**Purpose:** Store product reviews and ratings

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | |
| product_id | INT | FK to products | Product being reviewed |
| user_id | INT | FK to users | Reviewer |
| rating | INT | NOT NULL, CHECK 1-5 | Star rating 1-5 |
| comment | TEXT | | Review text |
| is_approved | BOOLEAN | DEFAULT 0 | Moderation status |
| created_at | TIMESTAMP | DEFAULT NOW | Review date |
| updated_at | TIMESTAMP | ON UPDATE NOW | Last update |

**Indexes:** product_id, user_id, created_at
**Foreign Keys:** product_id → products(id) CASCADE, user_id → users(id) CASCADE

---

## Authentication Flow

### User Registration
```
User Form → user_auth.php (user_register)
    ↓
Validate data (email format, password length, etc.)
    ↓
Check if email exists (prevent duplicates)
    ↓
Hash password with bcrypt
    ↓
Insert into users table
    ↓
Create session (user_id, user_name, user_email, user_type='user')
    ↓
Redirect to home
```

### User Login
```
User Form → user_auth.php (user_login)
    ↓
Get user from email where is_active=1
    ↓
Verify password with bcrypt
    ↓
Create session (user_id, user_name, user_email, user_type='user')
    ↓
Redirect to home
```

### Admin Login
```
Admin Form → admin_auth.php (admin_login)
    ↓
Get admin from email where is_active=1
    ↓
Verify password with bcrypt
    ↓
Update last_login timestamp
    ↓
Create session (admin_id, admin_name, admin_email, admin_role, user_type='admin')
    ↓
Redirect to dashboard
```

## Sample SQL Queries

### Get user with all orders
```sql
SELECT u.*, COUNT(o.id) as total_orders, SUM(o.total_amount) as lifetime_spent
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE u.id = ?
GROUP BY u.id;
```

### Get products in a category with reviews
```sql
SELECT p.*, AVG(r.rating) as avg_rating, COUNT(r.id) as review_count
FROM products p
LEFT JOIN reviews r ON p.id = r.product_id AND r.is_approved = 1
WHERE p.category = ? AND p.is_active = 1
GROUP BY p.id
ORDER BY p.created_at DESC;
```

### Get order details with items
```sql
SELECT o.*, u.name, u.email, u.address,
       oi.product_id, oi.quantity, oi.price,
       p.name as product_name
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN order_items oi ON o.id = oi.order_id
JOIN products p ON oi.product_id = p.id
WHERE o.id = ?;
```

### Best selling products
```sql
SELECT p.id, p.name, COUNT(oi.id) as times_sold, SUM(oi.quantity) as total_quantity
FROM products p
JOIN order_items oi ON p.id = oi.product_id
GROUP BY p.id
ORDER BY total_quantity DESC
LIMIT 10;
```
