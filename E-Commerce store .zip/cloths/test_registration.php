<?php
header('Content-Type: application/json');
session_start();

require_once 'config/db_config.php';
require_once 'api/email_service.php';

// Test data
$action = 'user_register';
$name = 'Test User ' . time();
$email = 'testuser' . time() . '@example.com';
$password = 'test1234';
$phone = '1234567890';
$address = 'Test Address';
$city = 'Test City';
$state = 'TS';
$zip_code = '12345';
$country = 'Test Country';

// Check database connection
if (!$conn) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

// Check if otp_verifications table exists
$check_table = $conn->query("SHOW TABLES LIKE 'otp_verifications'");
if ($check_table->num_rows === 0) {
    die(json_encode(['success' => false, 'message' => 'OTP table does not exist']));
}

$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Insert user
$insert_query = "INSERT INTO users (name, email, password, phone, address, city, state, zip_code, country, email_verified) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
$insert_stmt = $conn->prepare($insert_query);

if (!$insert_stmt) {
    die(json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]));
}

$insert_stmt->bind_param("sssssssss", $name, $email, $hashed_password, $phone, $address, $city, $state, $zip_code, $country);

if (!$insert_stmt->execute()) {
    die(json_encode(['success' => false, 'message' => 'User insert failed: ' . $insert_stmt->error]));
}

$user_id = $insert_stmt->insert_id;

// Generate OTP
$otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$expires_at = date('Y-m-d H:i:s', strtotime('+3 minutes'));

// Insert OTP
$otp_query = "INSERT INTO otp_verifications (user_id, email, otp_code, expires_at) VALUES (?, ?, ?, ?)";
$otp_stmt = $conn->prepare($otp_query);

if (!$otp_stmt) {
    die(json_encode(['success' => false, 'message' => 'OTP prepare failed: ' . $conn->error]));
}

$otp_stmt->bind_param("isss", $user_id, $email, $otp, $expires_at);

if (!$otp_stmt->execute()) {
    die(json_encode(['success' => false, 'message' => 'OTP insert failed: ' . $otp_stmt->error]));
}

// Send OTP email
$emailService = new EmailService();
$emailSent = $emailService->sendOTPEmail($email, $name, $otp);

echo json_encode([
    'success' => true,
    'message' => 'Test registration successful',
    'user_id' => $user_id,
    'email' => $email,
    'otp' => $otp,
    'email_sent' => $emailSent
]);
?>
