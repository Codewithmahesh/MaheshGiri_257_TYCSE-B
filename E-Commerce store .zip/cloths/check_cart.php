<?php
require_once 'db_config.php';

$email = 'test_cart@example.com'; // We will use this email for testing

// Get user ID
$user_query = "SELECT id FROM users WHERE email = '$email'";
$user_result = $conn->query($user_query);

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
    $user_id = $user['id'];
    
    echo "User ID: " . $user_id . "\n";
    
    // Get cart items
    $cart_query = "SELECT * FROM cart WHERE user_id = $user_id";
    $cart_result = $conn->query($cart_query);
    
    if ($cart_result->num_rows > 0) {
        echo "Cart Items:\n";
        while ($row = $cart_result->fetch_assoc()) {
            print_r($row);
        }
    } else {
        echo "Cart is empty.\n";
    }
} else {
    echo "User not found.\n";
}
?>
